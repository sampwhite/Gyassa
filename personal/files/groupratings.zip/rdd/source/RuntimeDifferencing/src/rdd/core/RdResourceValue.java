package rdd.core;

/**
 * The calculated result of merges in resources of the same type and resource name.
 */
public class RdResourceValue
{
	/**
	 * The key used to look up the resource.
	 */
	public RdResourceKey _resourceName;
	
	/**
	 * The resource definition where this value was retrieved.
	 */
	public RdResourceDefinition _resourceDef;
	
	/**
	 * The resource. Most usually a CharSequence or a RdTable.
	 */
	public Object _resource;
	
	/**
	 * Extra properties about this resource.
	 */
	public RdResourceProperties _resourceProps;
}
