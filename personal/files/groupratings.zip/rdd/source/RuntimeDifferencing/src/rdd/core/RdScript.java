package rdd.core;

public interface RdScript
{
	public void execute(RdContext cxt, int flags) throws RdException;
}
