package rdd.core.storage;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import rdd.core.RdContext;
import rdd.core.RdException;

/**
 * Used to send the stream to potentially multiple consumers. Also
 * used to notify storage implementation that stream has been closed. This object
 * exists because the input stream can persist after the main interaction
 * with the RdStorage APIs is finished (typically for streaming data back
 * to a client).
 */
public class RdStorageInputStream extends FilterInputStream
{
	public boolean _writeToOutStream;
	
	/**
	 * Think of the secondary out stream more as a listener for when bytes
	 * are read than an ordinary output stream.
	 */
	public OutputStream _streamListener;
	
	public RdStorageParameters _params;
	public RdContext _cxt;
	
	public RdStorageInputStream(InputStream in, RdStorageParameters params, RdContext cxt)
	{
		super(in);
		_params = params;
		_cxt = cxt;
	}
	
	@Override
    public int read(byte b[], int off, int len) throws IOException 
    {
    	int numRead = super.read(b, off, len);
    	if (_writeToOutStream && _streamListener != null && numRead > 0)
    	{
    		_streamListener.write(b, off, numRead);
    	}
    	return numRead;
    }
	
	@Override
	public void close() throws IOException
	{
		IOException err = null;
		try
		{
			super.close();
		}
		catch (IOException e)
		{
			err = e;
			_cxt.put(_params._additionalData, "CloseException", e);
		}
		try
		{
			// If the secondary output stream needs to be closed,
			// a handler of this event should do it.
			RdStorage.notifyCloseInputStream(this);
		}
		catch (RdException rde)
		{
			if (err == null)
			{
				Throwable cause = rde.getCause();
				if (cause instanceof IOException)
				{
					err = (IOException)cause;
				}
				else
				{
					err = new IOException();
					err.initCause(rde);
				}
			}
		}
		if (err != null)
		{
			throw err;
		}
	}
}
