package rdd.app;

import rdd.core.RdContext;
import rdd.core.strings.RdDetermineLanguageIndex;

/**
 * This class is used by the core package to get information it needs from the application
 * layer that might vary by implementation.
 * @author Sam
 *
 */
public class RdAppCallback implements RdDetermineLanguageIndex
{

	@Override
	public int determineLanguageIndex(RdContext cxt)
	{
		return 0;
	}

}
