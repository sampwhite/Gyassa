package rdd.core.logger;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Calendar;
import java.util.Date;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdException;
import rdd.core.io.IoUtils;
import rdd.core.io.RdAppendableOutputStream;
import rdd.core.primitives.DateUtils;

public class RotatingFileLogger extends RdAppendableOutputStream
{
	public String _nodeName;
	public String _appType;
	public String _logDir;
	public int _flags;
	public boolean _createSubDirectoryForEachProcess;
	public String _logFilesDir;
	public boolean _isInit;
	public boolean _startedLogging;
	public CharSequence _curLogFilePath;
	public int _logFileCreationCounter;
	public byte[] _bufferedBytes;
	public byte[] _bytesToFlush;
	public int _numBufferedBytes;
	public int _numBytesToFlush;
	public long _numBytesWrittenToCurStream;
	public long _lastWriteTimeHour;
	public long _lastWriteDayFromCalendar;
	public boolean[] _flushSyncObject;
	public boolean _flushingWriter;
	
	public int _maxByteCountBeforeRotate = 1024 * 1024 * 10; // 10 megabytes
	
	public RotatingFileLogger(String nodeName, String appType, String logDir, int flags)
	{
		_isInit = false;
		_nodeName = nodeName;
		_appType = appType;
		_logDir = logDir;
		_flags = flags;
		_bufferedBytes = new byte[IoUtils.STANDARD_LARGE_FILE_WRITE_BUFFER];
		_bytesToFlush = new byte[IoUtils.STANDARD_LARGE_FILE_WRITE_BUFFER];
		_flushSyncObject = new boolean[]{false};
		if (_nodeName == null || nodeName.length() > 0)
		{
			_nodeName = "node";
		}
		if (_appType == null || _appType.length() == 0)
		{
			_appType = "rddapp";
		}
		try
		{
			_writerForThisObject = new OutputStreamWriter(this, "UTF8");
		}
		catch (Exception ignore)
		{
			RP.errT(ignore);
		}
	}
	
	/**
	 * Configures file logger dynamically, can be called more than once.
	 */
	public void setParameters(RdContext params)
	{
		// Current empty.
	}
	
	
	/**
	 * This method must be called before object is ready to use.
	 * @throws IOException
	 * @throws RdException
	 */
	public void init(RdContext params) throws IOException, RdException
	{
		setParameters(params);
		int numParentsToCheck = 1;
		if (_createSubDirectoryForEachProcess)
		{
			_logFilesDir = _logDir + createFilesDirName(params, new Date()) + "/";
			numParentsToCheck = 2;
		}
		else
		{
			_logFilesDir = _logDir;
		}
		IoUtils.checkOrCreateDirectories(_logFilesDir, numParentsToCheck, 0, params);
		
		_isInit = true;
	}
	
	public void throwNotInitError() throws IOException
	{
		throw new IOException("^rdceLogRotatingLoggerNotInit");
	}
	
	//+section OutputStream
	@Override
	public void write(int b) throws IOException
	{
		byte[] buf = new byte[]{(byte)b};
		write(buf, 0, 1);
	}
	
	@Override
	public void write(byte b[], int off, int len) throws IOException 
	{
		if (len + _numBufferedBytes > _bufferedBytes.length)
		{
			// Allows flush to be controlled by a different synchronization object,
			// optimizing throughput just a bit if there are a lot of tiny little
			// "write"s.
			flush();
		}
		synchronized (_syncObject)
		{
			if (!_isInit)
			{
				throwNotInitError();
			}
			
			// See if there has been an hour transition.
			Date curDate = new Date();
			long curTime = curDate.getTime();
			long curTimeHour = curTime/3600000;
			boolean rotateToNew = true;
			RdContext cxt = RdAppRegistry.getThreadWrapperContext();
			if (curTimeHour != _lastWriteTimeHour)
			{
				cxt = RdAppRegistry.getThreadWrapperContext();
				Calendar cal = cxt.getInternalCalendar();
				cal.setTimeInMillis(curTime);
				int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
				if (dayOfYear != _lastWriteDayFromCalendar)
				{
					rotateToNew = true;
				}
				_lastWriteDayFromCalendar = dayOfYear;
			}
			else if (len + _numBytesWrittenToCurStream > _maxByteCountBeforeRotate)
			{
				rotateToNew = true;
			}
			if (rotateToNew)
			{
				flushCurrentBytes();
				closeCurrentStreamAndCreateNew(cxt, curDate);
			}
			_lastWriteTimeHour = curTimeHour;
			if (len + _numBufferedBytes > _bufferedBytes.length)
			{
				flushCurrentBytes();
			}
			if (len > _bufferedBytes.length)
			{
				_curStream.write(b, off, len);
			}
			else
			{
				System.arraycopy(b, off, _bufferedBytes, _numBufferedBytes, len);
				_numBufferedBytes += len;
			}
		}
	}
	
	@Override
	public void flush() throws IOException
	{
		boolean doFlush = false;
		synchronized (_syncObject)
		{
			if (!_flushingWriter)
			{
				_flushingWriter = true;
				try
				{
					_writerForThisObject.flush();
					doFlush = true;
				}
				finally
				{
					_flushingWriter = false;
				}
			}
		}
		if (doFlush)
		{
			flushCurrentBytes();
		}
	}
	//+endsection
	
	public void flushCurrentBytes() throws IOException
	{
		synchronized  (_syncObject)
		{
			if (_numBufferedBytes > 0)
			{
				synchronized (_flushSyncObject)
				{
					if (_numBytesToFlush > 0)
					{
						_curStream.write(_bytesToFlush, 0, _numBytesToFlush);
					}
					_numBytesToFlush = _numBufferedBytes;
					System.arraycopy(_bufferedBytes, 0, _bytesToFlush, 0, _numBufferedBytes);
					_numBufferedBytes = 0;
				}
			}
		}
		
		synchronized (_flushSyncObject)
		{
			if (_numBytesToFlush > 0)
			{
				_curStream.write(_bytesToFlush, 0, _numBytesToFlush);
				_numBytesToFlush = 0;
			}
			
		}
	}
	
	public void closeCurrentStreamAndCreateNew(RdContext cxt, Date curDate) throws IOException
	{
		IoUtils.closeIoObjectNoException(_curStream);
		_curStream = null;
		CharSequence prevLogPath = _curLogFilePath;
		String logFile = createLogFileName(cxt, curDate);
		String filePath = IoUtils.createAbsolutePath(_logFilesDir, logFile, cxt, 
			IoUtils.F_USE_DEFAULTS);
		
		_curStream = new FileOutputStream(filePath);
		
		String firstReport = "# " + filePath + " # Log File Creation Count: " + 
			(_logFileCreationCounter + 1);
		if (_startedLogging)
		{
			firstReport += "\n# Continuing from previous log file " + prevLogPath;
		}
		firstReport += "\n";
		byte[] buf = firstReport.getBytes();
		_curStream.write(buf);
		_curStream.flush();
		_curLogFilePath = filePath;
		_logFileCreationCounter++;
		_startedLogging = true;
	}
	
	public String createFilesDirName(RdContext cxt, Date curDate)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (curDate == null)
		{
			curDate = new Date();
		}
		String result = null;
		try
		{
			RdCharArray tempArray = cxt.temporaryAllocateCharArray();
			tempArray.append(_appType);
			tempArray.append('@');
			DateUtils.appendFileSystemSafeInternalDateFormat(cxt, curDate, tempArray);
			result = tempArray.toString();
			cxt.releaseTemporaryAllocatedCharArray(tempArray);
		}
		catch (Throwable t)
		{
			RP.errT(t);
		}
		return result;
	}
	
	public String createLogFileName(RdContext cxt, Date curDate)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (curDate == null)
		{
			curDate = new Date();
		}
		String result = null;
		try
		{
			RdCharArray tempArray = cxt.temporaryAllocateCharArray();
			if (!_createSubDirectoryForEachProcess)
			{
				tempArray.append(_nodeName);
				tempArray.append('@');
			}
			
			DateUtils.appendFileSystemSafeInternalDateFormat(cxt, curDate, tempArray);
			tempArray.append(".log");
			result = tempArray.toString();
			cxt.releaseTemporaryAllocatedCharArray(tempArray);
		}
		catch (Throwable t)
		{
			RP.errT(t);
		}
		return result;
	}
}
