package rdd.core;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import rdd.core.primitives.DateUtils;

/**
 * Used to minimize object creation and destruction.
 */
public class RdObjectLifeCycleOptimizer
{
	/**
	 * Object is bound to a particular thread of execution and a particular
	 * wrapper context.
	 */
	public RdContext _cxt;
	
	/**
	 * A date format used to create internal and debug representations of dates.
	 */
	public SimpleDateFormat _internalDateFormat;
	
	/**
	 * A Calendar object that uses the same timezone and configuration as _internalDateFormat.
	 * Used for debugging and logging.
	 */
	public Calendar _internalCalendar;
	
	/**
	 * A Random object used to create random numbers. It is not instantiated
	 * when this wrapper object is instantiated to allow caller to choose SecureRandom
	 * if they want.
	 */
	public Random _random;
	
	/**
	 * Char arrays that can be temporarily retrieved and released.
	 */
	public List<RdCharArray> _charArrays;
	
	/**
	 * Bytes arrays that can be temporarily retrieved and released.
	 */
	public List<RdByteArray> _byteArrays;
	
	public RdObjectLifeCycleOptimizer(RdContext cxt)
	{
		_cxt = cxt;
		_internalDateFormat = DateUtils.createInternalDateFormatter(cxt);
		Calendar cal = _internalDateFormat.getCalendar();
		_internalCalendar = (Calendar)cal.clone();
		_charArrays = new ArrayList<RdCharArray>();
		_byteArrays = new ArrayList<RdByteArray>();
	}
}
