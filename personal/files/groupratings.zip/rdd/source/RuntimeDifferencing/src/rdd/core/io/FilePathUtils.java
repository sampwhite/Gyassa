package rdd.core.io;

import java.io.IOException;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.logger.RP;
import rdd.core.primitives.StrUtils;

public class FilePathUtils
{
	//+section Path and file processing flags.
	static public final int F_USE_DEFAULTS = 0;
	static public final int F_IS_DIR = 1;
	//+endsection
	
	/**
	 * Finds the parent directory for a path. The directory path
	 * returned will include the trailing slash. This approach makes
	 * it easier to join the parent with alternate children.
	 * @param path Path to parse for parent directory.
	 * @return The parent directory with trailing slash.
	 */
	static public CharSequence getParent(CharSequence path)
	{
		boolean foundNonSlash = false;
		int endParentIndex = -1;
		for (int i = path.length() - 1; i > 1; i--)
		{
			char ch = path.charAt(i);
			if (!foundNonSlash)
			{
				if (ch != '/' && ch != '\\')
				{
					foundNonSlash = true;
				}
			}
			else if (ch == '/' || ch == '\\')
			{
				endParentIndex = i;
				break;
			}
		}
		CharSequence retVal = null;
		if (endParentIndex > 0)
		{
			retVal = path.subSequence(0, endParentIndex + 1);
		}
		return retVal;
	}
	
	/**
	 * Finds the file name portion (including extension) of a file path.
	 * @param path The path to parse.
	 * @return The last element in the file path with the elements created by breaking up the path by its separator.
	 */
	static public CharSequence getFileName(CharSequence path)
	{
		boolean foundNonSlash = false;
		CharSequence retVal = path;
		int endPathIndex = path.length() - 1;
		for (int i = path.length() - 1; i >= 0; i--)
		{
			char ch = path.charAt(i);
			if (!foundNonSlash)
			{
				if (ch != '/' && ch != '\\')
				{
					foundNonSlash = true;
					endPathIndex = i;
				}
			}
			else if (ch == '/' || ch == '\\')
			{
				if (i + 1 < endPathIndex)
				{
					retVal = path.subSequence(i + 1, path.length());
				}
				else
				{
					retVal = null;
				}
				break;
			}
		}
		return retVal;
	}
	
	static public String normalizeFilePath(CharSequence path, RdContext cxt, int flags)
	{
		if (path == null || path.length() == 0)
		{
			return ((flags & F_IS_DIR) != 0) ? "./" : "";
		}
		int pathLen = path.length();
		int firstSlashToProcess = pathLen;
		boolean prevCharIsSlash = false;
		for (int i = 0; i < pathLen; i++)
		{
			char ch = path.charAt(i);
			boolean isSlash = (ch == '/' || ch == '\\');
			if (isSlash && (ch == '\\' || (i > 2 && prevCharIsSlash)))
			{
				firstSlashToProcess = i;
				break;
			}
			prevCharIsSlash = isSlash;
		}
		char lastCh = path.charAt(pathLen - 1);
		boolean needsTrailingSlash = (flags & F_IS_DIR) != 0 && lastCh != '/' && lastCh != '\\';
		String retPath;
		if (firstSlashToProcess < pathLen || needsTrailingSlash)
		{
			if (cxt == null)
			{
				cxt = RdAppRegistry.getThreadWrapperContext();
			}
			RdCharArray tempArray = cxt.temporaryAllocateCharArray();
			try
			{
				tempArray.append(path, 0, firstSlashToProcess);
				tempArray.append('/');
				prevCharIsSlash = true;
				boolean prevCharsIsSlashDot = false;
				for (int i = firstSlashToProcess + 1; i < pathLen; i++)
				{
					char ch = path.charAt(i);
					if (ch == '\\')
					{
						ch = '/';
					}
					boolean isSlash = (ch == '/');
					if (ch == '.' && prevCharIsSlash)
					{
						prevCharsIsSlashDot = true;
					}
					else
					{
						if (prevCharsIsSlashDot)
						{
							if (!isSlash)
							{
								tempArray.append('.');
								tempArray.append(ch);
							}
						}
						else if (!isSlash || i <= 2 || !prevCharIsSlash)
						{
							tempArray.append(ch);
						}
						prevCharsIsSlashDot = false;
					}
					prevCharIsSlash = isSlash;
				}
				if (prevCharsIsSlashDot)
				{
					if ((flags & F_IS_DIR) == 0)
					{
						// Badly formed path ends with a single, we will let it through
						// but indicate that the result is not desired.
						tempArray.append(".err");
					}
				}
				else if (needsTrailingSlash && firstSlashToProcess + 1 < pathLen)
				{
					tempArray.append('/');
				}
			}
			catch (Throwable t)
			{
				RP.errT(t);
			}
			retPath = tempArray.toString();
			cxt.releaseTemporaryAllocatedCharArray(tempArray);
		}
		else
		{
			retPath = path.toString();
		}
		return retPath;
	}
	
	/**
	 * This method creates a new path based on the original path minus
	 * its extension plus the splice string and then with the extension
	 * added again.
	 * @param appendable The result is appended here.
	 * @param path The path which will be spliced.
	 * @param spliceStr The string to insert before the last dot.
	 * @param cxt The current context.
	 */
	static public void appendSplicedFileName(Appendable appendable, CharSequence path, 
		CharSequence spliceStr, RdContext cxt) throws IOException
	{
		int l = path.length();
		int index = StrUtils.lastIndexOf(path, '.', l - 1);
		if (index < 0)
		{
			appendable.append(path);
			appendable.append(spliceStr);
		}
		else
		{
			appendable.append(path, 0, index);
			appendable.append(spliceStr);
			appendable.append('.');
			if (index < l - 1)
			{
				appendable.append(path, index + 1, l);
			}
		}
	}
	
	/**
	 * See if the path follows the protocol of an absolute path.
	 * @param path The path to test.
	 * @return Whether the path is absolute or relative.
	 */
	static public boolean isAbsolutePath(CharSequence path)
	{
		if (path == null)
		{
			return false;
		}
		int pathLen = path.length();
		if (pathLen == 0)
		{
			return false;
		}
		char firstCh = path.charAt(0);
		boolean retVal = false;
		if (firstCh == '/' || firstCh == '\\')
		{
			retVal = true;
		}
		else if ((firstCh >= 'A' && firstCh <= 'Z') || (firstCh >= 'a' && firstCh <= 'z'))
		{
			if (pathLen > 1)
			{
				char secondChar = path.charAt(1);
				if (secondChar == ':')
				{
					retVal = true;
				}
			}
		}
		return retVal;
	}
}
