package rdd.core.merge;

import java.util.ArrayList;
import java.util.List;

public class RdMergeState
{
	List<RdMergeErrorData> _errData = new ArrayList<RdMergeErrorData>();
}
