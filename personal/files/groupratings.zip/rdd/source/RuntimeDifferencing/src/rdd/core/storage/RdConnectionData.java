package rdd.core.storage;

import java.util.List;

import rdd.core.RdContext;

/**
 * General information about a connection to storage system. Storage systems can be a shared
 * file system, a server application dedicated to serving content, or a database. Depending
 * on which, some attributes in here may be more relevant than others.
 */
public class RdConnectionData
{
	/**
	 * The unique identifier to this storage device (it is used as a lookup key to a global
	 * registry of such storage solutions).
	 */
	public String _id;
	
	/**
	 * The basic type of storage (see storage types in RdStorage).
	 */
	public int _type;
	
	/**
	 * The sub type, used to let certain filter hooks to know whether they should act on
	 * a storage event.
	 */
	public String _subType;
	
	/**
	 * Whether this storage solution is the default one that holds the main component data
	 * and configuration for the current running application.
	 */
	public boolean _isSystemStorage;
	
	/**
	 * Whether the storage uses its own transaction counter separate from the system
	 * transaction counter. If this is the case, then transactions on this storage
	 * provider are separate from the standard transactions and presumed to have
	 * there own commit and rollback implementations. The typical reason for this
	 * if one server is talking to the storage solution of another server (for
	 * archiving and transfer of data). If this is not true, then the storage
	 * solution can use global transaction counters that may be computed
	 * from a completely different source (such as a session ID global cache
	 * provider).
	 */
	public boolean _usesOwnTransactionCounter;
	
	/**
	 * A vendor designation (ORACLE, POSTGRES, MYSQL, etc.). Used to behave slightly differently 
	 * dependent based on vendor peculiarities.
	 */
	public String _vendor;
	
	/**
	 * A vendor designation of version. Used to behave slightly differently depending on version.
	 */
	public String _vendorVersion;
	
	/**
	 * Whether the connection supports multiple failover connections. This is important
	 * for activities that support "retry" logic when the first connection fails.
	 */
	public boolean _supportsFailOver;
	
	/**
	 * General connection address (usually a socket type of address). If there are multiple failover
	 * addresses, then this attribute may be blank and/or ignored and connection information may be in the
	 * _additionalData attribute.
	 */
	public String _connectionAddress;
	
	/**
	 * If file based storage (or has partial file based storage), then location of files.
	 */
	public String _fileDir;
	
	/**
	 * User name for connections requiring authentication.
	 */
	public String _username;
	
	/**
	 * Password for connections requiring authentication.
	 */
	public String _password;
	
	/**
	 * List of registered pointer to "long"s waiting for their increment counter. Used for pipelining
	 * transaction counter increments.
	 */
	public List<RdCounterWrapper> _registeredIncrementers;
	
	/**
	 * May contain information such as fail over addresses. It may also
	 * contain redundant copies of information that are in attributes
	 * of this object.
	 */
	public RdContext _additionalData;
	
	public RdConnectionData(String id, CharSequence fileDir)
	{
		_id = id;
		_type = RdStorage.FILE_TYPE;
		_fileDir = fileDir.toString();
	}
}
