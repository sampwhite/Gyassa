package rdd.core;

import java.io.IOException;

public class RdResourceLocator implements RdAppendDebug
{
	public String _path;
	public boolean _hasLineOffsetAndCharInfo;
	public int _line;
	public int _col;
	public int _mostRecentStoreSize;
	public int _loadOrder;
	public int _loadCounter;
	
	public RdResourceLocator(CharSequence path)
	{
		if (path != null)
		{
			_path = path.toString();
		}
		else
		{
			_path = "<nopath>";
		}
	}
	
	@Override
	public RdResourceLocator clone()
	{
		RdResourceLocator locator = new RdResourceLocator(_path);
		locator._path = _path;
		locator._hasLineOffsetAndCharInfo = _hasLineOffsetAndCharInfo;
		locator._line = _line;
		locator._col = _col;
		locator._mostRecentStoreSize = _mostRecentStoreSize;
		locator._loadOrder = _loadOrder;
		locator._loadCounter = _loadCounter;
		return locator;
	}

	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		appendable.append(_path);
		appendable.append("(");
		if (_hasLineOffsetAndCharInfo)
		{
			appendable.append("line=" + _line);
			appendable.append(",char=" + _col);
			appendable.append(",");
		}
		appendable.append("loadOrder=" + _loadOrder);
		appendable.append(",loadCounter=" + _loadCounter);
		appendable.append(")");
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
