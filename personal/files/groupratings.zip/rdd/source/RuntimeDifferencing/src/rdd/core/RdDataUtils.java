package rdd.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import rdd.core.io.IoUtils;
import rdd.core.logger.RP;
import rdd.core.primitives.DateUtils;
import rdd.core.primitives.NumberUtils;
import rdd.core.primitives.StrUtils;
import rdd.core.resource.RdResourceFormat;
import rdd.core.substitution.RdPathSubstitutionUtils;

/**
 * Utility methods to avoid code duplication.
 */
public class RdDataUtils
{
	//+section Appending name value flags
	static public final int F_PREPEND_SEPARATOR = 1;
	static public final int F_USE_MAP_SEPARATOR = 2;
	//+endsection Appending name value flags
	
	/**
	 * Convenience method for scenarios where convenience trumps certain types
	 * of performance considerations. This method will return an empty string
	 * instead of null.
	 */
	static public String getS(Map<RdKey,Object> m, RdKey key, RdContext cxt)
	{
		return getString(m, key, cxt).toString();
	}
	
	/**
	 * Convenience method for looking for a string entry and if it is missing
	 * returning the default string instead. It uses an object look up parameter
	 * so an RdKey or String can be used as the lookup key. This is not a good method
	 * to call in a tight loop where performance might be an issue.
	 * @param m A map of RdKey to Object.
	 * @param key A string or RdKey lookup key.
	 * @param cxt The current context.
	 * @return A string version of an object if an object is found in the map,
	 * otherwise returns 'defVal'.
	 */
	static public String getS(Map<RdKey,Object> m, Object key, String defVal, RdContext cxt)
	{
		RdKey lKey = null;
		if (key instanceof RdKey)
		{
			lKey = (RdKey)key;
		}
		else
		{
			if (key != null)
			{
				String sKey = key.toString();
				if (sKey.length() > 0)
				{
					lKey = RdContextUtils.getKeyForString(sKey, cxt);
				}
			}
		}
		String retVal = defVal;
		if (lKey != null)
		{
			Object oVal = m.get(lKey);
			if (oVal != null)
			{
				retVal = oVal.toString();
			}
		}
		return retVal;
	}
	
	/**
	 * This method returns the asked for object after being coerced into being a
	 * string. It will return an empty string instead of null. Use getWithCoercion
	 * if more subtle null handling is required.
	 *
	 * @param m The map holding the value desired.
	 * @param key The lookup key.
	 * @param cxt The current context.
	 * @return A char sequence. Many times this will be an RdCharArray which makes
	 * for great performance if the immediate usage is to help build up a page or
	 * message.
	 */
	static public CharSequence getString(Map<RdKey,Object> m, RdKey key, RdContext cxt)
	{
		Object val = m.get(key);
		return coerceToString(val, key, cxt, 0);
	}
	
	static public long getInteger(Map<RdKey,Object> m, RdKey key, long defVal, 
		RdContext cxt) throws RdException
	{
		RdValue val = getWithCoercion(m, key, 0);
		return getIntegerValue(val, key, defVal, cxt);
	}
	
	static public boolean getBoolean(Map<RdKey,Object> m, RdKey key, boolean defVal, 
		RdContext cxt)
	{
		Object val = m.get(key);
		return cooerceObjectToBoolean(val, defVal, RdContext.F_PARSE_STRING_FOR_BOOL);
	}

	static public Date getDate(Map<RdKey,Object> m, RdKey key, RdContext cxt) throws
		RdException
	{
		RdValue val = getWithCoercion(m, key, 0);
		return getDateValue(val, key, cxt);
	}
	
	static public RdTable getTable(Map<RdKey,Object> m, RdKey key, RdContext cxt)
	{
		Object obj = m.get(key);
		RdTable retVal = null;
		if (obj != null)
		{
			if (obj instanceof RdTable)
			{
				retVal = (RdTable)obj;
			}
			else if (obj instanceof RdValue)
			{
				RdValue rdVal = (RdValue)obj;
				if (rdVal._oVal instanceof RdTable)
				{
					retVal = (RdTable)rdVal._oVal;
				}
			}
		}
		return retVal;
	}
	
	/**
	 * Gets a physical file path where all variables have been substituted and where
	 * the path has been turned into a clean absolute path.
	 * @param m The map container.
	 * @param key The key to use for looking up the value (should be RdKey or CharSequence).
	 * @param deflt The default file name or path, the default will also have variables
	 * evaluated in it.
	 * @param fileFlags Specifies whether this path is a directory or not.
	 * @param cxt The current context.
	 * @return An absolute fully evaluated path.
	 */
	static public String getEvaluatedFilePath(Map<RdKey,Object>m, Object key, String deflt, 
		int fileFlags, RdContext cxt) throws RdException
	{
		String path = RdPathSubstitutionUtils.getAndSubstitutePathVariables(m, key, deflt, cxt);
		path = IoUtils.createAbsolutePath(null, path, cxt, fileFlags);
		return path;
	}
	
	/**
	 * Gets a complex object. Note that complex objects do not necessarily have a
	 * persistable string representation unlike most of the other variable types.
	 * 
	 * @param m The map container.
	 * @param key The key to use for looking up the value.
	 * @param cxt The current context.
	 * @return A generic object.
	 */
	static public Object getComplexObject(Map<RdKey,Object> m, RdKey key, RdContext cxt)
	{
		Object obj = m.get(key);
		if (!(obj instanceof RdValue))
		{
			return obj;
		}
		
		// This is the code that justifies the existence of this utility method.
		RdValue rdVal = (RdValue)obj;
		return rdVal._oVal;
	}

	/**
	 * This method returns the value of a lookup as a RdValue object. But it tends to do more
	 * than that. It has the side effect of coercing an object into its RdValue equivalent
	 * and then putting that object back in for its original. This prevents constant
	 * recalculations of conversions that are a common problem in a lot of generic
	 * attribute handling code.
	 * @param map The map where the value will be retrieved.
	 * @param key The key to lookup with.
	 * @param containerFlags The container's flags for thread safety and "read-only" state
	 * that need to be marked into the RdValue object.
	 * @return A RdValue object. This method can return null.
	 */
	static public RdValue getWithCoercion(Map<RdKey,Object> map, RdKey key, int containerFlags)
	{
		RdValue retVal = null;
		if (map == null)
		{
			return null;
		}
		if (map instanceof RdData)
		{
			// Note, this method will call this current method recursively but
			// with a more primitive map object and a value for containerFlags.
			retVal = ((RdData)map).getV(key);
		}
		else if (map instanceof RdContext)
		{
			retVal = ((RdContext)map).getV(key, RdContext.F_STANDARD_SEARCH);
		}
		else if (map instanceof RdTable)
		{
			retVal = ((RdTable)map).getV(key);
		}
		else
		{
			// We are acting on a primitive map object. Now the containerFlags parameter
			// is relevant (and is set only if value is being retrieved on a more
			// complex map object).
			Object oVal = map.get(key);
			if (oVal != null)
			{
				if (!(oVal instanceof RdValue))
				{
					retVal = new RdValue(key, oVal);
					retVal._flags = RdDataFlags.setIsSharedFlag(containerFlags, retVal._flags);
					
					// There may be potential thread safety issues, but we are replacing
					// one entry with another so it should be safe. If not, then this
					// can be revisited. Note that the new entry is equivalent (but
					// with extra features) to the original. The main advantage
					// is that we do not have to keep parsing Date or Integer values
					// from strings every time we access those types of objects.
					// See implementations of getDateValue and getIntegerValue.
					map.put(key, retVal);
				}
				else
				{
					retVal = (RdValue)oVal;
					retVal._flags = RdDataFlags.setIsSharedFlag(containerFlags, retVal._flags);
				}
			}
		}
		return retVal;
	}
	
	/**
	 * Clones a map into a RdData object, but RdData will not have synchronization protection.
	 */
	static public <T> Map<RdKey,T> cloneRdMap(Map<RdKey,T> map)
	{
		if (map == null)
		{
			return null;
		}
		RdData retVal = null;
		if (map instanceof RdTable)
		{
			Map<RdKey,Object> m = ((RdTable)map).createMapFromCurrentRow();
			retVal = new RdData(RdData.GENERIC, m, null);
		}
		else if (map instanceof RdData)
		{
			retVal = (RdData)((RdData)map).clone();
		}
		else
		{
			// Create our own object. If 'map' has synchronization
			// protection, we don't want our clone to do so as well.
			RdData retMap = new RdData();
			retMap.putAll(map);
			retVal = retMap;
		}
		return (Map<RdKey,T>)retVal;
	}
	
	static public List cloneList(List l)
	{
		Object retVal = null;
		if (l instanceof ArrayList)
		{
			retVal = ((ArrayList)l).clone();
		}
		else if (l instanceof Vector)
		{
			retVal = ((Vector)l).clone();
		}
		else
		{
			List newList = new ArrayList();
			newList.addAll(l);
			retVal = newList;
		}
		return (List)retVal;
	}
	
	static public boolean cooerceObjectToBoolean(Object obj, boolean def, int flags)
	{
		if (obj == null)
		{
			return def;
		}
		CharSequence sVal = null;
		Object oVal = null;
		if (obj instanceof CharSequence)
		{
			sVal = (CharSequence)obj;
		}
		else
		{
			oVal = obj;
			if (obj instanceof RdValue)
			{
				RdValue rV = (RdValue)obj;
				if (rV.isNull())
				{
					return def;
				}
				sVal = rV._sVal;
				oVal = rV._oVal;
			}
		}
		boolean retVal = def;
		if (oVal == null)
		{
			if (sVal != null)
			{
				if ((flags & RdContext.F_PARSE_STRING_FOR_BOOL) != 0)
				{
					int sValLen = sVal.length();
					if (sValLen > 0)
					{
						char ch = sVal.charAt(0);
						if (ch == '+' || ch == '-')
						{
							if (sValLen > 1)
							{
								ch = sVal.charAt(1);
							}
						}
						if (ch == 't' || ch == 'T' || ch == 'y' || ch == 'Y' || ch == '1')
						{
							retVal = true;
						}
						else if (ch == 'f' || ch == 'F' || ch == 'n' || ch == 'N' || ch == '0')
						{
							retVal= false;
						}
					}
				}
				else
				{
					retVal = sVal.length() > 0;
				}
			}
		}
		else if (oVal instanceof Map)
		{
			retVal = !((Map)oVal).isEmpty();
		}
		else if (oVal instanceof Object[])
		{
			retVal = ((Object[])oVal).length > 0;
		}
		else if (oVal instanceof Collection)
		{
			retVal = ((Collection)oVal).size() > 0;
		}
		else if (oVal instanceof Boolean)
		{
			retVal = ((Boolean)oVal).booleanValue();
		}
		else if (oVal instanceof Integer)
		{
			retVal = ((Integer)oVal).intValue() != 0;
		}
		return retVal;
	}
	
	static public void appendTo(Appendable appendable, Object obj, RdKey key, int depth, RdContext cxt, int flags) throws IOException
	{
		Object oVal = obj;
		RdValue rV = null;
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (obj instanceof RdValue)
		{
			rV = (RdValue)obj;
			if (rV._sVal != null)
			{
				appendable.append(rV._sVal);
				return;
			}
			if (rV._type == RdKey.INTEGER && rV._oVal == null)
			{
				appendable.append("" + rV._lVal);
				return;
			}
			oVal = rV._oVal;
		}
		if (oVal == null)
		{
			return;
		}
		if (oVal instanceof CharSequence)
		{
			appendable.append((CharSequence)oVal);
		}
		else if (oVal instanceof Boolean)
		{
			char charVal = ((Boolean)oVal).booleanValue() ? '1' : '0';
			appendable.append(charVal);
		}
		else if (oVal instanceof Date)
		{
			CharSequence dateFormat = DateUtils.internalFormatDate(cxt, (Date)oVal);
			if (rV != null)
			{
				// The main justification for the existence of the RdValue object is that we can do this.
				rV._sVal = dateFormat;
				rV._lVal = ((Date)oVal).getTime();
			}
			appendable.append(dateFormat);
		}
		else if (oVal instanceof RdAppender)
		{
			// This is where we get the big performance boost.
			((RdAppender)oVal).appendTo(appendable, key, depth, cxt, flags);
		}
		else if (oVal instanceof Collection)
		{
			RdCharArray array = cxt.temporaryAllocateCharArray();
			boolean pastFirst = false;
			for (Object o : (Collection)oVal)
			{
				if (pastFirst)
				{
					appendable.append(',');
				}
				array.reset();
				appendTo(array, o, key, depth + 1,cxt, flags);
				StrUtils.appendEncodedStr(appendable, array, key, cxt, StrUtils.F_ENCODE_ARRAY_CHARS | StrUtils.F_ENCODE_LF);
				pastFirst = true;
			}
			cxt.releaseTemporaryAllocatedCharArray(array);
		}
		else if (oVal instanceof Object[])
		{
			RdCharArray array = cxt.temporaryAllocateCharArray();
			boolean pastFirst = false;
			for (Object o : (Object[])oVal)
			{
				if (pastFirst)
				{
					appendable.append(',');
				}
				array.reset();
				appendTo(array, o, key, depth + 1,cxt, flags);
				StrUtils.appendEncodedStr(appendable, array, key, cxt, StrUtils.F_ENCODE_ARRAY_CHARS | StrUtils.F_ENCODE_LF);
				pastFirst = true;
			}
			cxt.releaseTemporaryAllocatedCharArray(array);
			
		}
		else if (oVal instanceof Map)
		{
			Map m = (Map)oVal;
			RdResourceFormat.formatMapToAppendable(appendable, m, cxt, key, '=', ';', depth, 
				flags);
		}
		else
		{
			String strFormat = oVal.toString();
			appendable.append(strFormat);
		}
	}
	
	static public CharSequence coerceToString(Object obj, RdKey key, RdContext cxt, int flags)
	{
		Object oVal = obj;
		RdValue rV = null;
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (obj instanceof RdValue)
		{
			rV = (RdValue)obj;
			if (rV._sVal != null)
			{
				return rV._sVal;
			}
			if (rV._type == RdKey.INTEGER && rV._oVal == null)
			{
				return "" + rV._lVal;
			}
			oVal = rV._oVal;
		}
		if (oVal == null)
		{
			return "";
		}
		CharSequence retVal = null;
		if (oVal instanceof CharSequence)
		{
			retVal = (CharSequence)obj;
		}
		else if (oVal instanceof Boolean)
		{
			boolean boolVal = ((Boolean)obj).booleanValue();
			retVal = (((Boolean)obj).booleanValue()) ? "1" : "0";
			if (rV != null)
			{
				rV._sVal = retVal;
				rV._lVal = (boolVal) ? 1 : 0;
			}
		}
		else if (oVal instanceof Date)
		{
			retVal = DateUtils.internalFormatDate(cxt, (Date)oVal);
			if (rV != null)
			{
				// The main justification for the existence of the RdValue object is that we can do this.
				// Note, that if date value changes, we need to update these attributes.
				rV._sVal = retVal;
				rV._lVal = ((Date)oVal).getTime();
			}
		}
		else if (oVal instanceof Integer)
		{
			if (rV != null)
			{
				rV._lVal = ((Integer)oVal).longValue();
				rV._sVal = "" + rV._lVal;
			}
		}
		else
		{
			RdCharArray array = cxt.temporaryAllocateCharArray();
			try
			{
				appendTo(array, oVal, key, 0, cxt, flags);
			}
			catch (Exception ignore)
			{
				RP.traceException("internal", ignore, cxt);
			}
			retVal = array.toString();
			cxt.releaseTemporaryAllocatedCharArray(array);
		}
		if (retVal == null)
		{
			retVal = obj.toString();
		}
		return retVal;
	}
	
	/**
	 * Utility method to get a long value for a RdValue object. It
	 * will coerce the object so that it will remember the conversion (if
	 * one was necessary). Note that the RdKey.INTEGER type means "long" in
	 * Java.
	 * @param value The RdValue object holding the "long" value.
	 * @param key The lookup key for the field accessed.
	 * @param defVal The default value if no field value is present.
	 * @return The value as a "long".
	 */
	static public long getIntegerValue(RdValue value, RdKey key, long defVal,
		RdContext cxt) throws RdException
	{
		if (value._type == RdKey.INTEGER)
		{
			return value._lVal;
		}
		
		if (value._sVal == null || value._sVal.length() == 0)
		{
			return defVal;
		}
		long val = NumberUtils.parseLong(value._sVal, defVal);
		if (key._type == RdKey.INTEGER)
		{
			// Change RdValue type so next time we don't have to do this
			// calculation.
			value._type = RdKey.INTEGER;
			value._lVal = val;
		}
		return val;
	}

	/**
	 * Utility method to get a Date value for a RdValue object. It
	 * will coerce the object so that it will remember the conversion (if
	 * one was necessary). 
	 * @param value The value holding the Dave value desired.
	 * @param key The lookup key for the field that was accessed.
	 * @return The field value as a Date.
	 */
	static public Date getDateValue(RdValue value, RdKey key,
		RdContext cxt) throws RdException
	{
		if (value._type == RdKey.DATE)
		{
			return (Date)value._oVal;
		}
		
		if (value._sVal == null || value._sVal.length() == 0)
		{
			return null;
		}
		Date retVal = DateUtils.parseInternalFormatDate(value._sVal, cxt);
		value._oVal = retVal;
		return retVal;
	}

	static public Object cooerceToSettableValue(RdKey key, Object value, int flags)
	{
		if (value == null)
		{
			return RdGlobalValues.NULL_VALUE;
		}
		boolean isReadOnly = (flags & RdDataFlags.F_READ_ONLY) != 0;
		boolean createNewValue = false;
		if (value instanceof RdCharArray)
		{
			value = value.toString();
		}
		else if (value instanceof RdValue)
		{
			RdValue rv = (RdValue)value;
			if (rv._key != key || (
				(isReadOnly && (rv._flags & RdDataFlags.F_READ_ONLY) == 0)))
			{
				createNewValue = true;
			}
			rv.fixupParentsForChildChange();
		}
		else if (isReadOnly && !(value instanceof CharSequence))
		{
			createNewValue = true;
		}
		if (createNewValue)
		{
			RdValue deVal = new RdValue(key, value);
			if (isReadOnly)
			{
				deVal.setReadOnly();
			}
			value = deVal;
		}
		return value;
	}
	
	static public Object prepareForIterativeAccess(RdKey key, Object obj, int flags)
	{
		if (obj instanceof RdTable)
		{
			return ((RdTable)obj).shallowClone();
		}
		else if (obj instanceof RdValue)
		{
			RdValue rV = (RdValue)obj;
			if (rV._oVal instanceof RdTable)
			{
				return rV.shallowClone();
			}
		}
		return obj;
	}
	
	static public int determineBestFitValueType(RdKey key, Object obj)
	{
		int keyType = (key != null) ? key._type : RdKey.STRING;
		if (keyType != RdKey.TABLE && keyType != RdKey.DATA && keyType != RdKey.MAP)
		{
			// Treat as string resource.
			keyType = RdKey.STRING;
		}

		if (obj == null)
		{
			return keyType;
		}
		int objType = RdKey.STRING;
		if (obj instanceof RdValue)
		{
			objType = ((RdValue)obj)._type;
		}
		else if (obj instanceof RdTable)
		{
			objType = RdKey.TABLE;
		}
		else if (obj instanceof RdData)
		{
			objType = RdKey.DATA;
		}
		else if (obj instanceof Collection || obj instanceof Object[])
		{
			objType = RdKey.COLLECTION;
		}
		else if (obj instanceof Map)
		{
			objType = RdKey.MAP;
		}
		else if (obj instanceof Boolean)
		{
			objType = RdKey.BOOLEAN;
		}
		if (objType == RdKey.STRING)
		{
			objType = keyType;
		}
		if (objType != keyType && keyType != RdKey.STRING)
		{
			objType = RdKey.STRING;
		}
		if (objType == RdKey.ARRAY)
		{
			objType = RdKey.COLLECTION;
		}
		return objType;
	}
	
	static public void appendNameValue(Appendable appendable, CharSequence name, CharSequence value, RdContext cxt, int flags) throws IOException
	{
		if ((flags & F_PREPEND_SEPARATOR) != 0)
		{
			char sepChar = ((flags & F_USE_MAP_SEPARATOR) != 0) ? ';' : ',';
			appendable.append(sepChar);
		}
		appendable.append(name);
		if (value != null)
		{
			appendable.append('=');
			appendable.append(value);
		}
	}
	
	static public void appendDebugNameValue(Appendable appendable, CharSequence name, Object val,
		RdKey key, int depth, RdContext cxt, boolean appendedLeftParen, int flags) 
		throws IOException
	{
		if (!appendedLeftParen)
		{
			appendable.append('(');
		}
		else
		{
			appendable.append(',');
		}
		appendable.append(name);
		if (val != null)
		{
			appendable.append('=');
			RdDataUtils.appendTo(appendable, val, key, depth + 1, cxt, flags);
		}
	}
	
	//+section Debug support methods
	static public String createDebugStringReport(RdAppendDebug appendDebug, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray tempArray = cxt.temporaryAllocateCharArray();
		try
		{
			appendDebug.appendDebug(tempArray, cxt, 0);
		}
		catch (Throwable ignore)
		{
			RP.errT(ignore);
		}
		String retVal = tempArray.toString();
			cxt.releaseTemporaryAllocatedCharArray(tempArray);
		return retVal;
	}
	
	static public String createDebugStringReport(RdAppender appender, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray tempArray = cxt.temporaryAllocateCharArray();
		try
		{
			appender.appendTo(tempArray, null, 0, cxt, RdContext.F_DEBUG_FORMAT);
		}
		catch (Throwable ignore)
		{
			RP.errT(ignore);
		}
		String retVal = tempArray.toString();
		cxt.releaseTemporaryAllocatedCharArray(tempArray);
		return retVal;
	}
	
	static public void appendDebugObject(Appendable appendable, Object obj, RdContext cxt, int flags)
	{
		try
		{
			appendTo(appendable, obj, null, 0, cxt, flags | RdContext.F_DEBUG_FORMAT);
		}
		catch (Exception e)
		{
			// Not much use reporting this error (since this is in a toString done from an IDE
			// debugger)
		}
	}
	//+endsection Debug support methods
}
