package rdd.core.primitives;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdException;

public class DateUtils
{
	static public SimpleDateFormat createInternalDateFormatter(RdContext cxt)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		TimeZone utz = TimeZone.getTimeZone("GMT");
		sdf.setTimeZone(utz);
		return sdf;
	}
	
	static public void appendInternalDateFormat(RdContext cxt, Date d, Appendable appendable) throws IOException
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		SimpleDateFormat sdf = cxt.getInternalDateFormatter();
		if (d == null)
		{
			d = new Date();
		}
		String formatResult = sdf.format(d);
		appendable.append(formatResult);
	}
	
	static public String internalFormatDate(RdContext cxt, Date d)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (d == null)
		{
			d = new Date();
		}
		SimpleDateFormat sdf = cxt.getInternalDateFormatter();
		return sdf.format(d);
	}

	static public String internalFormatDate(RdContext cxt, long dateVal)
	{
		return internalFormatDate(cxt, new Date(dateVal));
	}
	
	static public Date parseInternalFormatDate(CharSequence dateStr, RdContext cxt)
		throws RdException
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		SimpleDateFormat sdf = cxt.getInternalDateFormatter();
		String formatStr = dateStr.toString();
		if (formatStr.length() == 0)
		{
			return null;
		}
		Date d = null;
		try
		{
			d = sdf.parse(formatStr);
		}
		catch (ParseException e)
		{
			throw new RdException(e, "rdceParseFailureForDate", dateStr);
		}
		return d;
	}

	static public void appendFileSystemSafeInternalDateFormat(RdContext cxt, Date d, Appendable appendable) throws IOException
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray tempArray = cxt.temporaryAllocateCharArray();
		appendInternalDateFormat(cxt, d, tempArray);
		for (int i = 0; i < tempArray._len; i++)
		{
			char ch = tempArray._chars[i];
			if ((ch < '0' || ch > '9') && (ch < 'a' || ch > 'z') && (ch < 'A' || ch > 'Z'))
			{
				tempArray._chars[i] = '_';
			}
		}
		appendable.append(tempArray);
		cxt.releaseTemporaryAllocatedCharArray(tempArray);
	}
}
