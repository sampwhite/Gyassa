package rdd.core;

public class RdContextKey
{
	public String _contextId;
	public RdContextKey _parent;
	
	public RdContextKey(String contextId, RdContextKey parent)
	{
		_contextId = contextId;
		_parent = parent;
	}
	
}
