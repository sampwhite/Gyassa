package rdd.core.primitives;

import java.util.List;
import java.util.Map;

import rdd.core.RdValue;

public class ValueUtils
{
	static public boolean isEmpty(Object obj)
	{
		if (obj == null)
		{
			return true;
		}
		if (obj instanceof CharSequence)
		{
			return ((CharSequence)obj).length() == 0;
		}
		if (obj instanceof RdValue)
		{
			return ((RdValue)obj).isNull();
		}
		if (obj instanceof List)
		{
			return ((List)obj).size() == 0;
		}
		if (obj instanceof Map)
		{
			return ((Map)obj).size() == 0;
		}
		if (obj instanceof Object[])
		{
			return ((Object[])obj).length == 0;
		}
		return false;
	}
}
