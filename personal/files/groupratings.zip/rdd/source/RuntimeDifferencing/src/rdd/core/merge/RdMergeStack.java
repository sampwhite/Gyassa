package rdd.core.merge;

public class RdMergeStack
{
	public boolean _isMerged;
	RdMergeItem[] _mergeableData;
	
	/**
	 * Extended merge data from associated files. Example:
	 * List of countries in a Country table. Each country has
	 * an associated file that has RdData properties about the country.
	 * Each component that overlays the country will have also a copy of
	 * the country file that overlays the files from other components
	 * that also have an entry for that country.
	 */
	RdResourceMergeData _associatedData;
}
