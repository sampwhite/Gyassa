package rdd.core.io;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import rdd.core.RdCharArray;
import rdd.core.logger.RP;

public class RdAppendableOutputStream extends OutputStream implements Appendable
{
	public OutputStream _curStream;
	public Writer _writerForThisObject;
	public boolean[] _syncObject = new boolean[1];
	
	public RdAppendableOutputStream(OutputStream curStream, String encoding)
	{
		try
		{
			_curStream = curStream;
			if (encoding != null)
			{
				_writerForThisObject = new OutputStreamWriter(_curStream, encoding);
			}
			else
			{	_writerForThisObject = new OutputStreamWriter(_curStream);
			}
		}
		catch (Exception ignore)
		{
			RP.errT(ignore);
		}
	}
	
	protected RdAppendableOutputStream()
	{
		// Only for those who extend this class.
	}

	//+section OutputStream
	@Override
	public void write(int b) throws IOException
	{
		byte[] buf = new byte[]{(byte)b};
		write(buf, 0, 1);
	}
	
	@Override
	public void write(byte b[], int off, int len) throws IOException 
	{
		_curStream.write(b, off, len);
	}
	
	@Override
	public void flush() throws IOException
	{
		_writerForThisObject.flush();
		_curStream.flush();
	}
	
	@Override
	public void close() throws IOException
	{
		synchronized (_syncObject)
		{
			_writerForThisObject.flush();
		}
		_curStream.close();
	}
	//+endsection OutputStream
	
	//+section Interface Appendable
	@Override
	public Appendable append(CharSequence csq) throws IOException
	{
		append(csq, 0, csq.length());
		return this;
	}

	@Override
	public Appendable append(CharSequence csq, int start, int end) throws IOException
	{
		char[] buf = null;
		if (start >= end)
		{
			return this;
		}
		if (csq instanceof RdCharArray)
		{
			buf = ((RdCharArray)csq)._chars;
		}
		else
		{
			buf = new char[end - start];
			for (int i = start; i < end; i++)
			{
				buf[i - start] = csq.charAt(i);
			}
			end = end - start;
			start = 0;
		}
		synchronized (_syncObject)
		{
			_writerForThisObject.write(buf, start, end - start);
		}
		return this;
	}

	@Override
	public Appendable append(char c) throws IOException
	{
		synchronized (_syncObject)
		{
			_writerForThisObject.write(c);
		}
		return this;
	}
	//+endsection Interface Appendable
	
	/**
	 * Convenience method to optimize sending out characters.
	 */
	public void writeDirect(char[] buf, int start, int len) throws IOException
	{
		synchronized (_syncObject)
		{
			_writerForThisObject.write(buf, start, len);
		}
	}
}
