package rdd.core;

import java.io.IOException;

public interface RdAppendDebug
{
	/**
	 * See RdAppender. This version is just for appending debug information for logging and doing "toString()" on objects.
	 * @throws IOException
	 */
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException;
}

