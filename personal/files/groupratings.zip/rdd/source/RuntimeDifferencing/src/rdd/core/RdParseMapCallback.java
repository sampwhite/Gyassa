package rdd.core;

public interface RdParseMapCallback
{
	/**
	 * Callback interface hook for when name value pairs are parsed. Note that both keyArray and valArray may be mildly mutated
	 * by the time the method call exits (some characters may have changed case). This is done for performance reasons.
	 * @param keyArray An array of characters holding the key.
	 * @param keyStart The start in the key array. If the first character is a tilde ("~"), then the key string starts one character
	 * later and the callback method is asking for the key to be removed.
	 * @param keyEnd Key ends one before this index, length of key is keyEnd - keyStart.
	 * @param valArray The array holding the value.
	 * @param valStart The start in the value array.
	 * @param valEnd The string to be extracted ends one before this index. If valEnd is equal to valStart, then the value is assumed to
	 * be "1".
	 * @param state The parsing state at the time this callback method is invoked. In particular, has a non null _cxt attribute.
	 * @param flags The general parsing flags that are active.
	 */
	public void onParseNameValue(char[] keyArray, int keyStart, int keyEnd, char[] valArray, int valStart, int valEnd,
		RdParsingState state, int flags);
}
