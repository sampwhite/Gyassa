package rdd.security;

public class RdPrivilege
{
	/**
	 * These are generic privileges that would apply to most resources or data that is
	 * granted privileges using this privilege object.
	 */
	//+section Access rights
	/**
	 * The group grants read privilege. The object being tested for privilege can be accessed by the
	 * client.
	 */
	static public int F_READ = 1;
	
	/**
	 * The group grants write privileges. The object being tested for privilege can be modified
	 * in a limited way by the client. The privileges on the object cannot be modified. An
	 * example, might be the rule that an author has read and write privileges to the content
	 * they create. In this case the content would be assigned the RdPrivilege that had
	 * its group be a wrapper for the user and the privilege level of F_READ | F_WRITE.
	 */
	static public int F_WRITE = 2;
	
	/**
	 * The group grants delete privileges. The object being tested for privilege can be deleted.
	 */
	static public int F_DELETE = 4;
	
	/**
	 * The group grants full alteration privileges. This includes modifying the groups or
	 * privileges assigned to the object.
	 */
	static public int F_ALTER = 8;
	
	/**
	 * The access right granted by the group (see flags above). For simple privilege objects
	 * (those granting simple boolean privileges) this attribute will be 0. In certain
	 * very complex security models, the RdPrivilege object will be granted to a data
	 * item instead of just a group.
	 */
	public int _accessRights;
	
	/**
	 * Group which gets the privilege.
	 */
	public RdSecurityGroup _group;
}
