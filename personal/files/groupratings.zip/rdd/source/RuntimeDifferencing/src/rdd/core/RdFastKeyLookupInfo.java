package rdd.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RdFastKeyLookupInfo
{
	public String _type;
	public Map<RdKey,Integer> _registeredKeyLookup;
	public List<RdKey> _registeredKeys;
	public int _numRegisteredKeys;
	
	public RdFastKeyLookupInfo(String type)
	{
		_type = type;
		_registeredKeyLookup = new HashMap<RdKey,Integer>();
		_registeredKeys = new ArrayList<RdKey>();
	}
	
	synchronized public int getOrRegisterKeyIndex(RdKey key)
	{
		// See if already registered.
		Integer result = _registeredKeyLookup.get(key);
		if (result == null)
		{
			int nextIndex = _registeredKeys.size();
			result = new Integer(nextIndex);
			_registeredKeys.add(key);
			_registeredKeyLookup.put(key, result);
			_numRegisteredKeys++;
		}
		return result.intValue();
	}
	
	synchronized public RdKey getKeyByIndex(int index)
	{
		if (index < 0 || index >= _numRegisteredKeys)
		{
			return null;
		}
		return _registeredKeys.get(index);
	}
	
	synchronized public int getNumberOfRegisteredKeys()
	{
		return _numRegisteredKeys;
	}
}
