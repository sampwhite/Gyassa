package rdd.core;


/**
 * Errors that are not significant enough to make the parsing of a file or stream to fail
 * but significant enough that they should be reported at some point to an administrator or
 * developer in a non intrusive way.
 */
public class RdResourceFormatError
{
	public RdParsingState _stateAtError;
	public int _errType;
	public RdResourceKey _resourceKey;
	public RdKey _resourceVarKey;
	
	public RdResourceFormatError(RdParsingState state, int errType)
	{
		_stateAtError = state;
		_errType = errType;
	}
	
}
