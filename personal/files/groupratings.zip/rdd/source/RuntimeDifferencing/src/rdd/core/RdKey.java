package rdd.core;

/**
 * The structure that holds information about a "well-defined" variable.
 * There is a unique instance of any RdKey with a specific "name" in
 * any application. To get the RdKey for a particular string, use the
 * call RdContextUtils.getKeyForString. For example, to get the RdKey
 * for the string "abc", do the following:
 * 
 * RdContext cxt = RdAppRegistry.getThreadWrapperContext();
 * ...
 * RdKey abcKey = RdContextUtils.getKeyForString("abc", cxt);
 */
public class RdKey
{
	//+section Flags
	static public final int F_IS_SECURE = 1;
	static public final int F_STRING_NON_DEFAULT = 2;
	static public final int F_IS_CONSTANT = 4;
	static public final int F_HAS_PROFILE = 8;
	static public final int F_IS_PATH = 16;
	static public final int F_IS_NOT_SERIALIZABLE = 32;
	static public final int F_TYPE_UNRESOLVED = 128;
	static public final int F_TYPE_EXPLICITLY_DEFINED = 256;
	//+endsection Flags
	
	//+section Types
	static public final int NULL = 0;
	static public final int STRING = 1; // This typically maps to RdResourceTypes.NAMEVALUE and NOT RdResourceTypes.STRING.
	static public final int BOOLEAN = 2;
	static public final int INTEGER = 3;
	static public final int FLOAT = 4;
	static public final int DATE = 5;
	static public final int ARRAY = 6;
	static public final int COLLECTION = 7;
	static public final int MESSAGE = 8;
	static public final int MAP = 9;
	static public final int TABLE = 10;
	static public final int DATA = 11;
	static public final int COMPLEX = 12;
	static public final int BINARY = 13;
	static public final int UNKNOWN = 14;
	//+endsection Types
	
	static public String[] TYPE_REPORT_STRINGS = {"null", "string", "boolean", "integer", "float", "date", 
		"array", "collection", "message", "map", "table", "data", "complex", "binary", "unknown"};
	
	//+section Attributes
	public String _name;
	public int _type;
	public int _flags;
	//+endsection Attributes
	
	/**
	 * Do not call this constructor directly (use methods that
	 * get it from central store). See comments at beginning of class.
	 */
	protected RdKey(String name)
	{
		_name = name.intern();
		_type = 1;
	}
	
	/**
	 * Do not call this constructor directly (use methods that
	 * get it from central store). See comments at beginning of class.
	 */
	protected RdKey(String name, int type)
	{
		_name = name.intern();
		_type = type;
	}
	
	public boolean isSerializableValue()
	{
		return (_flags & F_IS_NOT_SERIALIZABLE) == 0;
	}
	
	@Override
	public String toString()
	{
		return _name + "{" + ((_type >= 0 && _type < TYPE_REPORT_STRINGS.length) ? TYPE_REPORT_STRINGS[_type] : "") + "}";
	}
}
