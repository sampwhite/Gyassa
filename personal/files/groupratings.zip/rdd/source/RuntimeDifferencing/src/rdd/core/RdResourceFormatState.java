package rdd.core;

import java.util.ArrayList;
import java.util.List;

public class RdResourceFormatState
{
	List<RdResourceFormatError> _formatErrors = new ArrayList<RdResourceFormatError>();
}
