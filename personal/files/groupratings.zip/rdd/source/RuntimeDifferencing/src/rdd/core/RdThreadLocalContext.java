package rdd.core;

public class RdThreadLocalContext extends ThreadLocal<RdContext>
{
	
	@Override
	protected RdContext initialValue() 
	{
		RdContext threadContext = new RdContext(null, RdContext.WRAPPER_CONTEXT);
		threadContext._contextStack[RdContext.GLOBAL_CONTEXT] = RdAppRegistry._globalContext;
		RdContext paramsContext = new RdContext(threadContext, RdContext.PARAMETERS_CONTEXT, Thread.currentThread().getName(), new RdData());
		threadContext._contextStack[RdContext.PARAMETERS_CONTEXT] = paramsContext;
		threadContext._isInit = true;
		return threadContext;
	}
}
