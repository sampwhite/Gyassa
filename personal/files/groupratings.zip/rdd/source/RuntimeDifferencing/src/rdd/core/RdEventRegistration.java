package rdd.core;

public class RdEventRegistration implements Comparable
{
	public String _id;
	public RdEventId _event;
	public int _executeOrder;
	public int _flags;
	public String _registrationParam;
	public String _className;
	public boolean _isRemove;
	public ClassLoader _classLoader;
	public RdEventInterface _eventHandler;
	
	public RdEventRegistration(String id, RdEventId event, int executeOrder, int flags,
		String registrationParam, String className)
	{
		_id = id;
		_event = event;
		_executeOrder = executeOrder;
		_flags = flags;
		_registrationParam = registrationParam;
		_className = className;
	}
	
	@Override
	public int compareTo(Object o)
	{
		return _executeOrder - ((RdEventRegistration)o)._executeOrder;
	}
}
