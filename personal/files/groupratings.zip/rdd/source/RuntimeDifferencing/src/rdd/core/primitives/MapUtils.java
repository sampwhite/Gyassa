package rdd.core.primitives;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import rdd.core.RdContext;
import rdd.core.RdKey;

public class MapUtils
{
	//+section Merge flags
	static public final int F_STANDARD_MERGE = 0;
	static public final int F_DO_NOT_REPLACE_EXISTING = 1;
	//+endsection Merge flags
	
	static public void mergeKeyMaps(Map<RdKey,Object> fromMap, Map<RdKey,Object> toMap, RdContext cxt, int flags)
	{
		boolean noReplace = (flags & F_DO_NOT_REPLACE_EXISTING) != 0;
		Set<RdKey> keys = fromMap.keySet();
		for (RdKey key : keys)
		{
			if (noReplace)
			{
				Object o = toMap.get(key);
				if (!ValueUtils.isEmpty(o))
				{
					continue;
				}
			}
			Object val = fromMap.get(key);
			toMap.put(key, val);
		}
	}
	
	static public <T,U> Map<T,U> cloneMap(Map<T,U> map)
	{
		Map<T,U> retVal = map;
		Class mapType = map.getClass();
		try
		{
			retVal = (Map<T,U>)mapType.newInstance();
		}
		catch (Exception ignore)
		{
			// Create our own array object.
			retVal = new HashMap<T,U>();
		}
		retVal.putAll(map);
		return retVal;
	}
}
