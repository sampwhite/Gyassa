package rdd.core.primitives;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdKey;

public class StrUtils
{
	//+section Encoding flags
	static public final int F_ENCODE_LF = 1;
	static public final int F_ENCODE_MAP_CHARS = 2;
	static public final int F_ENCODE_ARRAY_CHARS = 4;
	static public final int F_ENCODE_PARENTHESIS = 8;
	static public final int F_ENCODE_FUNCTION_CHARS = F_ENCODE_ARRAY_CHARS | F_ENCODE_PARENTHESIS;
	static public final int F_ENCODE_ALL = F_ENCODE_LF | F_ENCODE_MAP_CHARS | F_ENCODE_ARRAY_CHARS | F_ENCODE_PARENTHESIS;
	//+endsection Encoding flags.
	
	//+section Wildcard match flags
	static public final int F_DO_FIRST_PATTERN_ONLY = 1;
	//+endsection Wildcard match flags
	
	// When writing out text content, try to limit lines to this length.
	static public int _preferredLineLen = 200;
	
	static public final RdCharArray SPACE_10_CHARS = new RdCharArray("          ");
	static public final RdCharArray TWO_LINE_FEEDS = new RdCharArray("\n\n");
	static public char[][] _encodedCharsArray = new char[128][];
	static public String[] _encodedCharsStr = new String[128];
	static public int[] _encodedCharsFlags = new int[128];
	static public char[][] _fastEncodedCharsLookup = new char[128][];
	static public boolean[] _fastNeedsThirdCharLookup = new boolean[128];
	static public char[][][] _fastEncodedThirdCharsLookup = new char[128][][];
	static public char[][] _fastEncodedThirdCharsLookupResult = new char[128][];
	static public char[] _fastEncodedCharsLookupResult = new char[128];
	
	// Used to test if a particular character is a legal character for a variable.
	static public boolean _isVarChar[] = new boolean [128];
	
//+section Static initialization
	/**
	 * Following characters need to be escaped (though not all of them all of the time).
	 * 
	 * ^ = Encoding character.
	 * : = For map encoding, separator between key and value (ex: mapKey=key1:val1;key2:val2)
	 * ; = For map encoding, separator between key and values pairs.
	 * , = For array and table row encoding, separates between values.
	 * # = Start of comments, all characters that follow on line are not parsed for a value.
	 * \n = End of table row
	 * \r = Hard to handle character in text files.
	 * \t = Ruins expected formatting of text files when value appears in data.
	 * \0 = Ruins strings.
	 */
	static
	{
		setEncodedChars('^', "^^", 0);
		setEncodedChars(':', "^colon^", F_ENCODE_MAP_CHARS);
		setEncodedChars(';', "^semi^", F_ENCODE_MAP_CHARS);
		setEncodedChars(',', "^comma^", F_ENCODE_ARRAY_CHARS);
		setEncodedChars('#', "^hash^", 0);
		setEncodedChars('(', "^lparen^", F_ENCODE_PARENTHESIS);
		setEncodedChars('(', "^rparen^", F_ENCODE_PARENTHESIS);
		setEncodedChars('\n', "^lf^", F_ENCODE_LF);
		setEncodedChars('\r', "^cr^", 0);
		setEncodedChars('\t', "^tab^", 0);
		setEncodedChars('\0', "^null^", 0);
		prepareLookup();
		prepareIsVarChar();
	}
	
	static public void setEncodedChars(char ch, String str, int flag)
	{
		int index = ch;
		_encodedCharsArray[index] = str.toCharArray();
		_encodedCharsStr[index] = str;
		_encodedCharsFlags[index] = F_ENCODE_ALL & ~flag;
	}
	
	static public void prepareLookup()
	{
		for (int i = 0; i < _encodedCharsArray.length; i++)
		{
			char[] chars = _encodedCharsArray[i];
			if (chars != null)
			{
				setFastLookup((char)i, chars);
			}
		}
		// Alternate renderings.
		setFastLookup('^', "^hat^".toCharArray());
		setFastLookup(' ', "^sp^".toCharArray());
		_encodedCharsStr[' '] = "^sp^"; // For prefix and trailing spaces that need encoding.
		setFastLookup('\1', "^eatws^".toCharArray());
	}
	
	static public void setFastLookup(char index, char[] lookupKey)
	{
		int firstCharLookupIndex = lookupKey[1];
		char[] curLookupKey = _fastEncodedCharsLookup[firstCharLookupIndex];
		if (curLookupKey != null)
		{
			int altIndex = _fastEncodedCharsLookupResult[firstCharLookupIndex];
			if (_fastEncodedThirdCharsLookup[altIndex] == null)
			{
				_fastEncodedThirdCharsLookup[altIndex] = new char[128][];
				_fastEncodedThirdCharsLookupResult[altIndex] = new char[128];
			}
			int thirdCharLookup = lookupKey[3];
			_fastEncodedThirdCharsLookup[altIndex][thirdCharLookup] = lookupKey;
			_fastEncodedThirdCharsLookupResult[altIndex][thirdCharLookup] = index;
			_fastNeedsThirdCharLookup[firstCharLookupIndex] = true;
			
		}
		else
		{
			_fastEncodedCharsLookup[lookupKey[1]] = lookupKey;
			_fastEncodedCharsLookupResult[lookupKey[1]] = index;
		}
	}
	
	static public void prepareIsVarChar()
	{
		for (char ch = 'a'; ch <= 'z'; ch++)
		{
			_isVarChar[ch] = true;
		}
		for (char ch = 'A'; ch <= 'Z'; ch++)
		{
			_isVarChar[ch] = true;
		}
		for (char ch = '0'; ch <= '9'; ch++)
		{
			_isVarChar[ch] = true;
		}
		
		_isVarChar['_'] = true;
		_isVarChar['$'] = true;
		_isVarChar[':'] = true;
	}
//+endsection Static initialization	
	
	static public void appendEncodedStr(Appendable appendable, CharSequence str, RdKey key, 
		RdContext cxt, int flags) throws IOException
	{
		int len = str.length();
		char[] array = null;
		Writer w = null;
		if (len > 20 && str instanceof RdCharArray)
		{
			// Worth doing optimization.
			RdCharArray charArray = (RdCharArray)str;
			array = charArray._chars;
		}
		if (appendable instanceof Writer)
		{
			w = (Writer)appendable;
		}
		int start = 0;
		boolean foundNonSpace = false;
		int lastNonSpaceIndex = -1;
		for (int i = 0; i < len; i++)
		{
			char ch = (array != null) ? array[i] : str.charAt(i);
			if ( ch < 128 && _encodedCharsArray[ch] != null && 
				((_encodedCharsFlags[ch] | flags) == F_ENCODE_ALL)	)
			{
				if (array == null || w == null)
				{
					appendable.append(str, start, i);
				}
				else
				{
					w.write(array, start, i - start);
				}
				if (w != null)
				{
					w.write(_encodedCharsArray[ch]);
				}
				else
				{
					appendable.append(_encodedCharsStr[ch]);
				}
				start = i + 1;
			}
			else if (!foundNonSpace && ch < ' ' || (ch == ' ' && i == 0))
			{
				// This should not happen, so we do not make it perform well.
				if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t')
				{
					appendable.append(_encodedCharsStr[ch]);
				}
				else
				{
					appendable.append("^" + (int)ch + "^");
				}
				start = i + 1;
			}
			if (ch > ' ')
			{
				foundNonSpace = true;
				lastNonSpaceIndex = i;
			}
		}
		int startEndSpaceIndex = lastNonSpaceIndex + 1;
		if (start < startEndSpaceIndex)
		{
			if (array == null || w == null)
			{
				appendable.append(str, start, startEndSpaceIndex);
			}
			else
			{
				w.write(array, start, startEndSpaceIndex - start);
			}
		}
		if (start > startEndSpaceIndex)
		{
			startEndSpaceIndex = start;
		}
		if (startEndSpaceIndex < len)
		{
			for (int i = startEndSpaceIndex; i < len; i++)
			{
				// This should not happen, so we do not worry about performance optimization.
				char ch = str.charAt(i);
				if (ch == ' ' && i < len - 1)
				{
					appendable.append(ch);
				}
				else if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t')
				{
					appendable.append(_encodedCharsStr[ch]);
				}
				else
				{
					appendable.append("^" + ch + "^");
				}
			}
		}
	}
	
	static public void appendDecodedStr(Appendable appendable, CharSequence str, int startIndex, int endIndex, RdKey key, 
		RdContext cxt, int flags) throws IOException
	{
		char[] array = null;
		Writer w = null;
		if (str instanceof RdCharArray)
		{
			// Worth doing optimization.
			RdCharArray charArray = (RdCharArray)str;
			array = charArray._chars;
		}
		if (appendable instanceof Writer)
		{
			w = (Writer)appendable;
		}
		boolean foundHat = false;
		boolean resolvingKey = false;
		int resolvingIndex = 0;
		char prevChar = 0;
		boolean needThirdChar = false;
		boolean foundNumChar = false;
		int start = startIndex;
		int foundHatIndex = 0;
		int accumulatedChar = 0;
		char[] activeLookupKey = null;
		boolean resolvedIt = false;
		boolean eatingWs = false;
		char resolvedChar = 0;
		for (int i = startIndex; i < endIndex; i++)
		{
			char ch = (array != null) ? array[i] : str.charAt(i);
			if (eatingWs && ch <= ' ')
			{
				start = i + 1;
				continue;
			}
			eatingWs = false;
			boolean consumedChar = false;
			if (ch >= 128)
			{
				// Cannot continue any active constructions.
				if (resolvingKey || foundHat)
				{
					resolvingKey = false;
					foundHat = false;
					foundNumChar = false;
					accumulatedChar = 0;
					activeLookupKey = null;
					needThirdChar = false;
					resolvingIndex = 0;
				}
			}
			if (foundHat && ch == '^')
			{
				activeLookupKey = _fastEncodedCharsLookup[ch];
				resolvedChar = '^';
				resolvingIndex = 1;
				resolvingKey = true;
				needThirdChar = false;
				foundHat = false;
			}
			if (foundHat)
			{
				// See which character sequence we are starting. The character
				// 'c' needs special handling because it starts three different lookup patterns.
				if (ch >= '0' && ch <= '9')
				{
					foundNumChar = true;
					accumulatedChar = (ch - '0');
					resolvingKey = true;
				}
				else if (ch == '^')
				{
					resolvedIt = true;
					resolvingKey = false;
					resolvedChar = '^';
				}
				else
				{
					activeLookupKey = _fastEncodedCharsLookup[ch];
					resolvedChar = _fastEncodedCharsLookupResult[ch];
					needThirdChar = _fastNeedsThirdCharLookup[ch];
					resolvingIndex = 2;
					resolvingKey = (activeLookupKey != null);
				}
				foundHat = false;
			}
			else if (resolvingKey)
			{
				if (foundNumChar)
				{
					if (ch == '^')
					{
						resolvedIt = true;
						resolvedChar = (char)accumulatedChar;
						foundNumChar = false;
					}
					else if (ch >= '0' && ch <= '9')
					{
						accumulatedChar *= 10;
						accumulatedChar += (ch - '0');
					}
					else
					{
						// Reset, bad number.
						resolvingKey = false;
						foundNumChar = false;
					}
				}
				else if (needThirdChar)
				{
					if (resolvingIndex == 3)
					{
						char[][] altLookups =  _fastEncodedThirdCharsLookup[resolvedChar];
						char[] altLookup = null;
						if (altLookups != null)
						{
							altLookup = altLookups[ch];
						}
						if (altLookup != null)
						{
							activeLookupKey = altLookup;
						}
						if (activeLookupKey[2] != prevChar || activeLookupKey[3] != ch)
						{
							// No match, reset.
							resolvingKey = false;
							resolvingIndex  = 0;
							resolvedChar = 0;
						}
						else
						{
							if (altLookup != null)
							{
								resolvedChar = _fastEncodedThirdCharsLookupResult[resolvedChar][ch];
							}
							if (ch == '^')
							{
								resolvedIt = true;
								resolvingKey = false;
							}
						}
						needThirdChar = false;
					}
					else
					{
						// Still matching key, skip to third character after ^ in activeLookupKey.
						prevChar = ch;
					}
					resolvingIndex++;
				}
				else if (activeLookupKey[resolvingIndex] == ch)
				{
					if (ch == '^')
					{
						// End of key, resolvedChar already set.
						resolvedIt = true;
						resolvingKey = false;
					}
					else
					{
						// Still matching key.
						resolvingIndex++;
					} 
				}
				else
				{
					// No match, reset.
					resolvingKey = false;
					resolvingIndex  = 0;
					resolvedChar = 0;
				}
				if (resolvedIt)
				{
					if (array == null || w == null)
					{
						appendable.append(str, start, foundHatIndex);
					}
					else
					{
						w.write(array, start, foundHatIndex - start);
					}
					if (resolvedChar == '\1' && str.charAt(i - 1) == 's')
					{
						eatingWs = true;
					}
					else
					{
						appendable.append(resolvedChar);
					}
					resolvedIt = false;
					resolvedChar = 0;
					resolvingIndex = 0;
					start = i + 1;
					consumedChar = true;
				}
			}
			if (!foundHat && !resolvingKey && !consumedChar && ch == '^')
			{
				foundHat = true;
				foundHatIndex = i;
			}
		}
		if (start < endIndex)
		{
			if (array == null || w == null)
			{
				appendable.append(str, start, endIndex);
			}
			else
			{
				w.write(array, start, endIndex - start);
			}
		}
	}
	
	/**
	 * Format an array of strings into a comma separated single string.
	 * @param list Array of strings to format.
	 * @param cxt The current context.
	 * @return A string with original items in the list separated by
	 * commas.
	 */
	static String formatList(List<CharSequence> list, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray array = cxt.temporaryAllocateCharArray();
		try
		{
			formatStringList(array, list, ',', cxt);
		}
		catch (IOException ignore)
		{
			// Ignore it completely.
		}
		String result = array.toString();
		cxt.releaseTemporaryAllocatedCharArray(array);
		return result;
	}
	
	static public void formatStringList(Appendable appendable, List<CharSequence> list, char sep, 
		RdContext cxt) throws IOException
	{
		int flags = 0;
		if (sep == ',')
		{
			flags = F_ENCODE_ARRAY_CHARS;
		}
		else if (sep == '\n')
		{
			flags = F_ENCODE_LF;
		}
		else if (sep == ':' || sep == ';' || sep == '=')
		{
			flags = F_ENCODE_MAP_CHARS;
		}
		
		boolean isFirst = true;
		for (CharSequence str : list)
		{
			if (!isFirst)
			{
				appendable.append(sep);
			}
			appendEncodedStr(appendable, str, null, cxt, flags);
			isFirst = false;
		}
	}

	/**
	 * Parses a character sequence an array of strings. This is a convenience
	 * method for when performance is not the greatest consideration.
	 * @param str The character sequence to parse.
	 * @param cxt The current execution context.
	 * @return A list of strings.
	 */
	static public List<String> parseList(CharSequence str, RdContext cxt)
	{
		List<String> retVal = new ArrayList<String>();
		parseStringList(str, ',', retVal, cxt);
		return retVal;
	}
	
	/**
	 * Convenience wrapper for parseList that returns result as an array of strings.
	 * @param str The character sequence to parse.
	 * @param cxt The current execution context.
	 * @return An array of strings.
	 */
	static public String[] parseArray(CharSequence str, RdContext cxt)
	{
		List<String> list = new ArrayList<String>();
		parseStringList(str, ',', list, cxt);
		String[] retVal = new String[list.size()];
		list.toArray(retVal);
		return retVal;
	}

	/**
	 * Parses a character sequence using a given separator. The separator
	 * should be one of the characters that can be encoded by appendEncodedStr.
	 * @param str The character sequence to parse.
	 * @param sepChar The separator character that separates array items. The
	 * separator should be encoded inside the item.
	 * @param list The list to hold the items parsed from the character sequence.
	 * @param cxt The current context.
	 */
	static public void parseStringList(CharSequence str, char sepChar, 
		List<String> list, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		int l = str.length();
		RdCharArray tempArr = cxt.temporaryAllocateCharArray();
		int start = 0;
		for (int i = 0; i < l; i++)
		{
			char ch = str.charAt(i);
			if (ch == sepChar)
			{
				if (i > start)
				{
					tempArr.reset();
					try
					{
						appendDecodedStr(tempArr, str, start, i, null, cxt, 0);
					}
					catch (IOException ignore)
					{
						// Ignore completely (but could be badly thrown memory error, so we abort).
						break;
					}
					list.add(tempArr.toString());
				}
				else
				{
					list.add("");
				}
				start = i + 1;
			}
			
		}
		cxt.releaseTemporaryAllocatedCharArray(tempArr);	
	}
	
	/**
	 * Looks for a substring in a character sequence using the appropriate approach given the
	 * underlying implementation of CharSequence.
	 * @param str The string to scan.
	 * @param seq The pattern to test.
	 * @param start Where the scan starts.
	 * @param len The number of characters to scan
	 * @param flags Flags that control behavior of the test (such as case sensitivity).
	 * @return The starting index where the first pattern match was found or -1.
	 */
	static public int indexOf(CharSequence str, char[] seq, int start, int len, int flags)
	{
		if (str == null || seq == null || seq.length == 0)
		{
			return -1;
		}
		int strLen = str.length();
		if (start >= strLen || start < 0)
		{
			return -1;
		}
		char[] chars = null;
		if (str instanceof RdCharArray)
		{
			RdCharArray array = (RdCharArray)str;
			chars = array._chars;
		}
		int endIndex = start + len;
		if (endIndex > strLen)
		{
			endIndex = strLen;
		}
		int numMatched = 0;
		int retVal = -1;
		for (int i = start; i < endIndex; i++)
		{
			char ch = (chars != null) ? chars[i] : str.charAt(i);
			if (ch == seq[numMatched])
			{
				numMatched++;
				if (numMatched == seq.length)
				{
					retVal = i - seq.length + 1;
					break;
				}
			}
			else
			{
				numMatched = 0;
			}
		}
		return retVal;
	}
	
	/**
	 * Looks for a character in a string using the appropriate approach given the
	 * underlying implementation of CharSequence.
	 * @param str The string to scan.
	 * @param testCh The character to test against.
	 * @param start Where the scan starts.
	 * @return The index where the first character match was found or -1.
	 */
	static public int indexOf(CharSequence str, char testCh, int start)
	{
		if (str == null)
		{
			return -1;
		}
		int strLen = str.length();
		if (start >= strLen || start < 0)
		{
			return -1;
		}
		if (str instanceof String)
		{
			return ((String)str).indexOf(testCh, start);
		}
		char[] chars = null;
		if (str instanceof RdCharArray)
		{
			RdCharArray array = (RdCharArray)str;
			chars = array._chars;
		}
		int endIndex = strLen;
		int retVal = -1;
		for (int i = start; i < endIndex; i++)
		{
			char ch = (chars != null) ? chars[i] : str.charAt(i);
			if (ch == testCh)
			{
				retVal = i;
				break;
			}
		}
		return retVal;
	}
	
	/**
	 * Starts looking for the test character going backwards.
	 * @param str The string to scan
	 * @param testCh The character to look for.
	 * @param index The start position. The scan starts at this position.
	 * If the position is off the end of the string, then
	 * the index is set to the last character in the string when starting.
	 */
	static public int lastIndexOf(CharSequence str, char testCh, int start)
	{
		if (str == null)
		{
			return -1;
		}
		int strLen = str.length();
		if (start < 0)
		{
			return -1;
		}
		if (start >= strLen)
		{
			start = strLen - 1;
		}
		if (str instanceof String)
		{
			return ((String)str).lastIndexOf(testCh, start);
		}
		char[] chars = null;
		if (str instanceof RdCharArray)
		{
			RdCharArray array = (RdCharArray)str;
			chars = array._chars;
		}
		int retVal = -1;
		for (int i = start; i >= 0; i--)
		{
			char ch = (chars != null) ? chars[i] : str.charAt(i);
			if (ch == testCh)
			{
				retVal = i;
				break;
			}
		}
		return retVal;
		
	}
	
	static public RdCharArray createTrimmedRdCharArray(char[] arr, int start, int end)
	{
		while (start < end && arr[start] <= ' ')
			start++;
		while (end > start && arr[end - 1] <= ' ')
			end--;
		if (end <= start)
		{
			return new RdCharArray();
		}
		return new RdCharArray(arr, start, end - start);
	}
	
	/**
	 * This function does a cross locale lower casing that will work reasonably well
	 * in most common locales. A common usage is to attempt to create a canonical file
	 * path for Windows.
	 * @param str The string to lower case.
	 * @cxt The current context.
	 * @return A result that was lower cased in a "locale independent way".
	 */
	static public String convertToGlobalLowerCase(CharSequence str, RdContext cxt)
	{
		String c = str.toString();
		return c.toLowerCase(Locale.ENGLISH);
	}
	
	/**
	 * Tests to see if two strings (CharSequence objects) are identical.
	 * @param str1 The first string.
	 * @param str2 The second string.
	 * @return Returns true if the two strings are identical (in the characters
	 * they hold, not as objects).
	 */
	static public boolean isMatchingStrings(CharSequence str1, CharSequence str2)
	{
		// This is where using CharSequence objects is not so good,
		// knowing the type up front can improve performance significantly
		// in the case where the two strings are actually equal and are
		// fairly long strings. Trying to discover their type probably takes
		// too long for the benefit gained.
		int str1Len = str1.length();
		int str2Len = str2.length();
		if (str1Len != str2Len)
		{
			return false;
		}
		boolean isEqual = true;
		for (int i = 0; i < str1Len; i++)
		{
			if (str1.charAt(i) != str2.charAt(i))
			{
				isEqual = false;
			}
		}
		return isEqual;
	}
	
	/**
	 * Compares two strings over a given range to see if they are identical up to case insensitivity.
	 * This comparison assumes that the strings are 7-bit clean configuration values or keys.
	 * @param str1 The first string to compare. The "start" index only applies to this parameter.
	 * @param str2 The second string to compare. The comparison for this string starts at the
	 * index 0.
	 * @param start Where to start the first string when doing the comparison.
	 * @param len The number of characters to compare.
	 * @return Whether they matched or not.
	 */
	static public boolean matchesRangeIgnoreCase(CharSequence str1, CharSequence str2, int start, 
		int len)
	{
		boolean retVal = true;
		int str1Len = str1.length();
		int str2Len = str2.length();
		int end = start + len;
		int index = 0;
		for (int i = start; i < end; i++)
		{
			if (i >= str1Len || i >= str2Len)
			{
				retVal = false;
				break;
			}
			char ch1 = str1.charAt(i);
			char ch2 = str2.charAt(index++);
			if (ch2 >= 'A' && ch2 <= 'Z')
			{
				ch1 += 'a' - 'A';
			}
			if (ch2 >= 'A' && ch2 <= 'Z')
			{
				ch2 += 'a' - 'A';
			}
			if (ch1 != ch2)
			{
				retVal = false;
				break;
			}
		}
		return retVal;
	}
	
	/**
	 * Tests a pattern against a test string. See isWildCharMatch that takes raw
	 * character arrays for more information.
	 * @param pattern The pattern used to do the test.
	 * @param str The string to do the test.
	 * @param flags Flags to control how the test is done.
	 * @param cxt The current context.
	 * @return Whether the test string satisfies the pattern.
	 */
	static public boolean isWildCardMatch(CharSequence pattern, CharSequence str, int flags,
		RdContext cxt)
	{
		char[] patternChars;
		char[] strChars;
		int plen = pattern.length();
		int slen = str.length();
		if (pattern instanceof RdCharArray)
		{
			patternChars = ((RdCharArray)pattern)._chars;
		}
		else
		{
			patternChars = pattern.toString().toCharArray();
		}
		if (str instanceof RdCharArray)
		{
			strChars = ((RdCharArray)str)._chars;
		}
		else
		{
			strChars = str.toString().toCharArray();
		}
		return isWildCardMatch(patternChars, 0, plen, strChars, 0, slen, flags, cxt);
	}
	
	/**
	 * This method does wild card matching optimized for usage with strings containing a comma
	 * separated list of control flags. It is case insensitive only for the standard A-Z range and generally
	 * only expects simple 7-bit characters. This method was created because of the problems with
	 * the performance/scalability and complexity of the standard Java regular expression matching solution.
	 * @param pattern The pattern compared against the test string. A * matches any number of
	 * characters and a | separates multiple different patterns to test.
	 * @param poffset The offset in the 'pattern' parameter to start at.
	 * @param pend The end index in the 'pattern' parameter. The test will run up to the character
	 * at the index pend - 1.
	 * @param str The test string to check to see if it matches the pattern.
	 * @param soffset The start offset in the string to start the test.
	 * @param send One past the last index to test when testing the pattern.
	 * @param flags Flags that control behavior.
	 * @param cxt The current context.
	 * @return Whether the test string satisfied the requirements of the pattern.
	 */
	static public boolean isWildCardMatch(char[] pattern, int poffset, int pend, 
		char[] str, int soffset, int send, int flags, RdContext cxt)
	{
		int pIndex = poffset;
		boolean inStar = false;
		boolean isMismatched = false;
		boolean didSubMatch = false;
		int sIndex = soffset;
		while (pIndex < pend)
		{
			char ch = pattern[pIndex];
			if (ch == '|' || isMismatched)
			{
				if (isMismatched && (flags & F_DO_FIRST_PATTERN_ONLY) != 0)
				{
					break;
				}
				if (ch == '|')
				{
					// See if we made it to the end of the target string.
					if ((sIndex >= send || inStar) && !isMismatched)
					{
						didSubMatch = true;
						break;
					}
					
					// Start again at beginning of target string.
					isMismatched = false;
					inStar = false;
					sIndex = soffset;
				}
				pIndex++;
			}
			else
			{
				if (ch == '*')
				{
					inStar = true;
					pIndex++;
				}
				else if (sIndex >= send)
				{
					// Went off the end.
					isMismatched = true;
				}
				else
				{
					if (ch >= 'A' && ch <= 'Z')
					{
						ch = (char)(ch + 'a' - 'A');
					}
					char sch = str[sIndex];
					if (sch >= 'A' && sch <= 'Z')
					{
						sch = (char)(sch + 'a' - 'A');
					}
					if (ch == sch)
					{
						if (inStar)
						{
							// Do recursive call.
							int newFlags = flags | F_DO_FIRST_PATTERN_ONLY;
							if (isWildCardMatch(pattern, pIndex + 1, pend, str,
								sIndex + 1, send, newFlags, cxt))
							{
								pIndex = pend;
								sIndex = send;
								break;
							}
							else
							{
								isMismatched = true;
							}
						}
						else
						{
							pIndex++;
						}
						sIndex++;
					}
					else
					{
						if (inStar)
						{
							sIndex++;
						}
						else
						{
							isMismatched = true;
						}
					}
				}
			}
		}
		boolean finishedPattern = (pIndex == pend || didSubMatch);
		boolean retVal = false;
		if (finishedPattern && !isMismatched && (inStar || sIndex >= send))
		{
			retVal = true;
		}
		return retVal;
		
	}
}
