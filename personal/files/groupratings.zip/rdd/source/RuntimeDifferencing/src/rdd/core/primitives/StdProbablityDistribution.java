package rdd.core.primitives;

/**
 * This is copied from code gotten from http://introcs.cs.princeton.edu/java/22library/.
 * The "pdf" is the standard probability distribution function (e to the -x^2 type function).
 * The "cdf" is the the cumulative probability function and it is the integral from
 * negative infinity to the given parameter.
 */
public class StdProbablityDistribution
{
    // return phi(x) = standard Gaussian pdf
    public static double pdfphi(double x) 
    {
        return Math.exp(-x*x / 2) / Math.sqrt(2 * Math.PI);
    }

    // return phi(x, mu, sigma) = Gaussian pdf with mean mu and stddev sigma
    public static double pdfphi(double x, double mu, double sigma) 
    {
        return pdfphi((x - mu) / sigma) / sigma;
    }

    // return Phi(z) = standard Gaussian cdf using Taylor approximation
    public static double cdfPhi(double z) 
    {
        if (z < -8.0) return 0.0;
        if (z >  8.0) return 1.0;
        double sum = 0.0, term = z;
        for (int i = 3; sum + term != sum; i += 2) {
            sum  = sum + term;
            term = term * z * z / i;
        }
        return 0.5 + sum * pdfphi(z);
    }

    // return Phi(z, mu, sigma) = Gaussian cdf with mean mu and stddev sigma
    public static double cdfPhi(double z, double mu, double sigma) 
    {
        return cdfPhi((z - mu) / sigma);
    } 

    // Compute z such that Phi(z) = y via bisection search
    public static double cdfPhiInverse(double y) 
    {
        return cdfPhiInverse(y, .00000001, -8, 8);
    } 

    // bisection search
    private static double cdfPhiInverse(double y, double delta, double lo, double hi) 
    {
        double mid = lo + (hi - lo) / 2;
        if (hi - lo < delta) return mid;
        if (cdfPhi(mid) > y) return cdfPhiInverse(y, delta, lo, mid);
        else              return cdfPhiInverse(y, delta, mid, hi);
    }



    // test client
    public static void main(String[] args) 
    {
        double z     = Double.parseDouble(args[0]);
        double mu    = Double.parseDouble(args[1]);
        double sigma = Double.parseDouble(args[2]);
        System.out.println(cdfPhi(z, mu, sigma));
        double y = cdfPhi(z);
        System.out.println(cdfPhiInverse(y));
    }

}
