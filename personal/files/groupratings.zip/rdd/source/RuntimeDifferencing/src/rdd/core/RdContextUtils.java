package rdd.core;

import java.util.Date;

public class RdContextUtils
{
	static public RdFastKeyLookupInfo _fastKeys = new RdFastKeyLookupInfo("context");
	static public final RdCachedObject NULL_OBJECT = new RdCachedObject(RdGlobalKeys.NULL_KEY, 
		"context", null, null);
	
	/**
	 * Gets the index to use as a parameter to getFastCachedObject.
	 * @see getFastCachedObject
	 * @param key The key to turn into an array index.
	 * @return The index to use for a faster look up of a cached object.
	 */
	static public int getOrRegisterFastContextLookupIndex(RdKey key)
	{
		return _fastKeys.getOrRegisterKeyIndex(key);
	}
	
	/**
	 * Uses the fast cache lookup index to retrieve a cached object in the shared part of
	 * the context.
	 * @param cachedIndex The fast lookup index.
	 * @param cxt The context containing the shared context.
	 * @return The cached object (if it exists).
	 */
	static public Object getFastCachedObject(int cachedIndex, RdContext cxt)
	{
		if (cachedIndex < 0)
		{
			return null;
		}
		
		if (cxt._fastCachedObjectLookup == null || cachedIndex >= cxt._fastCachedObjectLookup.length)
		{
			int numFastKeys = _fastKeys.getNumberOfRegisteredKeys();
			if (cachedIndex >= numFastKeys)
			{
				return null;
			}
			RdCachedObject[] cachedObjects = new RdCachedObject[numFastKeys];
			if (cxt._fastCachedObjectLookup != null)
			{
				System.arraycopy(cxt._fastCachedObjectLookup, 0, cachedObjects, 0, 
					cxt._fastCachedObjectLookup.length);
			}
			cxt._fastCachedObjectLookup = cachedObjects;
		}
		RdCachedObject cObj = cxt._fastCachedObjectLookup[cachedIndex];
		if (cObj == null)
		{
			RdKey key = _fastKeys.getKeyByIndex(cachedIndex);
			Object o = cxt.get(key);
			if (!(o instanceof RdCachedObject))
			{
				cObj = NULL_OBJECT;
			}
			else
			{
				cObj = (RdCachedObject)o;
			}
			cxt._fastCachedObjectLookup[cachedIndex] = cObj;
		}
		return cObj._obj;
	}
	
	/**
	 * The preferred way to set a cached object that is to be shared between threads. 
	 * @param key The key used to reference the object. Access is usually used with a
	 * combination of getOrRegisterFastContextLookupIndex and getFastCachedObject.
	 * @param cxt The context that has the shared data where the object will go.
	 * @param type The general type, used for troubleshooting.
	 * @param o The object to store to be found by other threads in this application.
	 * @param curDate The current date to be used as a timestamp for when the object
	 * was stored. If null, the parameter is created based on the current time.
	 */
	static public void setSharedCachedObject(RdKey key, RdContext cxt, String type, Object o,
		Date curDate)
	{
		if (curDate == null)
		{
			curDate = new Date();
		}
		RdCachedObject sharedWrapper = (RdCachedObject)cxt.get(key);
		if (sharedWrapper == null)
		{
			RdContext sharedContext = cxt.createSharedDataWrapperContext();
			sharedWrapper = new RdCachedObject(key, type, o, curDate);
			sharedContext.put(key, sharedWrapper);
			
			// Update fast keys for this context (other contexts will not get updates
			// so there needs to be turnover in context objects).
			int fastIndex = _fastKeys.getOrRegisterKeyIndex(key);
			if (cxt._fastCachedObjectLookup != null && cxt._fastCachedObjectLookup.length > fastIndex)
			{
				cxt._fastCachedObjectLookup[fastIndex] = sharedWrapper;
			}
		}
		else
		{
			sharedWrapper.setObject(o, curDate);
		}
	}
	
	/**
	 * The preferred way to set string values to be shared among threads.
	 * @param key The look up key for the global value.
	 * @param cxt The context which has references to the shared data inside it.
	 * @param agent The acting agent. Used for debug output.
	 * @param str The string to set.
	 */
	static public void setSharedStringValue(RdKey key, RdContext cxt, String agent, 
		CharSequence str)
	{
		RdContext sharedContext = cxt.createSharedDataWrapperContext();
		sharedContext.put(key, str);
	}

	/**
	 * The preferred way to set string values to be shared among threads.
	 * @param key The look up key for the global value.
	 * @param cxt The context which has references to the shared data inside it.
	 * @param agent The acting agent. Used for debug output.
	 * @param obj The object to set.
	 */
	static public void setSharedObjectValue(RdKey key, RdContext cxt, String agent, 
		Object obj)
	{
		RdContext sharedContext = cxt.createSharedDataWrapperContext();
		sharedContext.put(key, obj);
	}

	
	/**
	 * A utility method to turn a string into a proper RdKey.
	 */
	static public RdKey getKeyForString(CharSequence strKey, RdContext cxt)
	{
		return cxt.getEquivalentKeyObject(strKey, RdContext.F_CREATE_IF_MISSING);
	}
}
