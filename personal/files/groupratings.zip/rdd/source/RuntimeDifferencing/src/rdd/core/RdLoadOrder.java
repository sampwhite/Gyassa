package rdd.core;

import java.util.Map;

import rdd.core.primitives.NumberUtils;
import rdd.core.primitives.StrUtils;

public class RdLoadOrder
{
	//+section Suggested load orders
	static public final RdOrderName BEFORE_FIRST = new RdOrderName("beforefirst", 5);
	static public final RdOrderName FIRST = new RdOrderName("first", 10);
	static public final RdOrderName AFTER_FIRST = new RdOrderName("afterfirst", 15);
	static public final RdOrderName BEFORE_EARLY = new RdOrderName("beforeearly", 50);
	static public final RdOrderName EARLY = new RdOrderName("early", 100);
	static public final RdOrderName AFTER_EARLY = new RdOrderName("afterearly", 150);
	static public final RdOrderName BEFORE_STANDARD = new RdOrderName("beforestandard", 500);
	static public final RdOrderName STANDARD = new RdOrderName("standard", 1000);
	static public final RdOrderName AFTER_STANDARD = new RdOrderName("afterstandard", 1500);
	static public final RdOrderName BEFORE_LAST = new RdOrderName("beforelast", 5000);
	static public final RdOrderName LAST = new RdOrderName("last", 10000);
	static public final RdOrderName AFTER_LAST = new RdOrderName("afterlast", 15000);
	//+endsection Suggested load orders
	
	/**
	 * The named orders. Allows usage of suggestive token names for orders instead of actual
	 * numeric values. Token names are case insensitive and can be adjusted with a + or - of an 
	 * actual integer. Example: BEFOREFIRST - 1 -> 4.
	 */
	static public final RdOrderName[] NAMED_ORDERS = {BEFORE_FIRST, FIRST, AFTER_FIRST,
		BEFORE_EARLY, EARLY, AFTER_EARLY, BEFORE_STANDARD, STANDARD, AFTER_STANDARD,
		BEFORE_LAST, LAST, AFTER_LAST};
	
	/**
	 * Used to specify the order for loading, execution, or sorting. Generally,
	 * the order is sorted from lowest to highest and the lowest are handled first.
	 * So in the case of executing events, the lower order events are executed first.
	 * In the case of calling a "parent" version of a script, the higher order versions
	 * will call the highest version lower than the current version. In table overlays,
	 * the higher order tables will overlay the lower order tables. The overlays will
	 * be processed from lowest to highest (next lowest over lowest, that merge then overlaid
	 * by third lowest and so on).
	 */
	static public RdKey ORDER_KEY = RdGlobalKeys.registerGlobalKey(
		"rdOrder", RdKey.INTEGER);
	
	/**
	 * If no order, is specified, then this is the default order value.
	 */
	static public final RdOrderName DEFAULT_ORDER = STANDARD;
	
	/**
	 * Converts from a string representation to the actual order value.
	 * @param orderString The order as entered by user.
	 * @param cxt Current context.
	 * @return A numeric value used to do sort on.
	 */
	static public int convertToOrder(CharSequence orderString, RdContext cxt)
	{
		int firstRealCharIndex = 0;
		char firstChar = 0;
		int strLen = orderString.length();
		while (firstRealCharIndex < strLen)
		{
			char ch = orderString.charAt(firstRealCharIndex);
			if (ch > ' ')
			{
				firstChar = ch;
				break;
			}
			firstRealCharIndex++;
		}
		if (firstChar == 0)
		{
			return DEFAULT_ORDER._order;
		}
		
		int retVal = DEFAULT_ORDER._order;
		if ((firstChar >= '0' && firstChar <= '9') || firstChar == '-')
		{
			// Simple numerical representation.
			retVal = (int)NumberUtils.parseLong(orderString, retVal);
		}
		else
		{
			boolean foundMatch = false;
			int firstAfterIndex = 0;
			
			// See how expression starts.
			for (RdOrderName name : NAMED_ORDERS)
			{
				int nameLen = name._name.length();
				if (StrUtils.matchesRangeIgnoreCase(orderString, name._name, firstRealCharIndex, 
					nameLen))
				{
					foundMatch = true;
					firstAfterIndex = firstRealCharIndex + nameLen;
					retVal = name._order;
					break;
				}
			}
			
			if (foundMatch)
			{
				// Parse for adjustments.
				boolean foundOperator = false;
				boolean foundNum = false;
				int numIndex = firstAfterIndex;
				boolean isSubtract = false;
				
				for (int i = firstAfterIndex; i < strLen; i++)
				{
					char ch = orderString.charAt(i);
					if (foundOperator)
					{
						if (ch >= '0' && ch <= '9')
						{
							foundNum = true;
							numIndex = i;
							break;
						}
					}
					else if (ch == '-')
					{
						foundOperator = true;
						isSubtract = true;
					}
					else if (ch == '+')
					{
						foundOperator = true;
					}
				}
				if (foundNum)
				{
					int adjust = (int)NumberUtils.parseLong(orderString, numIndex, 
						strLen - numIndex, 0);
					if (isSubtract)
					{
						adjust = -adjust;
					}
					retVal += adjust;
				}
			}
		}
		return retVal;
	}
	
	/**
	 * Implements most common mechanism to get the load order value.
	 * @param m A map object, typically a RdTable.
	 * @param cxt The current context.
	 * @return The converted load order.
	 */
	static public int getLoadOrder(Map<RdKey,Object> m, RdContext cxt)
	{
		CharSequence orderValue = RdDataUtils.getString(m, ORDER_KEY, cxt);
		return convertToOrder(orderValue, cxt);
	}
}
