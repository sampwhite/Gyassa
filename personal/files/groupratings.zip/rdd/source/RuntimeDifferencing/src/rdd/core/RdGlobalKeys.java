package rdd.core;

public class RdGlobalKeys
{
	/** Null key not registered under any lookup string */
	static public final RdKey NULL_KEY = new RdKey("null", RdKey.NULL);

	/**
	 * The column in a table that holds name value pairs that get merged into table at time of table
	 * merging. The column is not actually declared but assumed.
	 */
	static public final RdKey TC_AUTO_ADD = registerGlobalKey("tcAutoAdd", RdKey.MAP);
	
	/**
	 * A column in a table that indicates whether a particular row should be skipped at the time
	 * tables are merged. Essentially the row will become invisible.
	 */
	static public final RdKey TC_DISABLED = registerGlobalKey("trDisabled", RdKey.BOOLEAN);
	
	/**
	 * Method for retrieving a statically declared global key. These keys must only be for
	 * keys that transcend any particular application. Any key registered here will be
	 * visible globally among all applications.
	 * @param keyStr The key string to register as key.
	 * @param type The type of variable represented by the key.
	 * @return The globally unique key registered for a particular string.
	 */
	static public RdKey registerGlobalKey(CharSequence keyStr, int type, int flags)
	{
		RdKey key = RdAppRegistry._globalContext.getEquivalentKeyObject(keyStr, 
			RdContext.F_CREATE_IF_MISSING);
		if ((key._flags & RdKey.F_TYPE_UNRESOLVED) != 0 || 
			(key._flags & RdKey.F_TYPE_EXPLICITLY_DEFINED) == 0)
		{
			synchronized (key)
			{
				// Do it again.
				if ((key._flags & RdKey.F_TYPE_UNRESOLVED) != 0  || 
					(key._flags & RdKey.F_TYPE_EXPLICITLY_DEFINED) == 0)
				{
					key._type = type;
					key._flags &= ~RdKey.F_TYPE_UNRESOLVED;
					key._flags |= RdKey.F_TYPE_EXPLICITLY_DEFINED;
				}
			}
		}
		key._flags |= flags;
		return key;
	}

	/**
	 * See registerGlobalKey that takes flags parameter. This version
	 * passes in 0 for flags parameter.
	 */
	static public RdKey registerGlobalKey(CharSequence keyStr, int type)
	{
		return registerGlobalKey(keyStr, type, 0);
	}

	
}
