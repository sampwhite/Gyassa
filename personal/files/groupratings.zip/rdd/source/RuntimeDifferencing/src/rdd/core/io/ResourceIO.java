package rdd.core.io;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;

import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdData;
import rdd.core.RdException;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdParsingState;
import rdd.core.logger.RP;
import rdd.core.resource.RdParseMapWrapper;
import rdd.core.resource.RdResourceFormat;

public class ResourceIO
{
	/**
	 * Reads resources from a file into the current local data context of the passed in wrapper context.
	 * @param cxt A wrapper context holding local data that is to be read in. It is typical to do a "push" on
	 * the context before making this method call and then using "pop" to get the resource data.
	 * @param path The physical file path that holds the resources.
	 * @param flags Rules on how parsing should be handled and how file should be handled.
	 */
	public static void readResourceFile(RdContext cxt, CharSequence path, int flags) throws IOException, RdException
	{
		Map<RdKey,Object> data = cxt.getLocalData();
		Reader r;
		try
		{
			r = IoUtils.openBufferedReader(path, IoUtils.F_USE_DEFAULTS);
		}
		catch (IOException originalException)
		{
			// Maybe original resource file is not available, try temp file instead.
			// This can sometimes help with error recovery.
			CharSequence tempPath = createTempPath(path, cxt);
			File tempFile = new File(tempPath.toString());
			if (!tempFile.exists())
			{
				throw originalException;
			}
			r = IoUtils.openBufferedReader(tempPath, IoUtils.F_USE_DEFAULTS);
		}
		RdParsingState state = new RdParsingState(path, cxt);
		if (data instanceof RdData)
		{
			RdData rdData = (RdData)data;
			rdData.parse(r, state, cxt, flags);
		}
		else
		{
			RdCharArray chArray = cxt.temporaryAllocateCharArray();
			IoUtils.readAllChars(r, chArray, cxt);
			RdParseMapWrapper mapWrapper = new RdParseMapWrapper(data, 0);
			RdResourceFormat.parseMap(chArray._chars, 0, chArray._len, '=', '\n', mapWrapper, 
				state, 0, 0);
			cxt.releaseTemporaryAllocatedCharArray(chArray);
		}
		if (state._failed)
		{
			if (state._error == null)
			{
				// This should never happen.
				state._error = new RdException("rdceFailedToParseFile", path);
			}
			throw state._error;
		}
	}
	
	/**
	 * Writes resources to a file using the current local data context of the passed in wrapper context.
	 * This method is far more complex then it might first appear and its current approach is
	 * based on interactions with 100s of customers over a diverse set of file systems.
	 * It is rare to find network storage solutions that truly support scalable fast turn over
	 * of data being stored in the same location. This comment even applies to well known
	 * databases which can sometimes slow down drastically as they try to keep up with all
	 * the "deletes/replaces". These issues usually manifest when doing billions of transactions steadily
	 * over many weeks and using queue files or tables to track "state of 100s of worker threads on
	 * 10s of machines".
	 * @param cxt A wrapper context holding local data that is to be written. It is typical to do a "push" on
	 * the context before making this method call and then using "pop" to reset the data.
	 * @param path The physical file path that holds the resources.
	 * @param flags Rules on how formatting should be handled and how file should be handled.
	 */
	public static void writeResourceFile(RdContext cxt, CharSequence path, int flags) 
		throws IOException, RdException
	{
		Map<RdKey,Object> data = cxt.getLocalData();
		CharSequence tempPath = createTempPath(path, cxt);
		Writer w = IoUtils.openBufferedWriter(tempPath, IoUtils.F_USE_DEFAULTS);
		
		try
		{
			RdResourceFormat.formatKeyMap(w, data, cxt, RdGlobalKeys.NULL_KEY, 0, flags);
		}
		finally
		{
			IoUtils.closeIoObjectNoException(w);
		}
		
		// This is the fragile part of the code because some shared file systems
		// tend to do a bad job of notifying client processes of directory
		// changes and whether a file is truly available. 
		IoUtils.renameTo(tempPath, path, 0, cxt);
	}
	
	static public CharSequence createTempPath(CharSequence path, RdContext cxt)
	{
		int l = path.length();
		RdCharArray retVal = new RdCharArray();
		retVal.prepareForAppend(l + 5);
		try
		{
			FilePathUtils.appendSplicedFileName(retVal, path, "@temp", cxt);
		}
		catch (IOException e)
		{
			RP.errT(e);
		}
		return retVal;
	}
}
