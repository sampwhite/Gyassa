package rdd.core.primitives;

public class NumberUtils
{
	static public long parseLong(CharSequence str, long defVal)
	{
		return parseLong(str, 0, str.length(), defVal);
	}
	
	static public long parseLong(CharSequence str, int offset, int len, long defVal)
	{
		if (len <= 0)
		{
			return defVal;
		}
		
		// Place holder for more efficient logic later.
		CharSequence parseStr = str.subSequence(offset, offset + len);
		if (parseStr == null || parseStr.length() == 0)
		{
			return defVal;
		}
		return Long.parseLong(parseStr.toString());
	}
}
