package rdd.core.storage;

import java.util.Date;
import java.util.Map;

import rdd.core.RdCommonKeys;
import rdd.core.RdContext;
import rdd.core.RdContextUtils;
import rdd.core.RdData;
import rdd.core.RdDataUtils;
import rdd.core.RdErrorCodes;
import rdd.core.RdException;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdTable;
import rdd.core.RdTableField;
import rdd.core.RdTableIndex;
import rdd.core.RdTableUtils;
import rdd.core.logger.RP;
import rdd.security.RdUserUtils;

public class RdFileListUtils
{
	//+section File listings
	static public RdKey FILE_LIST_TABLE_KEY = RdGlobalKeys.registerGlobalKey("FileListing",
		RdKey.TABLE);
	static public int FAST_FILE_LISTING_CACHES_LOOKUP_INDEX = -1;
	static public RdKey FILE_LISTING_KEY = RdGlobalKeys.registerGlobalKey(
		"FileListingCache", RdKey.COMPLEX);
	static public RdKey LAST_EDIT_DATE = RdGlobalKeys.registerGlobalKey(
		"rdLastEditDate", RdKey.DATE);
	//+endsection File listings
	
	
	
	//+section Columns of file list table 
	/**
	 * A reference to the file that specifies the location of the file relative
	 * to the component directory (or inside the component "jar" file if that
	 * is being used). If the reference is stored in a table in the database
	 * then the component name followed by a slash is prefixed to this
	 * reference path to create the primary key for the entry.
	 */
	static public RdKey FILE_REFERENCE_PATH = RdGlobalKeys.registerGlobalKey(
		"rdFileReferencePath", RdKey.STRING);
	
	/**
	 * The usage type of file or directory. This entry is free form and uses
	 * wild card matching to determine what options are active. Standard options are:
	 * data - Contains data loaded and saved on demand.
	 * boot - Data is loaded at boot time and put into configuration data using
	 * overlay rules. This data cannot be reloaded dynamically.
	 * init - Data is loaded if component is active and put into configuration
	 * using data rules, otherwise it is ignored. This data can be dynamically
	 * reloaded.
	 * definition - Data is loaded at boot time but is stored as information
	 * about the file listing and the component and is not loaded into the
	 * global space for name value pairs, scripts, and tables.
	 */
	static public RdKey FILE_USAGE_TYPE = RdGlobalKeys.registerGlobalKey(
		"rdFileUsageType", RdKey.STRING);
	
	/**
	 * Flags specifying what field values are present and other options
	 * about this particular file (whether it is a directory and
	 * what options it might support).
	 */
	static public RdKey STORAGE_FLAGS = RdGlobalKeys.registerGlobalKey(
		"rdStorageFlags", RdKey.INTEGER);
	
	/**
	 * The object that captures information about the file in an object
	 * optimized for Java access. In particular, it captures component
	 * information and connection information as well. This object
	 * is not persisted into persistent storage.
	 */
	static public RdKey FILE_INFO = RdGlobalKeys.registerGlobalKey(
		"rdFileInfo", RdKey.STRING, RdKey.F_IS_NOT_SERIALIZABLE);
	//+endsection Columns of file list table

	static public void init(RdContext cxt)
	{
		FAST_FILE_LISTING_CACHES_LOOKUP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(FILE_LISTING_KEY);
	}

	static public void addSupplementaryFileListColumns(RdTable table, RdContext cxt)
	{
		table.addField(FILE_INFO, RdTableField.F_SUPPLEMENTARY_DATA);
	}
	
	static public RdFileList createEmptyFileList(RdStorageParameters params, RdContext cxt)
	{
		RdData data = new RdData();
		RdTable table = new RdTable(new RdKey[]{FILE_REFERENCE_PATH,
			FILE_USAGE_TYPE, RdCommonKeys.TRANSACTION_COUNTER, STORAGE_FLAGS, 
			RdCommonKeys.LAST_MODIFIED, RdCommonKeys.LAST_MODIFIED_USER});
		try
		{
			fillInFileInfoField(table, params, cxt);
		}
		catch (Exception e)
		{
			RP.errT(e);
		}
		data.put(FILE_LIST_TABLE_KEY, table);
		return new RdFileList(table, data);
	}
	
	static public RdFileList createFileListFromData(Map<RdKey,Object> data, RdStorageParameters params,
		RdContext cxt) throws RdException
	{
		RdFileList retList = null;
		RdData fileListData = (RdData)cxt.getLocalData();
		RdTable table = RdDataUtils.getTable(fileListData, RdFileListUtils.FILE_LIST_TABLE_KEY, 
			cxt);
		if (table != null)
		{
			RdFileListUtils.fillInFileInfoField(table, params, cxt);
			retList = new RdFileList(table, fileListData);
		}
		return retList;
	}
	
	static public void fillInFileInfoField(RdTable table, RdStorageParameters params, 
		RdContext cxt) throws RdException
	{
		addSupplementaryFileListColumns(table, cxt);
		int fileInfoIndex = table.getTableFieldIndex(FILE_INFO);
		for (int i = 0; i < table._rows.size(); i++)
		{
			table.setCurrentRowIndex(i);
			RdFileInfo fileInfo = createFileInfoFromRow(table, params, cxt);
			table.putDirectByIndex(fileInfoIndex, fileInfo);
		}
		RdTableUtils.createSimpleFieldIndex(table, RdFileListUtils.FILE_REFERENCE_PATH, cxt, 
			RdTableIndex.F_CASE_INSENSITIVE);
	}
	
	static public RdFileInfo createFileInfoFromRow(RdTable table, RdStorageParameters params,
		RdContext cxt) throws RdException
	{
		
		CharSequence referencePath = RdDataUtils.getString(table, FILE_REFERENCE_PATH, cxt);
		RdFileInfo fileInfo = new RdFileInfo(params._connectionData, params._component, 
			referencePath.toString());
		fileInfo._usageType = RdDataUtils.getS(table, FILE_USAGE_TYPE, cxt);
		fileInfo._flags = RdDataUtils.getInteger(table, STORAGE_FLAGS, 0, cxt);
		fileInfo._transactionCounter = RdDataUtils.getInteger(table, RdCommonKeys.TRANSACTION_COUNTER, 
			0, cxt);
		Date lastModifiedDate = RdDataUtils.getDate(table, RdCommonKeys.LAST_MODIFIED, cxt);
		if (lastModifiedDate != null)
		{
			fileInfo._lastModified = lastModifiedDate.getTime();
		}
		fileInfo._lastModifiedUser = RdDataUtils.getString(table, 
			RdCommonKeys.LAST_MODIFIED_USER, cxt).toString();
		return fileInfo;
	}
	
	static public RdFileInfo findFileInfo(RdFileList list, RdStorageParameters params, 
		String relativePath, RdContext cxt)
	{
		// Allow for other threads to "edit" this list for when the list is
		// retrieved from cache.
		synchronized (list._fileListTable)
		{
			RdTable fileRow = RdTableUtils.getSimpleIndexedTableByKey(list._fileListTable, 
				FILE_REFERENCE_PATH, relativePath, 0, cxt);
			if (fileRow == null)
			{
				return null;
			}
			fileRow._currentRow = 0;
			return (RdFileInfo)RdDataUtils.getComplexObject(fileRow, FILE_INFO, cxt);
		}
	}
	
	
	
	static public void addOrUpdateFileToWorkingFileInfo(RdStorageParameters params,
		String relativePath, int fileInfoFlags, RdContext cxt) throws RdException
	{
		if (params._workingFileList == null)
		{
			params._workingFileList = createEmptyFileList(params, cxt);
			params._hasWorkingFileList = true;
		}
		updateFileInfo(params._workingFileList, params, relativePath, fileInfoFlags, cxt);
	}
	
	static public void updateFileInfo(RdFileList list, RdStorageParameters params,
		String relativePath, int fileInfoFlags, RdContext cxt) throws RdException
	{
		// Allow for other threads to "edit" this list for when the list is
		// retrieved from cache.
		synchronized (list._fileListTable)
		{
			if ((params._formattingAndStorageOptionsFlags & RdContext.F_CREATE_STORAGE_ENTRY_ONLY) != 0)
			{
				// Do a paranoia existence test. (in theory we should have already tested
				// this and thrown the error before getting here).
				RdTable fileRow = RdTableUtils.getSimpleIndexedTableByKey(list._fileListTable, 
					FILE_REFERENCE_PATH, relativePath, 0, cxt);
				if (fileRow != null)
				{
					throw new RdException(RdErrorCodes.RESOURCE_ALREADY_EXISTS,
						"rdceReplacingFileThatIsNotSupposedToExist", params._component._name,
						relativePath);
				}
				
			}
			
			RdTable updateRow = list._fileListTable.shallowDesignClone();
			updateRow.createAndSetToNewEndRow();
			updateRow.put(FILE_REFERENCE_PATH, relativePath);
			String usageType = (params._usageType != null) ? params._usageType : "data";
			updateRow.put(FILE_USAGE_TYPE, usageType);
			updateRow.put(RdCommonKeys.TRANSACTION_COUNTER, new Long(params._transactionCounter));
			updateRow.put(RdCommonKeys.LAST_MODIFIED, new Date());
			fileInfoFlags |= RdFileInfo.F_HAS_TRANSACTION_COUNTER | RdFileInfo.F_HAS_LAST_MODIFIED;
			CharSequence user = cxt.getS(RdUserUtils.USER_LOOKUP_KEY);
			if (user.length() > 0)
			{
				updateRow.put(RdCommonKeys.LAST_MODIFIED_USER, user);
				fileInfoFlags |= RdFileInfo.F_HAS_LAST_CHANGE_USER;
			}
			else
			{
				updateRow.put(RdCommonKeys.LAST_MODIFIED_USER, "system");
			}
			updateRow.put(STORAGE_FLAGS, new Long(fileInfoFlags));
			RdFileInfo fileInfo = createFileInfoFromRow(updateRow, params, cxt);
			updateRow.put(FILE_INFO, fileInfo);
			RdTableUtils.mergeCompatibleTablesOnKey(FILE_REFERENCE_PATH, list._fileListTable,
				updateRow, 0, cxt);
		}
	}
}
