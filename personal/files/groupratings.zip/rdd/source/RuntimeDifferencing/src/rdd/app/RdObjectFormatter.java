package rdd.app;

import java.io.IOException;

import rdd.core.RdContext;
import rdd.core.RdDataUtils;
import rdd.core.logger.RP;
import rdd.core.primitives.ObjectFormatter;

/**
 * Formatter of objects for this application when presented to end user.
 */
public class RdObjectFormatter implements ObjectFormatter
{

	@Override
	public void appendFormattedObject(Appendable appendable, Object obj, RdContext cxt, int flags)
	{
		try
		{
			RdDataUtils.appendTo(appendable, obj, null, 0, cxt, flags);
		}
		catch (IOException e)
		{
			RP.errT(e);
		}
	}

}
