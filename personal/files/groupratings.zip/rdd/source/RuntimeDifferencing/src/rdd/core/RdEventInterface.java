package rdd.core;

/**
 * The base interface class that makes an object be able to handle events.
 * We use an interface instead of reflection in some cases for performance considerations.
 */
public interface RdEventInterface
{
	//+section Return values for handle event
	static public final int CONTINUE = 0;
	static public final int DONE = 1;
	static public final int ABORT = -1;
	//+endsection Return values for handle event
	/**
	 * Called before events are handled on this object but after
	 * a lot of initialization of the application has occurred.
	 */
	public void init(RdContext cxt) throws RdException;
	
	/**
	 * Implemented by a global object that handles an event.
	 */
	public int handleEvent(RdEventRegistration eventRegistration, RdEventParams params, 
		RdContext cxt) throws RdException;
	
	/**
	 * Called when this handler is being notified that the class loader that was
	 * called to instantiate it is being released to the garbage collector.
	 */
	public void applicationRelease(RdContext cxt);
}
