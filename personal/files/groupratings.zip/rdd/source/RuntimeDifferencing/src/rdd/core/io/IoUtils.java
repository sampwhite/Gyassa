package rdd.core.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdErrorCodes;
import rdd.core.RdException;
import rdd.core.logger.RP;
import rdd.core.primitives.SyncUtils;

public class IoUtils
{
	static public int STANDARD_READ_AMOUNT = 2048;
	static public int STANDARD_LARGE_FILE_WRITE_BUFFER = 4096;
	
	//+section Creation, renaming, deletion, reading and writing flags
	static public int F_USE_DEFAULTS = 0;
	static public int F_APPEND = 1;
	static public int F_VERIFY_RENAME = 2;
	static public int F_VERIFY_DELETE = 4;
	static public int F_RENAME_CANNOT_DELETE_TARGET = 8;
	static public int F_RENAME_USES_COPY = 16;
	//+endsection Reading and writing flags

	static public String _workingDir = createDefaultWorkingDirectory();

	static public int readChars(Reader reader, RdCharArray array, RdContext cxt, int numChars) throws IOException
	{
		if (reader == null)
		{
			return -1;
		}
		array.prepareForAppend(numChars);
		int nread = reader.read(array._chars, array._len, numChars);
		if (nread > 0)
		{
			array._len += nread;
		}
		return nread;
	}
	
	static public void readAllChars(Reader reader, RdCharArray array, RdContext cxt) throws IOException
	{
		int nread = -1;
		array.prepareForAppend(STANDARD_READ_AMOUNT);
		while ((nread = reader.read(array._chars, array._len, STANDARD_READ_AMOUNT)) > 0)
		{
			array._len += nread;
			array.prepareForAppend(STANDARD_READ_AMOUNT);
		}
	}
	
	static public Reader openBufferedReader(CharSequence path, int flags) throws IOException
	{
		File file = new File(path.toString());
		return openBufferedReader(file, flags);
	}

	static public Reader openBufferedReader(File file, int flags) throws IOException
	{
		InputStream in = new FileInputStream(file);
		Reader r = new InputStreamReader(in, "UTF8");
		return new BufferedReader(r);
	}
	
	static public Writer openBufferedWriter(CharSequence path, int flags) throws IOException
	{
		File file = new File(path.toString());
		return openBufferedWriter(file, flags);
	}

	static public Writer openBufferedWriter(File file, int flags) throws IOException
	{
		boolean append = (flags & F_APPEND) != 0;
		OutputStream out = new FileOutputStream(file, append);
		Writer w = new OutputStreamWriter(out, "UTF8");
		return new BufferedWriter(w);
	}

	/**
	 * Creates a "beautified" and consistent full path from a directory and relative sub path. This
	 * method coerces path names into using Unix forward slashes to create consistency. Generally,
	 * full paths should be created using this method before files are opened so that error
	 * reporting can use consistent file path styles.
	 * 
	 * One of the problems is that relative paths are usually built up to get at application data in
	 * subdirectories and it is a real inconvenience to worry about whether to use forward or
	 * backward slashes when doing these constructions. The RDD project tries to solve this problem
	 * by always using forward slashes (which also work well when used in building up URL paths).
	 * 
	 * @param dir
	 *            The directory parent (can be null, to use working directory as default).
	 * @param name
	 *            The path under the directory. If this parameter is actually an absolute path then
	 *            the parameter 'dir' is ignored and only this parameter is used to build the path.
	 * @param cxt
	 *            The current context of the caller.
	 * @param flags
	 *            Whether the path created should be a directory or physical file path.
	 * @return A full well formed file path.
	 */
	static public String createAbsolutePath(CharSequence dir, CharSequence name, 
		RdContext cxt, int flags)
	{
		if (dir == null)
		{
			dir = _workingDir;
		}
		String path;
		if (FilePathUtils.isAbsolutePath(name))
		{
			path = FilePathUtils.normalizeFilePath(name, cxt, flags);
		}
		else
		{
			if (cxt == null)
			{
				cxt = RdAppRegistry.getThreadWrapperContext();
			}
			RdCharArray tempArray = cxt.temporaryAllocateCharArray();
			try
			{
				tempArray.append(dir);
				int len = tempArray._len;
				if (len == 0 || tempArray._chars[len - 1] != '/')
				{
					tempArray.append('/');
				}
				tempArray.append(name);
			}
			catch (Throwable ignore)
			{
				RP.errT(ignore);
			}
			path = FilePathUtils.normalizeFilePath(tempArray, cxt, FilePathUtils.F_USE_DEFAULTS);
		}
		return path;
	}
	
	static public String createDefaultWorkingDirectory()
	{
		String workingDir = System.getProperty("user.dir");
		if (!FilePathUtils.isAbsolutePath(workingDir))
		{
			if (workingDir == null)
			{
				workingDir = "./";
			}
			File f = new File(workingDir);
			workingDir = f.getAbsolutePath();
		}
		return FilePathUtils.normalizeFilePath(workingDir, null, FilePathUtils.F_IS_DIR);
	}
	
	/**
	 * Convenience method that is commonly used.
	 * @param path Path to check for file existence.
	 * @return Whether the OS reports the file to exist. Permission issues may obscure the truth.
	 */
	static public boolean fileExists(CharSequence path)
	{
		File f = new File(path.toString());
		return f.exists();
	}
	
	/**
	 * Closes a standard IO object and suppresses the exception.
	 * @param o The object to close.
	 */
	static public void closeIoObjectNoException(Object o)
	{
		if (o == null)
		{
			return;
		}
		try
		{
			if (o instanceof InputStream)
			{
				((InputStream)o).close();
			}
			else if (o instanceof OutputStream)
			{
				((OutputStream)o).close();
			}
			else if (o instanceof Reader)
			{
				((Reader)o).close();
			}
			else if (o instanceof Writer)
			{
				((Writer)o).close();
			}
			else if (o instanceof Socket)
			{
				((Socket)o).close();
			}
			else
			{
				RP.reportMessage("system", RP.TRACE, 
					"IoUtils.closeIoObjectNoException: No object to close", new Throwable(), null);
			}
		}
		catch (Exception e)
		{
			RP.errT(e);
		}
	}
	
	/**
	 * It is so typical to close two IO objects at the same time, that a convenience method is useful.
	 * @param o1 First IO object to close.
	 * @param o2 Second IO object to close.
	 */
	static public void closeTwoIoObjectsNoException(Object o1, Object o2)
	{
		closeIoObjectNoException(o1);
		closeIoObjectNoException(o2);
	}
	
	static public void checkOrCreateDirectories(CharSequence dirPath, int numParents, int flags, 
		RdContext cxt) throws RdException
	{
		if (numParents > 0)
		{
			CharSequence parentDir = FilePathUtils.getParent(dirPath);
			if (parentDir != null)
			{
				checkOrCreateDirectories(parentDir, numParents - 1, flags, cxt);
			}
		}
		
		File f = new File(dirPath.toString());
		if (!f.exists())
		{
			if (!f.mkdir())
			{
				throw new RdException("rdceUnableToCreateDirectory", dirPath);
			}
		}
	}
	
	static public void checkOrCreateSubDirectory(CharSequence dirPath, CharSequence subDir, 
		int flags, RdContext cxt) throws RdException
	{
		if (dirPath == null || dirPath.length() == 0 || subDir == null || subDir.length() == 0)
		{
			return;
		}
		
		int numSlashes = 0;
		RdCharArray path = new RdCharArray();
		
		try
		{
			path.append(dirPath);
			char lastChar = dirPath.charAt(dirPath.length() - 1);
			if (lastChar != '/' && lastChar != '\\')
			{
				path.append('/');
			}
			
			// Count slashes (collapsing) ones that follow right after each other).
			int len = subDir.length();
			boolean prevCharIsSlash = true; // Ignore slash on first character.
			for (int i = 0; i < len; i++)
			{
				char ch = subDir.charAt(i);
				if (ch == '/' || ch == '\\')
				{
					if (!prevCharIsSlash)
					{
						numSlashes++;
						prevCharIsSlash = true;
					}
					if (i == len - 1)
					{
						// Trailing slashes don't count.
						numSlashes--;
					}
				}
				else
				{
					prevCharIsSlash = false;
				}
			}
			path.append(subDir);
		}
		catch (IOException ignore)
		{
			RP.errT(ignore);
		}
		if (numSlashes >= 0)
		{
			checkOrCreateDirectories(path, numSlashes, flags, cxt);
		}
	}
	
	/**
	 * This method renames from one file path to another. This seemingly simple call
	 * has many complications and can be a point of unusual failure when network based
	 * file systems start behaving erratically when under stress. The fragility of
	 * this method is one of the biggest reasons for using databases for file storage (or
	 * use "database" like mechanics where there is a layer of indirection from the client's
	 * name of the file to the actual name of the physical file).
	 * 
	 * If at some time we get access at the native API calls for doing "hardlinks", then
     * doing a "hardlink" to the new location has better transaction mechanics. But some
	 * of the badly behaved shared file systems don't implement "hardlinks" properly so
	 * that strategy has limited utility as well.
	 * 
	 * @param fromPath The path to rename from.
	 * @param toPath The new location for the file.
	 * @param flags Controls the rename operation. In particular the F_RENAME_USES_COPY
	 * needs to be set if the copy is across disk volumes.
	 * @param cxt The current context.
	 * @throws RdException
	 */
	static public void renameTo(CharSequence fromPath, CharSequence toPath, int flags,
		RdContext cxt) throws RdException
	{
		File from = new File(fromPath.toString());
		File to = new File(toPath.toString());
		boolean success = false;
		boolean renameUsesCopy = (flags & F_RENAME_USES_COPY) != 0;
		for (int i = 0; i < 3; i++)
		{
			boolean originalFilePresent = to.exists();
			if (originalFilePresent)
			{
				// Try to make sure we are not fooled by a file name
				// that is in transition. Sometimes you can rename a file
				// and will report that it is at its original and new location
				// if you ask in the correct order and ask fast enough (Windows
				// which has non transaction file renames is prone to this problem).
				if (i > 0)
				{
					boolean fromExists = from.exists();
					if (fromExists)
					{
						SyncUtils.sleep(2, cxt);
						
						if (i == 1)
						{
							// First retry we are at maximum paranoia that
							// the method calls we are making are lying
							// to us. We really want to avoid deleting
							/// file we just renamed. Start over.
							continue; 
						}
						fromExists = from.exists();
					}
					if (!fromExists)
					{
						SyncUtils.sleep(1, cxt);
						success = to.exists();
						break;
					}
				}
				
				if ((flags & F_RENAME_CANNOT_DELETE_TARGET) != 0)
				{
					throw new RdException(RdErrorCodes.RESOURCE_ALREADY_EXISTS, 
						"rdceTargetFileForRenameExists", to);
				}
				
				// There are way too many ways for this method to fail or to report
				// back incorrectly. A common reason is that the file is open in a text
				// editor on a Windows system or has been closed but Windows has not
				// yet processed the close request (or synced with this client).
				to.delete();
			}
			if (i > 0 || renameUsesCopy)
			{
				if (originalFilePresent && to.exists())
				{
					// Our delete request did not happen. Wait a bit.
					SyncUtils.sleep(2, cxt);
					continue;
				}
				else if (!renameUsesCopy)
				{
					if (!from.exists())
					{
						success = true;
						break;
					} 
					if (i > 1)
					{
						renameUsesCopy = true;
					}
				}
			}
			if (renameUsesCopy)
			{
				try
				{
					// This approach is reliable but slow (the slowness
					// is what likely makes it reliable).
					InputStream in = new FileInputStream(from);
					OutputStream out = new FileOutputStream(to);
					copyStreams(in, out, cxt);
					from.delete();
					success = true;
					break;
				}
				catch (IOException e)
				{
					throw new RdException(e, "rdceFilesCouldNotBeCopied",
						from, to);
				}
			}
			else
			{
				if (from.renameTo(to))
				{
					// Provisional success.
					success = true;
				}
			}
			
			if (i > 0)
			{
				SyncUtils.sleep(2, cxt);
			}
			if (!from.exists())
			{
				break;
			}
			success = false;
			SyncUtils.sleep(1, cxt);
		}
		if (!success)
		{
			if (from.exists() && to.exists())
			{
				throw new RdException("rdceFileCouldNotBeDeleted", to);
			}
			throw new RdException("rdceFileRenameFailed", from, to);
		}
		
	}
	
	static public void copyStreams(InputStream in, OutputStream out,
		RdContext cxt) throws IOException
	{
		byte[] buf = new byte[STANDARD_LARGE_FILE_WRITE_BUFFER];
		int nread = -1;
		while ((nread = in.read(buf)) > 0)
		{
			out.write(buf, 0, nread);
		}
	}
	
	/**
	 * A simple test utility method. Used to verify file systems.
	 * @param path The path to the file which will get the message.
	 * @param msg The message to write.
	 */
	static public void createFileWithMessage(CharSequence path, CharSequence msg) throws RdException
	{
		Writer w;
		CharSequence parentDir = FilePathUtils.getParent(path);
		if (parentDir == null || parentDir.length() < 5)
		{
			throw new RdException("rdceFilePathHasNoProperParentDirectory", path);
		}
		try
		{
			w = openBufferedWriter(path, F_USE_DEFAULTS);
		}
		catch (IOException e)
		{
			// See if we can figure out more.
			if (fileExists(path))
			{
				// A security issue mostly likely.
				throw new RdException(e, "rdceFileIsLockedFromAccess", path);
			}
			if (IoUtils.fileExists(parentDir))
			{
				// Just could not create file.
				throw new RdException(e, "rdceCouldNotCreateFile", path);
			}
			throw new RdException(e, "rdceParentDirectoryForFileDoesNotExist", path);
		}
		try
		{
			w.append(msg);
			w.close();
		}
		catch (IOException e)
		{
			throw new RdException(e, "rdceCouldNotWriteToFile", path);
		}
	}
}
