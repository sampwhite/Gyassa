package rdd.security;

import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;

public class RdUserUtils
{
	// Stub class for now.
	static public RdKey USER_LOOKUP_KEY = RdGlobalKeys.registerGlobalKey("RdUser", 
		RdKey.COMPLEX, RdKey.F_IS_NOT_SERIALIZABLE);

}
