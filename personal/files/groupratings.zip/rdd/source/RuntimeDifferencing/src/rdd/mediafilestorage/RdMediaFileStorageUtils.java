package rdd.mediafilestorage;

import rdd.core.RdContext;
import rdd.core.RdEventUtils;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdLoadOrder;
import rdd.core.RdTable;
import rdd.core.storage.RdStorage;

public class RdMediaFileStorageUtils
{
	static public RdKey MEDIA_DIRECTORIES =  RdGlobalKeys.registerGlobalKey(
		"MediaDirectories", RdKey.ARRAY, 0);
	

	static public RdKey HAS_DEVELOPER_DIRECTORIES = RdGlobalKeys.registerGlobalKey(
		"HasDeveloperDirectories", RdKey.BOOLEAN, 0);
	static public RdKey DEVELOPER_DIRECTORIES =  RdGlobalKeys.registerGlobalKey(
		"DeveloperDirectories", RdKey.ARRAY, 0);


	static public RdTable createEventRegistrationTable(RdContext cxt)
	{
		return new RdTable(
			new RdKey[]{
				RdEventUtils.EVENT_REGISTRATION_ID, 
				RdEventUtils.EVENT_IDS,
				RdEventUtils.EVENT_HANDLER_CLASSS,
				RdLoadOrder.ORDER_KEY},
			new Object[][]{{
			"mediastorage",
			RdStorage.getEventListAsString(),
			"rdd.mediastorage.RdMediaFileStorage",
			RdLoadOrder.EARLY}});
	}

}
