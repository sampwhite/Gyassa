package rdd.core.storage;

import java.io.InputStream;
import java.io.OutputStream;

import rdd.core.RdData;
import rdd.core.RdEventId;
import rdd.core.component.RdComponentDefinition;

/**
 * This is the class that holds the work in progress for a storage request. It is acted on by many
 * event hooks and event hooks can sign off on the work that has been done. The same
 * RdStorageParameters object should NOT be used for requests to different component directories.
 * Once a directory listing has been computed for this object it is considered to be the complete
 * list of referenceable files until the start of the next transaction (lock called).
 * This object is NOT thread safe and should not be shared among threads.
 */
public class RdStorageParameters
{
	//+section Input Flags
	static public final int F_IS_DB_TABLE = 1;
	static public final int F_IS_READ_ONLY_ACTION = 2;
	static public final int F_ALWAYS_ALLOW_REPLACE = 4;
	//+endsection Input flags
	
	//+section Output Flags
	static public final int F_CREATED_INPUT_STREAM = 1;
	static public final int F_CREATED_OUTPUT_STREAM = 2;
	static public final int F_READING_FROM_LOCAL_FILESYSTEM_CACHE = 4;
	static public final int F_USING_DEVELOPMENT_DIRECTORY = 8;
	//+endsection
	
	//+section Input data
	/**
	 * The component being accessed. This attribute should not be modified once set. It is a
	 * required parameter to be supplied by the caller.
	 */
	public RdComponentDefinition _component;
	
	/**
	 * A sub directory that is locked instead of the component.
	 * This attribute should only be set when the sub directory is specially designed to
	 * handle large amounts of content. Once set it should not change.
	 */
	public String _listingSubDir; 
	
	/**
	 * The file or directory being accessed.
	 */
	public String _relativePath;
	
	/**
	 * The usage type of the file being accessed (if it is a file). This parameter
	 * is only consulted if the file is being created or updated. See
	 * RdFileListUtils.FILE_USAGE_TYPE for more.
	 */
	public String _usageType;

	/**
	 * If request is actually a database table request, then this is the table.
	 */
	public String _tableDataSource;
	
	/**
	 * If the table is being treated as simple storage, then this is the primary key value.
	 * In particular, a "select for update" is performed on the row to start a transaction
	 * lock on the particular row when "lockDirectory" is called.
	 */
	public String _primaryKeyValue; // Used to do locks on _tableDataSource.
	
	/**
	 * Indicates whether the caller has explicitly set the in flags and does not
	 * want defaults used for the appropriate storage call.
	 */
	public boolean _inFlagsSet;
	
	/**
	 * Flags controlling usage. See Input Flags above.
	 */
	public int _inFlags;
	//+endsection Input data
	
	//+section Output data (do not modify outside of API calls)
	public boolean _transactionCounterRetrieved;
	public long _transactionCounter;
	public boolean _targetedResourceExits;
	public boolean _fromCache;
	public InputStream _inStream;
	public OutputStream _outStream;
	public String _relativePathUsed;
	public boolean _fileInfoRetrieved;
	public RdFileInfo _fileInfo;
	public RdFileList _directoryListing;
	public int _outFlags;
	public String _lockKey;
	public boolean _isLocked;
	public int _lockCount;
	//+endsection Output data
	
	//+section Internal data
	public RdConnectionData _connectionData;
	public int _extraIncrementCount;
	public long _nextTransactionCounter;
	public int _timeOutForLockInSeconds;
	public boolean _fileIsBeingAccessed;
	public boolean _lockAcquired;
	public boolean _lockReleased;
	public boolean _useDirectFileSystemAccess;
	public boolean _isMediaComponent;
	public boolean _isReadOnlyData;
	public int _formattingAndStorageOptionsFlags;
	public boolean _cacheFileIsAvailable;
	public boolean _storageEventPrepared;
	public boolean _computedLockPath;
	public boolean _retrievedWorkingFileList;
	public boolean _hasWorkingFileList;
	public RdFileList _workingFileList;
	public RdData _additionalData;
	public boolean _handledMainEvent;
	public RdEventId _mainTopLevelEvent;
	public boolean _componentPathComputed;
	public String _componentPath;
	public boolean _computedListPath;
	public String _listingPath;
	public String _resourceFilePath;
	//+endsection Internal data
	
	public RdStorageParameters()
	{
		_additionalData = new RdData();
	}
	
	public RdStorageParameters(RdComponentDefinition component, String relativePath)
	{
		setFileLocation(component, relativePath);
		_additionalData = new RdData();
	}
	
	public void setFileLocation(RdComponentDefinition component, String relativePath)
	{
		_component = component;
		_relativePath = relativePath;
	}
	
	public void resetForNextFile()
	{
		_fileIsBeingAccessed = false;
		_cacheFileIsAvailable = false;
		_targetedResourceExits = false;
		_relativePathUsed = null;
		_usageType = null;
		_useDirectFileSystemAccess = false;
		_resourceFilePath = null;
		_fileInfoRetrieved = false;
		_fileInfo = null;
		_formattingAndStorageOptionsFlags = 0;
		_isReadOnlyData = false;
	}
	
	public void resetForTransactionStart()
	{
		resetForNextFile();
		_transactionCounterRetrieved = false;
		_transactionCounter = -1;
		_directoryListing = null;
		_retrievedWorkingFileList = false;		
		_hasWorkingFileList = false;
		_workingFileList = null;
		_lockReleased = false;
		_isReadOnlyData = false;
	}
	
	public void checkResetForNextFile()
	{
		if (_relativePathUsed == null || _relativePath == null ||
			!(_relativePathUsed.equals(_relativePath)))
		{
			resetForNextFile();
		}
	}
	
	public void prepareForRead()
	{
		if (!_lockAcquired && !_inFlagsSet)
		{
			_inFlags |= F_IS_READ_ONLY_ACTION;
		}
	}
	
	public void prepareForWrite()
	{
		if (!_inFlagsSet)
		{
			_inFlags &= ~F_IS_READ_ONLY_ACTION;
		}
	}
}
