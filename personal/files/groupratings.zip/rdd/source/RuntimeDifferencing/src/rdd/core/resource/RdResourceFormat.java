package rdd.core.resource;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdData;
import rdd.core.RdDataUtils;
import rdd.core.RdException;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdMessage;
import rdd.core.RdParseMapCallback;
import rdd.core.RdParsingState;
import rdd.core.RdResourceDefinition;
import rdd.core.RdResourceFormatError;
import rdd.core.RdResourceKey;
import rdd.core.RdResourceLocator;
import rdd.core.RdResourceProperties;
import rdd.core.RdResourceTypes;
import rdd.core.RdResourceUtils;
import rdd.core.RdTable;
import rdd.core.RdTableUtils;
import rdd.core.RdValue;
import rdd.core.io.IoUtils;
import rdd.core.primitives.StrUtils;

public class RdResourceFormat
{
	//+section Resource line parsing flags
	static public final int F_NO_BODY = 1;
	static public final int F_HAS_NAME = 2;
	//+endsection Resource line parsing flags
	
	//+section Writing out resources
	static public void appendResource(RdResourceDefinition res, Map<RdKey,Object> values, Appendable appendable, RdKey parentKey, 
		Set<RdKey>alreadyProcessedKeys, int depth, RdContext cxt, int flags) throws IOException
	{
		// First look for the simple case.
		int resType = res._resKey._resourceType;
		if (resType == RdResourceTypes.TEXT)
		{
			if ((flags & RdContext.F_IS_NOT_FIRST) != 0)
			{
				// Make things a little prettier.
				appendable.append('\n');
			}
			appendable.append(res._text);
			appendable.append('\n');
			return;
		}
		
		// Temporary arrays to use.
		RdCharArray tempValArray = cxt.temporaryAllocateCharArray();
		RdCharArray tempPropsArray = cxt.temporaryAllocateCharArray();
		
		// See if we wish to handle strings in a special way to compact presentation.
		RdKey key = (res._key != null) ? res._key : RdResourceUtils.RESOURCE_KEY;
		boolean isNameValue =  false;
		boolean valueInData = (resType == RdResourceTypes.NAMEVALUE || resType == RdResourceTypes.TABLE ||
			resType == RdResourceTypes.DATA || resType == RdResourceTypes.MAP);
		Object val = null;
		CharSequence cVal = null;
		CharSequence propsVal = null;
		boolean hasText = false;
		boolean encodeVal = false;
		boolean textHasLineFeeds = false;
		int suggestedValType = RdKey.STRING;
		boolean desHasLineFeeds = false;
		boolean textUsesCompactForm = false;
		boolean desUsesCompactForm = false;
		boolean propsValEmpty = res._properties == null;
		if (valueInData)
		{
			val = values.get(res._key);
			if (alreadyProcessedKeys != null)
			{
				alreadyProcessedKeys.add(res._key);
			}
			suggestedValType = RdDataUtils.determineBestFitValueType(key, val);
			encodeVal = suggestedValType <= RdKey.DATE; // The other types have string representations that are still encoded.
			if (suggestedValType >= RdKey.NULL && suggestedValType <= RdKey.MAP)
			{
				// The value is always written as a single line of text.
				isNameValue = resType != RdResourceTypes.MAP;
				hasText = true;
				
				// We can coerce to string.
				// Do easy cases first.
				if (val instanceof CharSequence)
				{
					cVal = (CharSequence)val;
				}
				else if (val instanceof RdValue)
				{
					RdValue rVal = (RdValue)val;
					cVal = rVal._sVal;
					encodeVal = (rVal._type <= RdKey.DATE);
				}
				if (cVal == null)
				{
					// Do hard cases. 
					tempValArray.reset();
					RdDataUtils.appendTo(tempValArray, val, key, depth + 1, cxt, flags);
					cVal = tempValArray;
					
					// Note, cVal is presumed to contain properly encoded text without any line feeds. There are
					// scenarios where this does not work.
					encodeVal = false;
				}
			}
		}
		else
		{
			hasText = RdResourceTypes.hasText(resType);
			if (hasText)
			{
				if (res._parsedObject != null)
				{
					if (res._parsedObject instanceof CharSequence)
					{
						cVal = (CharSequence)res._parsedObject;
					}
					else
					{
						tempValArray.reset();
						RdDataUtils.appendTo(tempValArray, val, key, depth + 1, cxt, flags);
						cVal = tempValArray;
					}
				}
				else
				{
					cVal = res._text;
				}
				encodeVal = (resType != RdResourceTypes.HIDDEN);
			}
		}

		// See if our computed value for resource type is wrong.
		resType = RdResourceTypes.determineResourceTypeFromValueType(suggestedValType, resType);

		if (resType == RdResourceTypes.STRING || resType == RdResourceTypes.MAP || isNameValue)
		{
			if (res._properties != null)
			{
				tempPropsArray.reset();
				res._properties.appendTo(tempPropsArray, key, depth, cxt, flags);
				if (tempPropsArray.length() > 0)
				{
					propsVal = tempPropsArray;
				}
			}
			if (cVal != null)
			{
				textHasLineFeeds = StrUtils.indexOf(cVal, '\n', 0) >= 0;
			}
			if (res._description != null)
			{
				desHasLineFeeds = StrUtils.indexOf(res._description, '\n', 0) >= 0;
			}
			int textLen = (cVal != null) ? cVal.length() : 0;
			int desLen = (res._description != null) ? res._description.length() : 0;
			int keyLen = res._resKey._resourceName.length();
			propsValEmpty = propsVal == null || propsVal.length() == 0;
			int propsLen = (!propsValEmpty) ? propsVal.length() + 2 : 0;
			
			int fullTextLen = textLen + keyLen + propsLen + 1;
			if (fullTextLen < 40)
			{
				textUsesCompactForm = true;
			}
			else if (!textHasLineFeeds && fullTextLen < StrUtils._preferredLineLen)
			{
				textUsesCompactForm = true;
			}
			if (textUsesCompactForm && !desHasLineFeeds && desLen > 0)
			{
				if (fullTextLen + desLen + 1 < StrUtils._preferredLineLen)
				{
					desUsesCompactForm = true;
				}
			}
		}
		
		boolean prependDescription = res._description != null && !desUsesCompactForm;
		if (prependDescription)
		{
			if ((flags & RdContext.F_IS_NOT_FIRST) != 0)
			{
				appendable.append('\n');
			}
			appendAddCommentHashes(appendable, res._description, 0, res._description.length());
		}
		
		String resourceTypeStr = RdResourceTypes.getResourceLabel(resType);
		
		// See if we wish to use compact form for name values or strings.
		if (!textUsesCompactForm || !isNameValue || !propsValEmpty)
		{
			if (!prependDescription && resType > RdResourceTypes.STRING && (flags & RdContext.F_IS_NOT_FIRST) != 0)
			{
				// Make things look a little prettier.
				appendable.append('\n');
			}
			appendable.append('^');
			appendable.append(resourceTypeStr);
			appendable.append(' ');
		}
		appendable.append(res._resKey._resourceName);
		if (!propsValEmpty)
		{
			appendable.append('[');
			if (propsVal != null)
			{
				appendable.append(propsVal);
			}
			else
			{
				res._properties.appendTo(appendable, key, depth, cxt, flags);
			}
			appendable.append(']');
		}
		
		if (textUsesCompactForm)
		{
			appendable.append('=');
		}
		else
		{
			if (desUsesCompactForm)
			{
				appendable.append(" # ");
				appendable.append(res._description);
			}
			appendable.append('\n');
		}
		if (hasText)
		{
			if (cVal != null)
			{
				if (encodeVal)
				{
					int encodeFlags =  (textUsesCompactForm) ? StrUtils.F_ENCODE_LF : 0;
					StrUtils.appendEncodedStr(appendable, cVal, key, cxt, encodeFlags);
				}
				else
				{
					appendable.append(cVal);
				}
			}
		}
		else if (valueInData)
		{
			RdDataUtils.appendTo(appendable, val, key, depth + 1, cxt, flags);
		}
		if (textUsesCompactForm)
		{
			if (desUsesCompactForm)
			{
				appendable.append(" # ");
				appendable.append(res._description);
			}
			appendable.append('\n');
		}
		else if ((hasText || valueInData))
		{
			String endTag = (resType == RdResourceTypes.HIDDEN) ? "\n^endhidden\n" : "\n^end\n";
			appendable.append(endTag);
		}
		
		cxt.releaseTemporaryAllocatedCharArray(tempValArray);
		cxt.releaseTemporaryAllocatedCharArray(tempPropsArray);
	}
	//+endsection Writing out resources
	
	//+section Reading in resources
	
	/**
	 * This method is the entry point for parsing resources from a file or stream. The parsing logic tries to avoid "look ahead" logic
	 * that is the more common way to do such parsing. In "look ahead" logic, certain trigger characters are found, and then there is
	 * forward scan of the buffer to see if one of the allowable constructs is being started. The problem with this approach is that
	 * if the scan runs off the end of the current buffer, you then need to read in more of the buffer and this can create logical
	 * messes. The other problem is that it can be a bit inefficient since you are constantly "trying" out "look ahead" patterns
	 * as you walk through the stream. Also, "look ahead" logic is awkward when dealing with tracking current line and column position
	 * in a file.
	 * 
	 * Instead this parsing logic maintains current state about what type of construct is being found. At no point are previous or later
	 * characters consulted to determine how to act. The problem with this approach is that it creates a lot of local variables and complex
	 * logic transitions as various state boolean variables are set to true or false. In theory, the code could be broken up into smaller
	 * method chunks by putting the local variables into structures (there are comment blocks on the local variables that suggest how 
	 * this might be done) and then making method calls for different types of logic handling. This would make for better code, but it
	 * would be significantly slower because handling each character would involve invoking at least one method call (and probably more)
	 * to handle it. This method may have a lot of code, but it is very FAST code because it only uses Java primitives that can be executed
	 * in just a few CPU cycles. One way of viewing this code is seeing it as "manually compiled assembly" (for those who don't remember, assembly
	 * is the output of a compiler when it compiles C code).
	 * 
	 * @param reader The character stream that streams the resources to be parsed.
	 * @param resources Resources that are successfully parsed are added to this array. Text between defined resources are considered
	 * to be resources as well. This way a close approximate to the original stream can be created.
	 * @param state The current state. Used to track file name, file position, and error handling. The method does not
	 * throw an exception on error, instead it returns quietly and sets an error state into this parameter. This means the IOException
	 * is logically pure and this method can be invoked without logical complications by call back methods that can only throw IOExceptions.
	 * @flags Flags to control how parsing is done.
	 * @param cxt The context that most RDD core methods require.
	 */
	static public void parseResources(Reader reader, List<RdResourceDefinition> resources, RdParsingState state, RdContext cxt, int flags) 
		throws IOException
	{
		RdParsingState allocatedState = null;
		if (state == null)
		{
			allocatedState = new RdParsingState("<stream>", cxt);
			state = allocatedState;
		}
	
		// Buffers
		RdCharArray inChars = state._inChars;
		RdCharArray bufChars = state._copyBuffer;
		bufChars.prepareForAppend(IoUtils.STANDARD_READ_AMOUNT);
		char[] copyBuffer = bufChars._chars;
		int inPos = state._inCharsPos;
		int copyPos = 0;
		
		// Whether we are inside a variable or resource.
		int varStartsPos = 0;
		boolean insideVariableName = false;
		boolean readToEndOfLine = false;
		boolean insideResource = false;
		
		// End of body detection.
		char[] endSequence = null;
		int endSeqCounter = 0;
		boolean inEndSequence = false;
		
		// Whether to add a resource and offsets in buffer to use when creating resource.
		boolean addResource = false;
		boolean inResourceLineDeclaration = false;
		int resoureDefStartPos = 0;
		int startDescriptionMarker = 0;
		int endOfTextPos = 0;
		int copyBodyResourceStartIndex = 0;
		boolean startDescriptionMarkerIsLocked = false;
		boolean resourceBodyFinished = false;
		
		// Resource information.
		RdResourceDefinition res = null;
		boolean varIsResourceType = false;
		
		// Where in file to find resource.
		int startOfResourceCol = state._col;
		int startOfResourceLineNum = state._line;
		int startOfTextCol = state._col;
		int startOfTextLineNum = state._line;
		int startResBodyLine = 0;
		
		// Line handling
		boolean isEmptyLine = false;
		int prevLineEndPos = 0;
		int lineParsingFlags = 0;
		int line = state._line;
		int col = state._col;
		
		// The main loop.
		boolean hasMore = true;
		while (!state._failed && hasMore)
		{
			if (inChars._len <= inPos)
			{
				// Note: It is quite possible that reader is null, and inChars already holds the entire stream, in which
				// case this method will return -1.
				hasMore = IoUtils.readChars(reader, inChars, cxt, IoUtils.STANDARD_READ_AMOUNT) > 0;
			}
			char[] chars = (hasMore) ? inChars._chars : StrUtils.TWO_LINE_FEEDS._chars;
			int end = (hasMore) ? inChars._len : 1;
			if (!hasMore)
			{
				inPos = 0;
			}
			
			while (inPos < end)
			{
				boolean lineEnded = false;
				char ch = chars[inPos];
				if (readToEndOfLine)
				{
					if (ch == '\n')
					{
						readToEndOfLine = false;
						lineEnded = true;
					}
					else if (ch > ' ')
					{
						isEmptyLine = false;
					}
				}
				else
				{
					if (insideResource)
					{
						if (inEndSequence)
						{
							boolean continueSearch = false;
							if (ch == endSequence[endSeqCounter++])
							{
								if (endSeqCounter == endSequence.length)
								{
									int endBodyPos = prevLineEndPos;
									RdResourceFormat.parseResourceData(res, startResBodyLine, 0,
										state._depth, copyBuffer, copyBodyResourceStartIndex, endBodyPos, 
										state, cxt, 0);
									resourceBodyFinished = true;
									state._needsEndTag = false;
								}
								else
								{
									continueSearch = true;
								}
							}
							if (!continueSearch)
							{
								inEndSequence = false;
								endSeqCounter = 0;
								readToEndOfLine = true;
								endSequence = null;
							}
							if (state._failed)
							{
								break;
							}
						}
						else if (ch == '^')
						{
							inEndSequence = true;
						}
						else if (ch > ' ')
						{
							// No chance that resource body will end here.
							readToEndOfLine = true;
						}
					}
					else // !insideResource -- Looking for a resource tag.
					{
						boolean isInvalidChar = false;
						if (ch < 128 && (StrUtils._isVarChar[ch] || ch == ':'))
						{
							isEmptyLine = false;
							if (!insideVariableName)
							{
								if (ch >= '0' && ch <= '9')
								{
									// Cannot start with a number.
									isInvalidChar = true;
								}
								else
								{
									varStartsPos = copyPos;
									insideVariableName = true;
								}
							}
						}
						else if (insideVariableName)
						{
							// Variable name has ended, did it end with a legal character.
							if (ch > ' ' && ch != '=' && ch != '[')
							{
								isInvalidChar = true;
							}
							else
							{
								// We are inside a resource declaration.
								inResourceLineDeclaration = true;
								resoureDefStartPos = copyPos;
								endOfTextPos = prevLineEndPos;
								startOfResourceCol = col;
								startOfResourceLineNum = line;
								
								// See if this character terminated the line.
								if (ch == '\n')
								{
									lineEnded = true;
								}
								else
								{
									readToEndOfLine = true;
								}
								insideVariableName = false;
							}
						}
						else
						{
							if (ch == '^')
							{
								varStartsPos = copyPos + 1;
								insideVariableName = true;
								varIsResourceType = true;
								isEmptyLine = false;
							}
							else if (ch > ' ')
							{
								// This line is not going to hold a resource start tag or name equal value pair.
								isEmptyLine = false;
								readToEndOfLine = true;
							}
						}
						if (isInvalidChar)
						{
							// Bad variable name. If started, with a ^, this is fatal.
							if (varIsResourceType)
							{
								createErrorMessageIntoParsingState(state, 
									"rdceParsingInvalidResourceTypeCharacter", line, col, "" + ch);
							}
							else
							{
								// Ignore this line of text.
								insideVariableName = false;
								readToEndOfLine = true;
							}
							break;
						}
					}
				} // if (readToEndOfLine)
				if (lineEnded && inResourceLineDeclaration)
				{
					boolean isResource = true;
					if (!varIsResourceType)
					{
						// See if legitimately formed name=value pair.
						for (int i = resoureDefStartPos; i < copyPos; i++)
						{
							char resCh = copyBuffer[i];
							if (resCh == ' ')
							{
								continue;
							}
							isResource = (resCh == '=' || resCh == '[');
							break;
						}
					}
					String resName = null;
					if (isResource)
					{
						resName = new String(copyBuffer, varStartsPos, resoureDefStartPos - varStartsPos);
					}
					if (isResource && varIsResourceType && resName.equals("description") && !startDescriptionMarkerIsLocked)
					{
						isResource = false;
						startDescriptionMarker = copyPos + 1;
						startDescriptionMarkerIsLocked = true;
					}
					if (isResource)
					{
						int resType = RdResourceTypes.NAMEVALUE;
						lineParsingFlags = 0;
						state._needsEndTag = false;
						
						String curResName = resName;
						if (varIsResourceType)
						{
							resType = RdResourceTypes.determineResourceTypeFromTypeName(resName);
							if (resType < 0)
							{
								resType = RdResourceTypes.STRING;
								lineParsingFlags |= F_HAS_NAME;
							}
							else
							{
								// Name not yet known.
								curResName = null;
							}
						}
						else
						{
							resType = RdResourceTypes.NAMEVALUE;
							lineParsingFlags |= (F_HAS_NAME | F_NO_BODY);
						}
						RdResourceKey resKey = RdResourceUtils.getOrCreateResourceKey(resType, curResName);
						res = new RdResourceDefinition(resKey, state._locator);
						res._location._line = startOfResourceLineNum;
						res._location._col = startOfResourceCol;
						parseResourceLine(res, state._depth, copyBuffer, resoureDefStartPos, copyPos, state, cxt, lineParsingFlags);
						if (state._failed)
						{
							break;
						}
						if (state._needsEndTag)
						{
							// Still need to parse body.
							insideResource = true;
							copyBodyResourceStartIndex = copyPos + 1;
							startResBodyLine = line + 1;
							RdCharArray endArray = RdResourceTypes.getTerminationSequence(resKey._resourceType);
							endSequence = endArray._chars;
						}
						else
						{
							// Finished resource.
							addResource = true;
						}
					}
					inResourceLineDeclaration = false;
				} // if (lineEnded && inResourceLineDeclaration)
				if (lineEnded && resourceBodyFinished)
				{
					addResource = true;
				}
				if (ch != '\r')
				{
					if (copyPos >= copyBuffer.length)
					{
						bufChars.realloc(copyPos + (end - inPos));
						copyBuffer = bufChars._chars;
					}
					copyBuffer[copyPos] = ch;
					bufChars._len = copyPos + 1;
					bufChars._toStringCache = null;
					if (ch == '\n')
					{
						if (isEmptyLine && !insideResource && !startDescriptionMarkerIsLocked)
						{
							// Two line feeds in a row (one of which may have followed spaces and one # character).
							startDescriptionMarker = copyPos + 1;
						}

						line++;
						col = 0;
						prevLineEndPos = copyPos; 
						isEmptyLine = true;
					}
					else
					{
						col++;
					}
					copyPos++;
				}
				if (addResource)
				{
					// Determine description part and create text resource that comes before.
					if (!res._descriptionIsInLine && startDescriptionMarker + 3 < endOfTextPos)
					{
						// Can look for description before resource.
						RdCharArray des = new RdCharArray();
						des.prepareForAppend(endOfTextPos - startDescriptionMarker);
						appendRemoveCommentHashes(des, bufChars, startDescriptionMarker, endOfTextPos);
						res._description = des;
						endOfTextPos = startDescriptionMarker - 2;
					}
					if (endOfTextPos > 2)
					{
						CharSequence parsedText = createLineFeedTrimmedText(copyBuffer, 0, endOfTextPos);
						if (parsedText.length() > 0)
						{
							RdResourceDefinition textResource = new RdResourceDefinition(
								RdResourceUtils.TEXT_RESOURCE_KEY, state._locator);
							textResource._text = parsedText;
							textResource._location._line = startOfTextLineNum;
							textResource._location._col = startOfTextCol;
							resources.add(textResource);
						}
					}
					resources.add(res);
					res = null;
					if (state._failed)
					{
						break;
					}
					insideResource = false;
					if (reader != null && hasMore && inPos >  10 * IoUtils.STANDARD_READ_AMOUNT && (end - inPos) < inPos)
					{
						inChars.leftShift(inPos);
						end = inChars._len;
						inPos = 0;
					}
					
					// Finish off line and start on next resource.
					copyPos = 0;
					bufChars._len = 0;
					endSequence = null;
					insideResource = false;
					resourceBodyFinished = false;
					addResource = false;
					varIsResourceType = false;
					startDescriptionMarker = 0;
					startDescriptionMarkerIsLocked = false;
					startOfTextCol = col;
					startOfTextLineNum = line;
					prevLineEndPos = 0;
					endOfTextPos = 0;
				}
				
				// Increment for next round.
				inPos++;
			} // while (inPos <= end)
		} // while (!state._failed && hasMore)
		
		// See if we have a trailing text resource.
		if (!state._failed && copyPos > 0)
		{
			// See if we don't have an end tag for a resource.
			if (res != null && insideResource)
			{
				createErrorMessageIntoParsingState(state, "rdceUnterminatedResource", 
					res._location._line, res._location._col, res._resKey);
			}
			else
			{
				// Make a final text block.
				CharSequence parsedText = createLineFeedTrimmedText(copyBuffer, 0, copyPos);
				if (parsedText.length() > 0)
				{
					RdResourceDefinition textResource = new RdResourceDefinition(
						RdResourceUtils.TEXT_RESOURCE_KEY, state._locator);
					textResource._text = parsedText;
					textResource._location._line = startOfTextLineNum;
					textResource._location._col = startOfTextCol;
					resources.add(textResource);
				}
			}
		}
		if (allocatedState != null)
		{
			allocatedState.release();
		}
		state._line = line;
		state._col = col;
		
	}

	/**
	 * This method may mutate the contents of "buf" slightly. Parses a resource declaration line.
	 * It can be as simple as something of the form:
	 * 
	 * XX=YY #comment
	 * 
	 * or as complex as
	 * 
	 * ^table sampletable[mergeKey=sampleKey2]
	 * 
	 * @param res
	 * @param buf
	 * @param startPos
	 * @param endPos
	 * @param state
	 * @param flags
	 */
	static public void parseResourceLine(RdResourceDefinition res, int depth, char[] array, int startPos, int endPos, 
		RdParsingState state, RdContext cxt, int flags) throws IOException
	{
		boolean foundName = (flags & F_HAS_NAME) != 0;
		
		// Value
		boolean afterEquals = false;
		int startValPos = 0;
		int endValPos = 0;
		int startValLine = 0;
		int startValCol = 0;
		boolean foundStartVal = false;
		boolean foundEndVal = false;
		
		// Name
		int startNamePos = 0;
		boolean foundStartName = false;
		
		// Parameters
		int startParamsPos = 0;
		int paramsStartLine = res._location._line;
		int paramsStartCol = res._location._col;
		boolean foundStartParams = false;
		
		// Description
		boolean foundStartDescription = false;
		int startDescriptionPos = 0;
		boolean foundDescriptionMarker = false;
		
		// Trim whitespace at end
		int lastNonSpace = startPos;
		
		// Line and column location.
		int line = paramsStartLine;
		int col = paramsStartCol;
		
		for (int i = startPos; i <= endPos; i++)
		{
			// Have a fake line feed at end so we close out most constructs.
			char ch = (i < endPos) ? array[i] : '\n';
			if (!foundDescriptionMarker)
			{
				if (afterEquals)
				{
					if (ch == '#' && lastNonSpace + 1 < i)
					{
						foundDescriptionMarker = true;
						if (foundStartVal)
						{
							foundEndVal = true;
							endValPos = lastNonSpace + 1;
						}
					}
					else if (!foundStartVal && ch > ' ')
					{
						startValPos = i;
						startValLine = line;
						startValCol = col;
						foundStartVal = true;
					}
				}
				else if (!foundName)
				{
					boolean isInvalidChar = false;
					if (ch < 128 && (StrUtils._isVarChar[ch] || ch == ':'))
					{
						if (!foundStartName)
						{
							if (ch >= '0' && ch <= '9')
							{
								isInvalidChar = true;
							}
							else
							{
								foundStartName = true;
								startNamePos = i;
							}
						}
					}
					else if (ch <= ' ' || ch == '=' || ch == '[')
					{
						if (foundStartName)
						{
							String resName =  new String(array, startNamePos, i - startNamePos);
							RdResourceKey newResKey= RdResourceUtils.getOrCreateResourceKey(
								res._resKey._resourceType, resName);
							res._resKey = newResKey;
							foundName = true;
							foundStartName = false;
							if (ch == '=')
							{
								afterEquals = true;
							}
							else if (ch == '[')
							{
								foundStartParams = true;
								startParamsPos = i + 1;
								paramsStartLine = line;
								paramsStartCol = col + 1;
							}
						}
						else if (ch == '=' || ch == '[')
						{
							isInvalidChar = true;
						}
					}
					else
					{
						isInvalidChar = true;
					}
					if (isInvalidChar)
					{
						createErrorMessageIntoParsingState(state, "rdceParsingInvalidResourceNameCharacter", line, col, "" + ch);
						break;
					}
				}
				else if (foundStartParams)
				{
					if (ch == ']')
					{
						// Parse map.
						RdResourceProperties resProps = new RdResourceProperties();
						parseMap(array, startParamsPos, i, '=', ';', resProps, state, paramsStartLine, paramsStartCol);
						if (state._failed)
						{
							break;
						}
						res._properties = resProps;
						foundStartParams = false;
					}
				}
				else // !afterEquals && foundName && !foundStartParams
				{
					if (ch == '=')
					{
						afterEquals = true;
					}
					else if (ch == '[')
					{
						foundStartParams = true;
						startParamsPos = i + 1;
						paramsStartLine = line;
						paramsStartCol = col + 1;
					}
				} // if (afterEquals)
			}
			else // We have found the description.
			{
				if (!foundStartDescription)
				{
					if (ch > ' ')
					{
						foundStartDescription = true;
						startDescriptionPos = i;
					}
				}
			} // if (!foundDescriptionMarker)
			if (ch == '\n')
			{
				line++;
				col = 0;
			}
			else
			{
				col++;
			}
			if (ch > ' ')
			{
				lastNonSpace = i;
			}
		}
		
		RdResourceKey resourceKey = res._resKey;
		if (resourceKey == null)
		{
			resourceKey = RdResourceUtils.TEXT_RESOURCE_KEY;
		}
		int resType = resourceKey._resourceType;
		String resName =  resourceKey._resourceName;
		if (!state._failed && foundStartParams)
		{
			// Parameters have closure character.
			createErrorMessageIntoParsingState(state, "rdceParseUnclosedKeyParameters", paramsStartLine, paramsStartCol);
		}
		if (!state._failed && RdResourceTypes.resourceMustHaveName(resType) && !foundName)
		{
			createErrorMessageIntoParsingState(state, "rdceParseResourceHasNoName", res._location._line, 
				res._location._col);
		}
		if (!state._failed)
		{
			boolean hasBody = false;
			if (RdResourceTypes.isDataValue(res._resKey._resourceType))
			{
				// Value types are more specific than resource types, but changing resource types
				// when processing values has more drastic consequences (a table object is
				// quite different from a map).
				RdKey resVarKey = cxt.getEquivalentKeyObject(resName, RdContext.F_CREATE_IF_MISSING);
				int curVarResType = RdResourceTypes.determineResourceTypeFromValueType(resVarKey._type,
					RdResourceTypes.NAMEVALUE);
				if (resType != curVarResType)
				{
					int valType = RdResourceTypes.determineValueTypeFromResourceType(resType, RdKey.STRING);
					boolean typeDefined = (resVarKey._flags & RdKey.F_TYPE_UNRESOLVED) == 0;
					boolean explicitTypeDefined = (resVarKey._flags & 
						RdKey.F_TYPE_EXPLICITLY_DEFINED) != 0;
					if (!explicitTypeDefined)
					{
						// Can change it.
						resVarKey._type = valType;
					}
					if (typeDefined)
					{
						// This should be reported that we changed a defined type.
						int errType = (explicitTypeDefined) ? 
							RdResourceUtils.RESOURCE_DEFINITION_INCOMPATIBLE_TYPE :
								RdResourceUtils.RESOURCE_DEFINITION_CHANGED_TYPE;
						RdCharArray arrayWrapper = new RdCharArray();
						arrayWrapper._chars = array;
						arrayWrapper._len = endPos;
						RdParsingState capturedState = state.createChild(line, col, depth, arrayWrapper, startPos);
						RdResourceFormatError formatError = new RdResourceFormatError(capturedState, errType);
						formatError._resourceKey = res._resKey;
						formatError._resourceVarKey = resVarKey;
						RdResourceUtils.addFormatErrorToAudit(cxt, formatError);
					}
					resVarKey._flags &= ~RdKey.F_TYPE_UNRESOLVED;
				}
				res._key = resVarKey;
				
				// Value is modifiable by normal API or page submits as part of standard application processing.
				res._isDataValue = true;
			}
			
			// Finish off handling value and description.
			if (foundStartVal)
			{
				if (!foundEndVal)
				{
					foundEndVal = true;
					endValPos = lastNonSpace + 1;
				}
				parseResourceData(res, startValLine, startValCol, state._depth, array, startValPos, endValPos, state, cxt, F_NO_BODY);
			}
			else
			{
				// See if resource can have body.
				hasBody = RdResourceTypes.canHaveBody(resType);
			}
			state._needsEndTag = hasBody;
			
			if (foundStartDescription)
			{
				int endDescriptionPos = lastNonSpace + 1;
				res._descriptionIsInLine = true;
				res._description = new RdCharArray(array, startDescriptionPos, endDescriptionPos - startDescriptionPos);
			}
		}
	}

	static public void parseResourceData(RdResourceDefinition res, int line, int col, int depth, char[] array, int startPos, int endPos, RdParsingState state,
		RdContext cxt, int flags) throws IOException
	{
		boolean isSingleLine = (flags & F_NO_BODY) != 0;
		Object value = null;
		
		switch (res._resKey._resourceType)
		{
		case RdResourceTypes.DATA:
		{
			RdData data = new RdData();
			RdCharArray arrayWrapper = new RdCharArray();
			arrayWrapper._chars = array;
			arrayWrapper._len = endPos;
			RdParsingState childState = state.createChild(line, col, depth + 1, arrayWrapper, startPos);
			data.parse(null, childState, cxt, flags);
			value = data;
			break;
		}
		case RdResourceTypes.TABLE:
		{
			RdTable table = new RdTable();
			char rowSeparator = (isSingleLine) ? '|' : '\n';
			parseTable(array, startPos, endPos, ',', rowSeparator, table, state, line, col, flags);
			preparePrimaryKey(res._properties, table, cxt);
			value = table;
			break;
		}
		case RdResourceTypes.MAP:
		{
			Map map = new HashMap();
			RdParseMapCallback mapCallback = new RdParseMapWrapper(map, 0);
			parseMap(array, startPos, endPos, '=', ';', mapCallback, state, line, col);
			value = map;
			break;
		}
		default:
		{
			// Scan for a ^.
			RdCharArray valueArray = new RdCharArray();
			valueArray.prepareForAppend(endPos - startPos);
			RdCharArray wrapperArray = new RdCharArray();
			wrapperArray._chars = array;
			wrapperArray._len = endPos;
			StrUtils.appendDecodedStr(valueArray, wrapperArray, startPos, endPos, res._key, cxt, flags);
			value = valueArray;
			break;
		}
		} // switch (res._type)
		
		res._parsedObject = value; // Implicit return value to this method call.
	}
	
	static public void parseMap(char[] array, int start, int end, char nameValueSeparator, char multiItemSeparator, 
		RdParseMapCallback callback, RdParsingState state, int line, int col) throws IOException
	{
		RdCharArray tempArray = null;
		RdCharArray wrapperArray = null;
		boolean inKey = false;
		boolean foundKey = false;
		int keyStart = start;
		int lastNonSpace = start;
		int keyEnd = -1;
		boolean inVal = false;
		boolean valIsEncoded = false;
		boolean foundFullNameValue = false;
		boolean lookingForValueStart = false;
		int valStart = -1;
		int valEnd = -1;
		boolean isInvalidChar = false;
		for (int i = start; i <= end; i++)
		{
			char ch = (i < end) ? array[i] : multiItemSeparator;
			if (inKey)
			{
				if (ch == nameValueSeparator)
				{
					inKey = false;
					foundKey = true;
					keyEnd = i;
					inVal = true;
					valStart = i + 1;
				}
				else if (ch == multiItemSeparator)
				{
					inKey = false;
					keyEnd = i;
					foundKey = true;
					foundFullNameValue = true;
				}
				else if (ch <= ' ')
				{
					keyEnd = i;
					inKey = false;
					foundKey = true;
				}
				else if (ch != ':' && (ch >= 128 || !StrUtils._isVarChar[ch]))
				{
					isInvalidChar = true;
				}
			}
			else if (inVal)
			{
				if (ch == multiItemSeparator)
				{
					valEnd = lastNonSpace + 1;
					foundFullNameValue = true;
				}
				else if (ch == '^')
				{
					valIsEncoded = true;
				}
			}
			else
			{
				if (ch == multiItemSeparator)
				{
					foundFullNameValue = true;
				}
				else
				{
					if (lookingForValueStart)
					{
						if (ch > ' ')
						{
							inVal = true;
							lookingForValueStart = false;
							valStart = i;
						}
					}
					else if (foundKey)
					{
						if (ch == nameValueSeparator)
						{
							lookingForValueStart = true;
						}
						else if (ch > ' ')
						{
							isInvalidChar = true;
						}
					}
					else if (ch < 128 && StrUtils._isVarChar[ch])
					{
						keyStart = i;
						inKey = true;
					}
				}
			} // if (inKey)
			if (isInvalidChar)
			{
				createErrorMessageIntoParsingState(state, "rdceParseMapInvalidCharacter", line, col, "" + ch);
				break;
			}
			if (foundFullNameValue)
			{
				char[] valArray = array;
				
				if (inVal)
				{
					if (valIsEncoded)
					{
						if (tempArray == null)
						{
							tempArray = state._cxt.temporaryAllocateCharArray();
							wrapperArray = new RdCharArray();
							wrapperArray._chars = array;
							wrapperArray._len = end;
						}
						else
						{
							tempArray.reset();
						}
						StrUtils.appendDecodedStr(tempArray, wrapperArray, valStart, valEnd, null, state._cxt, 0);
						valStart = 0;
						valEnd = tempArray._len;
						valArray = tempArray._chars;
					}
				}
				else
				{
					valStart = i;
					valEnd = i;
				}
				callback.onParseNameValue(array, keyStart, keyEnd, valArray, valStart, valEnd, state, 0);
				foundFullNameValue = false;
				foundKey = false;
				inVal = false;
				inKey = false;
				lookingForValueStart = false;
			} // if (foundFullNameValue)
			if (ch == '\n')
			{
				line++;
			}
			else
			{
				col++;
			}
			if (ch > ' ')
			{
				lastNonSpace = i;
			}
		} // for (int i = start; i < end; i++)
		if (tempArray != null)
		{
			state._cxt.releaseTemporaryAllocatedCharArray(tempArray);
		}
		
	}
	
	static public void formatKeyMap(Appendable appendable, Map<RdKey,Object> keyMap, RdContext cxt,
		RdKey key, int depth, int flags) throws IOException
	{
		if (keyMap instanceof RdData)
		{
			RdData rdData = (RdData)keyMap;
			rdData.appendTo(appendable, RdGlobalKeys.NULL_KEY, depth, cxt, flags);
		}
		else
		{
			RdResourceFormat.formatMapToAppendable(appendable, keyMap, cxt, 
				RdGlobalKeys.NULL_KEY, '=', '\n', depth, flags);
		}
	}
	
	/**
	 * Formats a map in RdData style. The only acceptable multiItemSeparator characters
	 * are line feed, semicolon, or colon.
	 */
	static public void formatMapToAppendable(Appendable appendable, Map map, RdContext cxt,
		RdKey key, char nameValueSeparator, char multiItemSeparator, int depth, int flags) 
		throws IOException
	{
		RdCharArray array = cxt.temporaryAllocateCharArray();
		boolean pastFirst = false;
		Set keys = map.keySet();
		
		for (Object lKey : keys)
		{
			Object mKey = lKey;
			if ((flags & RdContext.F_DUMP_FORMAT) == 0 && lKey instanceof RdKey)
			{
				RdKey realKey = (RdKey)lKey;
				if (!realKey.isSerializableValue())
				{
					continue;
				}
				mKey = realKey._name;
			}
			if (pastFirst)
			{
				appendable.append(multiItemSeparator);
				if (multiItemSeparator > ' ')
				{
					// To make things a little prettier
					appendable.append(' ');
				}
			}
			array.reset();
			RdDataUtils.appendTo(array, mKey, key, depth + 1, cxt, flags);
			StrUtils.appendEncodedStr(appendable, array, key, cxt, 
				StrUtils.F_ENCODE_MAP_CHARS | StrUtils.F_ENCODE_LF);
			appendable.append(nameValueSeparator);
			array.reset();
			Object mVal = map.get(lKey);
			RdDataUtils.appendTo(array, mVal, key, depth + 1, cxt, flags);
			StrUtils.appendEncodedStr(appendable, array, key, cxt, 
				StrUtils.F_ENCODE_MAP_CHARS | StrUtils.F_ENCODE_LF);
			pastFirst = true;
		}
		if (pastFirst && multiItemSeparator == '\n')
		{
			// For consistency with formatting of RdData.
			appendable.append('\n');
		}
		cxt.releaseTemporaryAllocatedCharArray(array);
		
	}
	
	static public void parseTable(char[] array, int start, int end, char colSeparator, char rowSeparator, 
		RdTable table, RdParsingState state, int line, int col, int flags) throws IOException
	{
		boolean inRows = false;
		RdCharArray wrapperArray = null;
		
		// Value detection.
		boolean inValue = false;
		boolean valIsEncoded = false;
		int valueStartPos = start;
		int lastNonWsChar = start;
		List curRow = null;
		RdKey curFieldKey = null;
		List<RdKey> fieldNames = new ArrayList<RdKey>();
		int colCount = 0;
		boolean endOfCols = false;
		
		for (int i = start; i <= end; i++)
		{
			char ch = (i < end) ? array[i] : rowSeparator;
			boolean charIsFieldTerminator = (ch == colSeparator && !endOfCols);
			if (charIsFieldTerminator || ch == rowSeparator)
			{
				if (!inValue)
				{
					// Empty comma value of totally empty row.
					lastNonWsChar = i - 1;
					valueStartPos = i;
					valIsEncoded = false;
				}
				
				// Terminated value.
				CharSequence val = null;
				if (inRows)
				{
					curFieldKey = (endOfCols) ? RdGlobalKeys.TC_AUTO_ADD : table._fields.get(colCount++)._key;
					int l = lastNonWsChar + 1 - valueStartPos;
					if (!valIsEncoded)
					{
						val = new RdCharArray(array, valueStartPos, l);
					}
					else
					{
						RdCharArray decodedVal = new RdCharArray();
						decodedVal.prepareForAppend(l);
						if (wrapperArray == null)
						{
							wrapperArray = new RdCharArray();
							wrapperArray._chars = array;
							wrapperArray._len = end;
						}
						
						StrUtils.appendDecodedStr(decodedVal, wrapperArray, valueStartPos, 
							lastNonWsChar + 1, curFieldKey, state._cxt, 0);
						val = decodedVal;
					}
					if (curRow == null)
					{
						curRow = new ArrayList();
						table._rows.add(curRow);
					}
					curRow.add(val);
				    if (endOfCols)
				    {
				    	table.addField(curFieldKey);
				    }
				    if (ch == rowSeparator)
				    {
				    	colCount = 0;
				    	curRow = null;
				    }
				    endOfCols = colCount >= table._fields.size();
				}
				else
				{
					String keyStr = new String(array, valueStartPos, lastNonWsChar + 1 - valueStartPos);
					RdKey fieldName = state._cxt.getEquivalentKeyObject(keyStr, RdContext.F_CREATE_IF_MISSING);
					fieldNames.add(fieldName);
					if (ch == rowSeparator)
					{
						table.addFields(fieldNames);
						inRows = true;
					}
				}
				inValue = false;
			}
			else if (inValue)
			{
				if (ch == '^')
				{
					valIsEncoded = true;
				}
			}
			else if (ch > ' ')
			{
				valueStartPos = i;
				valIsEncoded = (ch == '^');
				inValue = true;
			}
			// if (charIsFieldTerminator || ch == rowSeparator)
			
			if (ch == '\n')
			{
				line++;
				col = 0;
			}
			else
			{
				col++;
			}
			if (ch > ' ')
			{
				lastNonWsChar = i;
			}
		}
	}
	
	static public void preparePrimaryKey(RdResourceProperties resProps, RdTable table, RdContext cxt)
		throws IOException
	{
		if (resProps == null || resProps._primaryKey == null || resProps._primaryKey.length() == 0)
		{
			return;
		}
		String primaryKey = resProps._primaryKey;
		if (primaryKey.indexOf(',') > 0 || resProps._mergeIsCaseInsensitive)
		{
			// Doing multiple columns or case insensitive.
			table.addField(RdTableUtils.TABLE_COMPUTED_PK_KEY);
			int pkIndex = table.getTableFieldIndex(RdTableUtils.TABLE_COMPUTED_PK_KEY);
			table._primaryKeyIndex = pkIndex;
			String keys[] = StrUtils.parseArray(primaryKey, cxt);
			int colIndex[] = new int[keys.length];
			for (int i = 0; i < colIndex.length; i++)
			{
				RdKey rdKey = cxt.getEquivalentKeyObject(keys[i], 0);
				int index = -1;
				if (rdKey != null)
				{
					index = table.getTableFieldIndex(rdKey);
				}
				colIndex[i] = index;
			}
			
			int numRows = table.getNumRows();
			RdCharArray tempArray = new RdCharArray();
			for (int i = 0; i < numRows; i++)
			{
				table.setCurrentRowIndex(i);
				RdCharArray pkVal = new RdCharArray();
				List row = table.getCurrentRow();
				boolean afterFirst = false;
				for (int index : colIndex)
				{
					if (index >= 0)
					{
						if (afterFirst)
						{
							pkVal.append(',');
						}
						RdKey rdKey = table.getTableFieldKey(index);
						Object val = row.get(index);
						tempArray.reset();
						RdDataUtils.appendTo(tempArray, val, rdKey, 0, cxt, 0);
						StrUtils.appendEncodedStr(pkVal, tempArray, rdKey, cxt, 0);
						afterFirst = true;
					}
				}
				CharSequence pkChars = pkVal;
				if (resProps._mergeIsCaseInsensitive)
				{
					pkChars = StrUtils.convertToGlobalLowerCase(pkVal, cxt);
				}
				table.putDirectByIndex(pkIndex, pkChars);
			}
		}
		else
		{
			RdKey rdPrimaryKey = cxt.getEquivalentKeyObject(primaryKey, 0);
			if (rdPrimaryKey != null)
			{
				int primaryKeyIndex = table.getTableFieldIndex(rdPrimaryKey);
				if (primaryKeyIndex >= 0)
				{
					table._primaryKeyIndex = primaryKeyIndex;
				}
			}
		}
	}
	//+endsection Reading in resources
	
	//+section Utility functions
	static public void appendRemoveCommentHashes(Appendable appendable, CharSequence comment, int start, int end) throws IOException
	{
		boolean afterEndOfLine = true;
		boolean foundHash = false;
		boolean secondCharAfterHash = false;
		int lastEndOfLine = start;
		int lastStart = start;
		char[] array = null;
		if (comment instanceof RdCharArray)
		{
			array = ((RdCharArray)comment)._chars;
		}
		for (int i = start; i < end; i++)
		{
			char ch = (array != null) ? array[i] : comment.charAt(i);
			if (afterEndOfLine)
			{
				if (ch == '#')
				{
					foundHash = true;
					afterEndOfLine = false;
				}
				else if (ch > ' ')
				{
					afterEndOfLine = false;
				}
			}
			else if (foundHash)
			{
				if (ch != ' ' || secondCharAfterHash)
				{
					if (lastEndOfLine > lastStart)
					{
						appendable.append(comment, lastStart, lastEndOfLine);
					}
					lastStart = i;
					foundHash = false;
					secondCharAfterHash = false;
				}
				else
				{
					secondCharAfterHash = true;
				}
			}
			if (ch == '\n')
			{
				afterEndOfLine = true;
				lastEndOfLine = i + 1;
			}
		}
		
		if (lastStart < end)
		{
			appendable.append(comment, lastStart, end);
		}
	}
	
	static public void appendAddCommentHashes(Appendable appendable, CharSequence comment, int start, int end) throws IOException
	{
		int lastStart = start;
		int lastEndOfLine = start;
		boolean afterEndOfLine = true;
		char[] array = null;
		if (comment instanceof RdCharArray)
		{
			array = ((RdCharArray)comment)._chars;
		}
		
		for (int i = start; i < end; i++)
		{
			char ch = (array != null) ? array[i] : comment.charAt(i);
			if (afterEndOfLine)
			{
				if (ch != '#')
				{
					// Need to add # before line.
					if (lastEndOfLine > lastStart)
					{
						appendable.append(comment, lastStart, lastEndOfLine);
					}
					appendable.append('#');
					if (ch > ' ')
					{
						appendable.append(' ');
					}
					lastStart = i;
				}
				afterEndOfLine = false;
			}
			if (ch == '\n')
			{
				afterEndOfLine = true;
				lastEndOfLine = i + 1;
			}
		}
		if (lastStart < end)
		{
			appendable.append(comment, lastStart, end);
		}
		if (lastEndOfLine != end)
		{
			appendable.append('\n');
		}
	}
	
	static public RdCharArray createLineFeedTrimmedText(char[] array, int start, int end)
	{
		if (start >= end)
		{
			return new RdCharArray();
		}
		int lineFeedIndex = -1;
		int proposedStart = start;
		while (proposedStart < end && array[proposedStart] <= ' ')
		{
			if (array[proposedStart] == '\n')
			{
				lineFeedIndex = proposedStart;
			}
			proposedStart++;
		}
		if (lineFeedIndex >= 0)
		{
			start = lineFeedIndex + 1;
		}
		
		while (end > start && array[end - 1] <= ' ')
		{
			end--;
		}
		
		if (start >= end)
		{
			return new RdCharArray();
		}
		return new RdCharArray(array, start, end - start);
	}
	//+endsection Utility functions
	
	//+section Error message handling
	static public RdResourceLocator createLocationSpecifier(RdParsingState state, int line, int col)
	{
		RdResourceLocator locator = state._locator.clone();
		locator._line = line;
		locator._col = col;
		return locator;
	}
	
	static public void createErrorMessageIntoParsingState(RdParsingState state, String stringKey, int line, int col, Object ... args)
	{
		RdMessage msg = new RdMessage(0, stringKey, args);
		RdException e = new RdException(RdException.PARSING_EXCEPTION, msg);
		RdMessage locationMsg = createErrorLocationMessage(state, line, col);
		RdException locationExcep = new RdException(RdException.PARSING_EXCEPTION, locationMsg);
		locationExcep.initCause(e);
		state._failed = true;
		state._error = locationExcep;
	}
	
	static public RdMessage createErrorLocationMessage(RdParsingState state, int line, int col)
	{
		RdResourceLocator locator = createLocationSpecifier(state, line, col);
		// Line count starts at 0, but typical editors (such as Eclipse) start at 1, likewise for the column count. We adjust
		// appropriately.
		RdMessage locationMsg = new RdMessage("rdceParseErrorLocation", locator._path, new Integer(locator._line + 1), 
				new Integer(locator._col+ 1));
		locationMsg.attachData("ParsingLocation", locator);
		return locationMsg;
	}
	//+endsection Error message handling
}
