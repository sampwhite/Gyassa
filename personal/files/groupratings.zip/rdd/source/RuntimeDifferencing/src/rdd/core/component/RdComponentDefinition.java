package rdd.core.component;

import rdd.core.storage.RdConnectionData;
import rdd.core.storage.RdMediaStorageInfo;

public class RdComponentDefinition
{
	//+section Flags
	/**
	 * Means the component holds data that will probably not port from one application
	 * to another. Components that are not system components will parameterize their configuration 
	 * so they can be more easily ported from server to server.
	 * A system component is the supplier of parameters, other components are the consumer
	 * of parameters.
	 */
	static public int F_IS_SYSTEM = 1;
	
	/**
	 * Has support for large tables with indexed lookup for
	 * primary keys. Data from this component may be archived into and
	 * out of other components. Archives will be bundles that do not
	 * allow quick random access to content.
	 */
	static public int F_LARGE_STORAGE = 2;
	
	/**
	 * Component is accessible from file system (usually local disk) and is usually
	 * prepackaged and read only. Media components can also be served from development
	 * directories where the content of the component is version controlled in a
	 * developer source code control system.
	 */
	static public int F_IS_MEDIA = 4;
	//+endsection Flags
	
	/**
	 * The name of the component. Used when creating file paths and when doing
	 * queries against database tables.
	 */
	public String _name;
	
	/**
	 * Type of components (see flag definitions above).
	 */
	public int _flags;

	/**
	 * The connection to use when accessing the component data. Generally this is null
	 * if using a media location.
	 */
	public RdConnectionData _connectionData;

	/**
	 * Whether component has media storage location. Media storage has complicated rules
	 * in terms of search order and when to detect changes so there are many attributes
	 * tracking information about media components.
	 */
	public boolean _hasMediaLocation;
	
	/**
	 * General facts about the media storage location (if one is used).
	 */
	public RdMediaStorageInfo _mediaInfo;
	
	/**
	 * The physical file path to find files inside the component if component
	 * is from the media.
	 */
	public String _mediaComponentPath;

	
	public RdComponentDefinition(String name, int flags)
	{
		_name = name;
		_flags = flags;
	}
	
	@Override
	public String toString()
	{
		return _name;
	}
}
