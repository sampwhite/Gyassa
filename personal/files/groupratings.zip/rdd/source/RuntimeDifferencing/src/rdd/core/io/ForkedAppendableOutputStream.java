package rdd.core.io;

import java.io.IOException;
import java.io.OutputStream;

import rdd.core.RdCharArray;

/**
 * Used to support a mix of binary and character data in a convenient manner. The particular focus is on logging. This implementation does not
 * support PrintStream because of the awkward existing implementation and the difficulty in creating a new implementation. It also has some
 * unfortunate performance characteristics under stress.
 */
public class ForkedAppendableOutputStream extends RdAppendableOutputStream
{
	public RdAppendableOutputStream[] _streams;

	public ForkedAppendableOutputStream(RdAppendableOutputStream[] streams)
	{
		int nStreams = (streams != null) ? streams.length : 0;
		_streams = new RdAppendableOutputStream[nStreams];
		if (streams != null)
		{
			System.arraycopy(streams, 0, _streams, 0, nStreams);
		}
	}
	
	public void addStream(RdAppendableOutputStream stream)
	{
		synchronized (_syncObject)
		{
			RdAppendableOutputStream[] newStreams = new RdAppendableOutputStream[_streams.length + 1];
			for (int i = 0; i < _streams.length; i++)
			{
				newStreams[i] = _streams[i];
			}
			newStreams[_streams.length] = stream;
			_streams = newStreams;
		}
	}
	
	//+section OutputStream
	@Override
	public void write(int b) throws IOException
	{
		for (OutputStream str : _streams)
		{
			str.write(b);
		}
	}

	@Override
    public void write(byte b[], int off, int len) throws IOException
    {
		for (OutputStream str : _streams)
		{
			str.write(b, off, len);
		}
    }
	
	@Override
	public void close() throws IOException
	{
		// Do nothing, closing has to be done directly on interior streams. It may be 
		// a bad idea to close some of the streams being written to.
	}
	
	@Override
	public void flush() throws IOException
	{
		for (OutputStream str : _streams)
		{
			str.flush();
		}
	}
	//+endsection OutputStreasm
	
	//+section Interface Appendable
	@Override
	public Appendable append(CharSequence csq) throws IOException
	{
		append(csq, 0, csq.length());
		return this;
	}

	@Override
	public Appendable append(CharSequence csq, int start, int end) throws IOException
	{
		char[] buf = null;
		if (start >= end)
		{
			return this;
		}
		if (csq instanceof RdCharArray)
		{
			buf = ((RdCharArray)csq)._chars;
		}
		else
		{
			buf = new char[end - start];
			for (int i = start; i < end; i++)
			{
				buf[i - start] = csq.charAt(i);
			}
			end = end - start;
			start = 0;
		}
		for (RdAppendableOutputStream rdAO : _streams)
		{
			rdAO.writeDirect(buf, start, end - start);
		}
		return this;
	}

	@Override
	public Appendable append(char c) throws IOException
	{
		for (RdAppendableOutputStream rdAO : _streams)
		{
			rdAO.append(c);
		}
		return this;
	}

}
