package rdd.core;

/**
 * The universal exception type of the "RDD" package. 
 * @see RddErrorCodes
 */
public class RdException extends Exception
{
	// Types of exceptions.
	static public final int GENERAL_EXCEPTION = 1;
	static public final int PROTOCOL_EXCEPTION = 2;
	static public final int PARSING_EXCEPTION = 3;
	
	public int _type;
	public int _errorCode;
	public int _protocolCode;
	public RdMessage _msg;
	
	
	public RdException(RdMessage msg)
	{
		_msg = msg;
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = GENERAL_EXCEPTION;
	}
	
	public RdException(int type, RdMessage msg)
	{
		_msg = msg;
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = type;
	}


	public RdException(String strMsg, Object ... msgParams)
	{
		_msg = new RdMessage(0, strMsg, msgParams);
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = GENERAL_EXCEPTION;
	}

	public RdException(Throwable t, String strMsg, Object ... msgParams)
	{
		_msg = new RdMessage(0, strMsg, msgParams);
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = GENERAL_EXCEPTION;
		initCause(t);
	}

	public RdException(int type, String strMsg, Object ... msgParams)
	{
		_msg = new RdMessage(0, strMsg, msgParams);
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = type;
	}

	public RdException(Throwable t, int type, String strMsg, Object ... msgParams)
	{
		_msg = new RdMessage(0, strMsg, msgParams);
		_errorCode = RdErrorCodes.GENERAL_ERROR;
		_type = type;
		initCause(t);
	}

	@Override
	public String getMessage()
	{
		if (_msg == null)
		{
			return "null";
		}
		return _msg.getEncodedMessage();
	}
}
