package rdd.core.logger;

import rdd.core.io.ForkedAppendableOutputStream;
import rdd.core.io.RdAppendableOutputStream;

public class LogStreams
{
	static public ForkedAppendableOutputStream _lOut = new ForkedAppendableOutputStream(
		new RdAppendableOutputStream[]{new RdAppendableOutputStream(System.out, null)});
	static public ForkedAppendableOutputStream _lErr = new ForkedAppendableOutputStream(
		new RdAppendableOutputStream[]{new RdAppendableOutputStream(System.err, null)});
}
