package rdd.core.strings;

import rdd.core.RdContext;

/**
 * Determining language for the current context is a non "core" package action. This provides a
 * callback up to the application layer to answer this vital question.
 */
public interface RdDetermineLanguageIndex
{
	public int determineLanguageIndex(RdContext cxt);
}
