package rdd.core;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import rdd.core.resource.RdResourceFormat;

/**
 * The general context object. This is a complicated and sophisticated object that is used to manage
 * a "stack" of context objects and also to maintain "context" objects on the "side". The general
 * idea is that values will be searched for in various places using various rules and this class
 * will control all this logic. Data can be swapped in or out, pushed or popped, and in general data
 * will be prepared and massaged so that script can access it in the most straightforward and
 * logical way.
 * 
 * The Context objects come in the following types.
 * 
 * WRAPPER_CONTEXT -- This context holds the other context objects in _contextStack. The
 * _contextStack is usually shared with the context objects stored in the _contextStack. The wrapper
 * context is usually the one that is passed as parameters to API calls.
 * 
 * GLOBAL_CONTEXT -- This is the wrapper context for global configuration data. The configuration
 * data is global to all applications loaded inside this running Java VM. The global context is
 * created at the time the process is started and never created again.
 * 
 * APP_CONTEXT -- This context is create per application. Each application comes with its own class
 * loader and each application can be restarted.
 * 
 * PARAMETERS_CONTEXT -- This context is data that comes with a request but is not actually in the
 * body of the request data. It will contain all HTTP headers (and derived data), such as whether
 * the request came over SSL or not. It will also contain any parameters that are not to be modified
 * by script and are to be secured against unintentional modification. If the request has been
 * authenticated as acting for a particular user, it will have a RdUser object as well (under the
 * key "User"). In more complex security configurations, it will hold session key and user security
 * data.
 * 
 * REQUEST_CONTEXT -- This context holds the incoming data of the request. For example, it will hold
 * the values found after the "?" on a URL request. It will also hold data computed during the
 * "data" processing part of the request.
 * 
 * PAGE_CONTEXT -- This is the context that is used to build the response and process the body of
 * the incoming data. It is used when building the page or creating a well formed response to an API
 * request.
 * 
 * CALL_CONTEXT -- This is a temporary context created for certain method calls to protect the
 * PAGE_CONTEXT from unintended modification. This context can come into and go out of existence.
 * The one specific scenario of interest is when data is being prepared for a cross process API call
 * or when it is being prepared for persistent storage.
 * 
 * The REQUEST_CONTEXT, PAGE_CONTEXT, and CALL_CONTEXT are called "API" contexts. The APP_CONTEXT
 * and GLOBAL_CONTEXT are called "ENV" contexts. The PARAMETERS_CONTEXT is called the "PARAMS"
 * context.
 * 
 * Not all the contexts have to exist at any moment. The context that is farthest down in the stack
 * is called the "local" context and it is the one which typically will receive modifications by
 * script. In a fully profiled request, all of the stack down to the REQUEST_CONTEXT should be
 * defined. At the time that page script is executed, the PAGE_CONTEXT should be defined. The rules
 * for the existence of CALL_CONTEXT are specific to particular method calls. It is expected that
 * parameters will be retrieved from particular context levels in order to avoid potential data
 * pollution or security issues. That is why the "search" for a value has many different flags to
 * control how the search is done. Likewise code may explicitly set values into particular context
 * levels in order to control the visibility and life time of the data.
 * 
 * In addition to the request stack, it is also possible to "push" and "pop" API context objects to
 * protect the current API context from modification from sub method or sub service calls.
 */
public class RdContext implements Map<RdKey,Object>, RdAppender, Cloneable, RdCloneable
{
	//+section Context types
	static public final int WRAPPER_CONTEXT = 0;
	static public final int GLOBAL_CONTEXT = 1;
	static public final int APP_CONTEXT = 2;
	static public final int PARAMETERS_CONTEXT = 3;
	static public final int REQUEST_CONTEXT = 4;
	static public final int PAGE_CONTEXT = 5;
	static public final int CALL_CONTEXT = 6;
	static public final int CONTEXT_ARRAY_SIZE = 7;
	
	static public final int SIMPLE_DATA_CONTEXT = 16;
	
	static public final int END_CLASSLOADER_CONTEXTS = APP_CONTEXT;
	static public final int END_NON_API_DATA_CONTEXTS = PARAMETERS_CONTEXT;
	
	static public final String[] CONTEXT_TYPE_DESCRIPTIONS = {"wrapper", "global", "app", 
		"parameters", "request", "page", "call"};
	//+endsection Context types
	
	//+section Flags for controlling how data is retrieved and presented on return.
	static public final int F_STANDARD_SEARCH = 0;
	static public final int F_LOCAL_ONLY = 1;
	static public final int F_COOERCE_TO_DEVALUE = 2;
	static public final int F_ENV_AND_PARAMS_ONLY = 4;
	static public final int F_PARSE_STRING_FOR_BOOL = 8;
	static public final int F_LOCALIZE_MESSAGES = 16;
	static public final int F_DEBUG_FORMAT = 32;
	static public final int F_DUMP_FORMAT = 64;
	static public final int F_IS_NOT_FIRST = 128;
	static public final int F_CREATE_STORAGE_ENTRY_ONLY = 256;
	//+endsection Flags for controlling how data is retrieved
	
	//+section Flags controlling access to RdKey lookup
	static public final int F_CREATE_IF_MISSING = 1;
	//+endsection Flags controlling access to RdKey lookup
	
	//+section Flags controlling how this context is searched for values
	static public final int F_DO_NOT_SEARCH_PUSHED = 1;
	//+endsection Flags controlling how this context is searched for values
	
	//+section Flags controlling push and pop
	static public final int F_STANDARD_PUSHPOP = 0;
	//+endsection Flags controlling push and pop
	
	
	/**
	 * Identifier for context. Used as part of lookups to cached data that are specific to user or application.
	 * It is null by default except for the more global execution contexts.
	 */
	RdContextKey _id;
	
	/**
	 * Type of context.
	 */
	public int _type;
	
	/**
	 * Whether context is initialized. Data cannot be retrieved or put into context until it is initialized properly.
	 */
	public boolean _isInit;
	
	/**
	 * Search flags. Controls whether pushed or prior contexts are searched.
	 */
	public int _searchFlags;
	
	/**
	 * Pointers to other types of contexts that are needed. In some cases
	 * the pointers will point to self. The context types are used as
	 * indexes into this array. A wrapper context can evolve to point
	 * at new versions of other contexts. The other contexts stay more fixed
	 * in what they have within themselves. The global context has the life span of
	 * this process, the application environment context has the life span of the class loader that
	 * had loaded this application. Only those objects have the _stringToKeyMap attribute
	 * initialized. The contexts are in a list from most global to most specific.
	 * The page context is not created until page creation starts. The request context
	 * will hold parameters from the original request that are considered to be part
	 * of the API. The parameters context will contain parameters for the request
	 * that need to be protected from modification when simple script is executed.
	 */
	public RdContext[] _contextStack;
	
	/**
	 * Cached pointer to active class loader to use. If attribute is null
	 * then it is gotten from the RdContext objects that are supposed
	 * to have class loaders.
	 */
	public ClassLoader _classLoader;
	
	/**
	 * Pointers that bind contexts together. The _parentContext is not searched automatically.
	 */
	public RdContext _parentContext;
	public RdContext _pushedContext;
	
	/**
	 * Temporarily promoted context. Given priority when looking up data.
	 */
	public RdContext _lookupFirst;
	
	/**
	 * Pushed promoted context, will be searched for values just after _lookupFirst is searched.
	 */
	public RdContext _pushedLookupFirst;

	/**
	 * Temporarily promoted context. Given priority when looking up data, but _data is searched first.
	 */
	public RdContext _lookupAfter;
	
	/**
	 * Pushed promoted context, will be searched for values just after _lookupAFter is searched.
	 */
	public RdContext _pushedLookupAfter;

	/**
	 * Turns strings into RdKeys. Only defined if a new class loader was created at the time this context
	 * object was created.
	 */
	public Map<String,RdKey> _stringToKeyMap;
	
	/**
	 * Gives extra definition to RdKey objects.
	 */
	public Map<RdKey,RdData> _keyToRdfinitionMap;
	
	/**
	 * The actual data of this context object. This object is null in a wrappering context.
	 */
	public Map<RdKey,Object> _data;
	
	/**
	 * Counter to help create reference counters.
	 */
	public int _refTempCounter;
	
	/**
	 * Temporary references to internal objects during the serialization process.
	 */
	public SortedMap<String,RdValue> _tempReferences;
	
	/**
	 * Convenience object to minimize object creation and destruction. Only created for wrapper contexts.
	 */
	public RdObjectLifeCycleOptimizer _objectOptimizer;
	
	/**
	 * Cached context specific objects of a generic nature. Only created for wrapper contexts.
	 */
	public Map<RdKey,Object> _cachedObjects;
	
	/**
	 * Fast look up cached objects retrieved from data in the context or put here programatically.
	 * Global data is not put into static attributes unless the class is loaded by a
	 * class loader specific to that application (applications can be restarted without
	 * restarting the server). This attribute is designed to give some of the convenience
	 * and speed of static complex global objects without actually having static attributes
	 * in classes. The prototypical example of such an object in the RdStringData object
	 * for both the global environment and application environment.
	 * 
	 * This attribute can also hold complex objects specific to the user or the request
	 * that do complex enough processing that binding values in the context to specific
	 * attributes into an object becomes worthwhile. An example might be computing
	 * the locations of resources that use complex local file caching rules.
	 */
	public RdCachedObject[] _fastCachedObjectLookup;
	
	public RdContext()
	{
		_type = SIMPLE_DATA_CONTEXT;
		initStandardFields();
	}
	
	public RdContext(Map<RdKey,Object> map)
	{
		_type = SIMPLE_DATA_CONTEXT;
		_data = map;
	}

	public RdContext(int type)
	{
		_type = type;
		initStandardFields();
		prepareContext();
	}
	
	public RdContext(RdContext basedOn, int type)
	{
		_type = type;
		initStandardFields();
		if (basedOn != null)
		{
			copyStandardFields(basedOn);
		}
		prepareContext();
	}
	
	public RdContext(RdContext basedOn, int type, String id, Map<RdKey,Object> data)
	{
		_type = type;
		initStandardFields();
		RdContextKey parentId = null;
		if (basedOn != null)
		{
			copyStandardFields(basedOn);
			parentId = basedOn._id;
		}
		_id = new RdContextKey(id, parentId);
		_data = data;
		prepareContext();
		
		// Reasonably well filled out RdContext object.
		_isInit = true;
	}
	
	//+Support methods
	public RdContext shallowCloneContext()
	{
		RdContext newContext = new RdContext();
		newContext.copyStandardFields(this);
		newContext._type = _type;
		newContext.prepareContext();
		newContext._data = _data;
		return newContext;
	}
	
	@Override
	public Object clone()
	{
		RdContext newContext = new RdContext(this, _type);
		newContext._data = RdDataUtils.cloneRdMap(_data);
		newContext._parentContext = this;
		return newContext;
	}

	
	//+section RdCloneable interface
	@Override
	public Object clone(int depth, RdContext cxt)
	{
		RdContext newContext = shallowCloneContext();
		if (depth > 0)
		{
			newContext._data = (Map<RdKey,Object>)RdCloner.cloneObject(_data, 
				depth - 1, cxt);
		}
		return newContext;
	}
	//+endsection RdCloneable interface 

	public void initStandardFields()
	{
		_contextStack = new RdContext[CONTEXT_ARRAY_SIZE]; 
	}
	
	public void copyStandardFields(RdContext copyFrom)
	{
		for (int i = 0; i < copyFrom._contextStack.length; i++)
		{
			_contextStack[i] = copyFrom._contextStack[i];
		}
		_isInit = copyFrom._isInit;
	}
	
	public void prepareContext()
	{
		if (_type == WRAPPER_CONTEXT)
		{
			_objectOptimizer = new RdObjectLifeCycleOptimizer(this);
			_cachedObjects = new RdData();
			_contextStack[WRAPPER_CONTEXT] = this;
		}
		else if (_type <= END_CLASSLOADER_CONTEXTS)
		{
			_contextStack[_type] = this;
			_stringToKeyMap = new ConcurrentHashMap<String,RdKey>();			
		}
	}
	
	public RdKey getEquivalentKeyObject(CharSequence key, int flags)
	{
		if (!_isInit)
		{
			return null;
		}
		
		RdKey deKey = null;
		RdContext lastClassLoaderContext = null;
		String keyStr = key.toString();
		
		for (int i = END_CLASSLOADER_CONTEXTS; i > WRAPPER_CONTEXT; i--)
		{
			RdContext classLoaderContext = _contextStack[i];
			if (classLoaderContext != null)
			{
				lastClassLoaderContext = classLoaderContext;
				deKey = classLoaderContext._stringToKeyMap.get(keyStr);
				if (deKey != null)
				{
					break;
				}
			}
		}
		if (deKey == null && ((flags & F_CREATE_IF_MISSING) != 0))
		{
			synchronized (lastClassLoaderContext)
			{
				// Try again, want to avoid having same key getting created twice.
				deKey = lastClassLoaderContext._stringToKeyMap.get(keyStr);
				if (deKey == null)
				{
					deKey = new RdKey(keyStr);
					deKey._flags |= RdKey.F_TYPE_UNRESOLVED;
					lastClassLoaderContext._stringToKeyMap.put(keyStr, deKey);
				}
			}
		}
		return deKey;
	}
	//+endsection Support methods.

	//+section Utility access methods.
	public RdValue getV(RdKey key, int flags)
	{
		flags |= F_COOERCE_TO_DEVALUE;
		return (RdValue)findValue(key, flags, 0);
	}
	public RdValue getV(CharSequence key, int flags)
	{
		flags |= F_COOERCE_TO_DEVALUE;
		return (RdValue)findValue(key, flags);
	}
	public RdValue getV(CharSequence key)
	{
		int flags = F_COOERCE_TO_DEVALUE | F_STANDARD_SEARCH;
		return (RdValue)findValue(key, flags);
	}
	public CharSequence getS(RdKey key, int flags)
	{
		Object o = findValue(key, flags, 0);
		return RdDataUtils.coerceToString(o, key, this, flags);
	}
	public CharSequence getS(RdKey key)
	{
		Object o = findValue(key, F_STANDARD_SEARCH, 0);
		return RdDataUtils.coerceToString(o, key, this, F_STANDARD_SEARCH);
	}
	public CharSequence getS(CharSequence key, int flags)
	{
		RdKey rdKey = getEquivalentKeyObject(key, 0);
		if (rdKey == null)
		{
			return "";
		}
		Object o = findValue(rdKey, flags, 0);
		return RdDataUtils.coerceToString(o, rdKey, this, flags);
	}
	public CharSequence getS(CharSequence key)
	{
		RdKey rdKey = getEquivalentKeyObject(key, 0);
		if (rdKey == null)
		{
			return "";
		}
		Object o = findValue(rdKey, F_STANDARD_SEARCH, 0);
		return RdDataUtils.coerceToString(o, rdKey, this, F_STANDARD_SEARCH);
	}
	public boolean getB(RdKey key, int flags)
	{
		Object o = findValue(key, flags, 0);
		return RdDataUtils.cooerceObjectToBoolean(o, false, flags);
	}
	public boolean getB(RdKey key)
	{
		Object o = findValue(key, F_STANDARD_SEARCH, 0);
		return RdDataUtils.cooerceObjectToBoolean(o, false, F_STANDARD_SEARCH);
	}
	public boolean getB(CharSequence key, int flags)
	{
		Object o = findValue(key, flags);
		return RdDataUtils.cooerceObjectToBoolean(o, false, flags);
	}
	public boolean getB(CharSequence key)
	{
		Object o = findValue(key, F_STANDARD_SEARCH);
		return RdDataUtils.cooerceObjectToBoolean(o, false, F_STANDARD_SEARCH);
	}
	public boolean getB(RdKey key, int flags, boolean def)
	{
		Object o = findValue(key, flags, 0);
		return RdDataUtils.cooerceObjectToBoolean(o, def, flags);
	}
	public boolean getB(CharSequence key, int flags, boolean def)
	{
		Object o = findValue(key, flags);
		return RdDataUtils.cooerceObjectToBoolean(o, def, flags);
	}
	
	/**
	 * Convenience method for setting an object into an RdKey map using only
	 * a string key. This will register a new key if necessary.
	 * @param map The map to get the value.
	 * @param key A string version of a key.
	 * @param val The value to set.
	 */
	public void put(Map<RdKey,Object> map, CharSequence key, Object val)
	{
		RdKey rKey = getEquivalentKeyObject(key, F_CREATE_IF_MISSING);
		int valType = RdKey.STRING;
		boolean checkType = val != null && (rKey._flags & RdKey.F_TYPE_UNRESOLVED) != 0;
		if (val != null && !(val instanceof CharSequence) && !(val instanceof RdValue))
		{
			RdValue rV = new RdValue(rKey, val);
			valType = rV._type;
			val = rV;
		}
		else if (checkType && val instanceof RdValue)
		{
			RdValue rV = (RdValue)val;
			valType = rV._type;
		}
		if (checkType && valType != RdKey.NULL)
		{
			rKey._type = valType;
			rKey._flags &= ~RdKey.F_TYPE_UNRESOLVED;
		}
		if (val == null)
		{
			val = RdGlobalValues.NULL_VALUE;
		}
		map.put(rKey, val);
	}
	//+endsection


	public RdContext getWrapperContext()
	{
		if (_type == WRAPPER_CONTEXT)
		{
			return this;
		}
		return _contextStack[WRAPPER_CONTEXT];
	}
	
	public ClassLoader getClassLoader()
	{
		if (_classLoader != null)
		{
			return _classLoader;
		}

		ClassLoader classLoader = null;
		for (int i = END_CLASSLOADER_CONTEXTS; i > WRAPPER_CONTEXT; i--)
		{
			RdContext classLoaderContext = _contextStack[i];
			if (classLoaderContext != null)
			{
				classLoader = classLoaderContext._classLoader;
				if (classLoader != null)
				{
					break;
				}
			}
		}
		if (classLoader == null)
		{
			classLoader = RdContext.class.getClassLoader();
		}
		_classLoader = classLoader;
		return classLoader;
	}
	
	public SimpleDateFormat getInternalDateFormatter()
	{
		return getWrapperContext()._objectOptimizer._internalDateFormat;
	}
	
	public Calendar getInternalCalendar()
	{
		return getWrapperContext()._objectOptimizer._internalCalendar;
	}
	
	public Object getCachedObject(RdKey key)
	{
		 return getWrapperContext()._cachedObjects.get(key);
	}
	
	public void putCachedObject(RdKey key, Object obj)
	{
		getWrapperContext()._cachedObjects.put(key, obj);
	}
	
	public RdCharArray temporaryAllocateCharArray()
	{
		RdContext wrapperContext = getWrapperContext();
		List<RdCharArray> charArrays = wrapperContext._objectOptimizer._charArrays;
		if (charArrays.size() > 0)
		{
			RdCharArray reusedArray = charArrays.remove(charArrays.size() - 1);
			reusedArray.reset();
			return reusedArray;
		}
		return new RdCharArray();
	}
	
	public void releaseTemporaryAllocatedCharArray(RdCharArray charArray)
	{
		RdContext wrapperContext = getWrapperContext();
		List<RdCharArray> charArrays = wrapperContext._objectOptimizer._charArrays;
		charArrays.add(charArray);
	}

	public RdByteArray temporaryAllocateByteArray()
	{
		RdContext wrapperContext = getWrapperContext();
		List<RdByteArray> byteArrays = wrapperContext._objectOptimizer._byteArrays;
		if (byteArrays.size() > 0)
		{
			RdByteArray reusedArray = byteArrays.remove(byteArrays.size() - 1);
			reusedArray.reset();
			return reusedArray;
		}
		return new RdByteArray();
	}
	
	public void releaseTemporaryAllocatedCharArray(RdByteArray byteArray)
	{
		RdContext wrapperContext = getWrapperContext();
		List<RdByteArray> byteArrays = wrapperContext._objectOptimizer._byteArrays;
		byteArrays.add(byteArray);
	}

	/**
	 * Creates a context that references just the shared data without any local data.
	 * The context can only be used for setting and retrieving values directly. Other
	 * manipulations may cause failures.
	 * @return A new context wrappering just the context objects that are shared between
	 * threads.
	 */
	public RdContext createSharedDataWrapperContext()
	{
		RdContext cxt = new RdContext();
		cxt._type = WRAPPER_CONTEXT;
		for (int i = END_CLASSLOADER_CONTEXTS; i > WRAPPER_CONTEXT; i--)
		{
			cxt._contextStack[i] = _contextStack[i];
		}
		return cxt;
	}
	
	public RdContext getGlobalContext()
	{
		RdContext cxt = null;
		if (_type == WRAPPER_CONTEXT)
		{
			cxt = _contextStack[GLOBAL_CONTEXT];
		}
		else if (_type == GLOBAL_CONTEXT)
		{
			cxt = this;
		}
		return cxt;
	}
	
	public RdContext getApplicationContext()
	{
		RdContext cxt = null;
		if (_type == WRAPPER_CONTEXT)
		{
			cxt = _contextStack[APP_CONTEXT];
		}
		else if (_type == APP_CONTEXT)
		{
			cxt = this;
		}
		return cxt;
	}
	
	public RdContext getRequestContext()
	{
		RdContext cxt = null;
		if (_type == WRAPPER_CONTEXT)
		{
			cxt = _contextStack[REQUEST_CONTEXT];
		}
		if (cxt == null)
		{
			cxt = getLocalContext();
		}
		return cxt;
	}
	
	public RdContext getLocalContext()
	{
		RdContext cxt = null;
		if (_type == WRAPPER_CONTEXT)
		{
			// Get the last non null context in the array.
			int endIndex = CONTEXT_ARRAY_SIZE;
			for (int i = endIndex - 1; i > WRAPPER_CONTEXT; i--)
			{
				cxt = _contextStack[i];
				if (cxt != null)
				{
					break;
				}
			}
		}
		if (cxt == null)
		{
			cxt = this;
		}
		return cxt;
	}
	
	public Map<RdKey,Object> getLocalData()
	{
		RdContext cxt = getLocalContext();
		if (!cxt._isInit && cxt._data == null)
		{
			// Stop gap implementation for when RdContext is not ready yet.
			cxt._data = new RdData();
		}
		return cxt._data;
	}
	
	/**
	 * Though this method takes a CharSequence, it is better served if a String
	 * is passed in.
	 */
	public Object findValue(CharSequence key, int flags)
	{
		RdKey deKey = getEquivalentKeyObject(key, 0);
		if (deKey == null)
		{
			return null;
		}
		return findValue(deKey, flags, 0);
	}
	
	public Object findValue(RdKey key, int flags, int depth)
	{
		if (depth > 10)
		{
			throw new IllegalStateException("Rdpth " + depth + " too deep for searching context objects");
		}
		Object val = null;
		if (_type == WRAPPER_CONTEXT && _isInit)
		{
			// See which contexts we search through.
			boolean lastOneOnly = (flags & F_LOCAL_ONLY) != 0;
			int endIndex = (flags & F_ENV_AND_PARAMS_ONLY) != 0 ? PARAMETERS_CONTEXT : CONTEXT_ARRAY_SIZE - 1;
			for (int i = endIndex; i > WRAPPER_CONTEXT; i--)
			{
				RdContext cxt = _contextStack[i];
				if (cxt != null)
				{
					val = cxt.findValue(key, flags, depth + 1);
					if (val != null && val != RdGlobalValues.ORIGINALLY_NULL_VALUE)
					{
						break;
					}
					if (lastOneOnly)
					{
						break;
					}
				}
			}
		}
		else
		{
			boolean dataOnly = (flags & F_LOCAL_ONLY) != 0;
			if (!dataOnly)
			{
				if (_lookupFirst != null)
				{
					val = _lookupFirst.findValue(key, flags, depth + 1);
				}
				if (val == null && _pushedLookupFirst != null)
				{
					val = _pushedLookupFirst.findValue(key, flags, depth + 1);
				}
			}
			if (_data != null && val == null)
			{
				if ((flags & F_COOERCE_TO_DEVALUE) != 0)
				{
					val = RdDataUtils.getWithCoercion(_data, key, 0);
				}
				else
				{
					val = _data.get(key);
				}
			}
			if (!dataOnly && val == null)
			{
				if (_lookupAfter != null)
				{
					val = _lookupAfter.findValue(key, flags, depth + 1);
				}
				if (val == null && _pushedLookupAfter != null)
				{
					val = _pushedLookupAfter.findValue(key, flags, depth + 1);
				}
			}
			if (!dataOnly && val == null && (_searchFlags & F_DO_NOT_SEARCH_PUSHED) == 0)
			{
				if (_pushedContext != null)
				{
					val = _pushedContext.findValue(key, flags, depth + 1);
				}
			}
		}
		
		// Check to see if value needs to be shallow cloned. This way different references to the same RdTable will not
		// share iterators.
		val = RdDataUtils.prepareForIterativeAccess(key, val, flags);
		return val;
	}
	
//+ section Implementation of Map interface
	@Override
	public int size()
	{
		return getLocalData().size();
	}
	@Override
	public boolean isEmpty()
	{
		return getLocalData().isEmpty();
	}
	@Override
	public boolean containsKey(Object key)
	{
		return getLocalData().containsKey(key);
	}
	@Override
	public boolean containsValue(Object value)
	{
		return getLocalData().containsKey(value);
	}
	@Override
	public Object get(Object key)
	{
		if (key instanceof RdKey)
		{
			return findValue((RdKey)key, F_STANDARD_SEARCH, 0);
		}
		String sKey = key.toString();
		return findValue(sKey, F_STANDARD_SEARCH);
	}
	@Override
	public Object put(RdKey key, Object value)
	{
		return getLocalData().put(key, value);
	}
	@Override
	public Object remove(Object key)
	{
		return getLocalData().remove(key);
	}
	@Override
	public void putAll(Map<? extends RdKey, ? extends Object> m)
	{
		getLocalData().putAll(m);
	}
	@Override
	public void clear()
	{
		getLocalData().clear();
	}
	@Override
	public Set<RdKey> keySet()
	{
		return getLocalData().keySet();
	}
	@Override
	public Collection<Object> values()
	{
		return getLocalData().values();
	}
	@Override
	public Set<java.util.Map.Entry<RdKey, Object>> entrySet()
	{
		return getLocalData().entrySet();
	}
//+endsection Implementation of Map interface
	
	public void setTempReference(String ref, RdValue value)
	{
		if (_tempReferences == null)
		{
			_tempReferences = new TreeMap<String,RdValue>();
		}
		_tempReferences.put(ref, value);
	}
	
	public RdValue getTempReference(String ref)
	{
		if (_tempReferences == null)
		{
			return null;
		}
		return _tempReferences.get(ref);
	}
	
	public void clearTempReferences()
	{
		if (_tempReferences != null)
		{
			_tempReferences.clear();
			_tempReferences = null;
		}
	}
	
//+section Push and pop
	public void push(int flags)
	{
		RdContext localContext = getLocalContext();
		localContext._pushedContext = localContext.shallowCloneContext();
		localContext._data = new RdData();
	}
	
	public RdData pop(int flags)
	{
		RdContext localContext = getLocalContext();
		if (localContext._pushedContext == null || !(localContext._data instanceof RdData))
		{
			return null;
		}
		RdData curData = (RdData)localContext._data;
	    localContext._data = localContext._pushedContext._data;
	    localContext._pushedContext = localContext._pushedContext._pushedContext;
	    return curData;
	}
	
	public void pushByType(int type, int flags)
	{
		RdContext typeContext = _contextStack[type];
		RdContext pushedContext = null;
		if (typeContext == null)
		{
			pushedContext = new RdContext(this, type, "" + type, new RdData());
			_contextStack[type] = pushedContext;
		}
		else
		{
			pushedContext = typeContext.shallowCloneContext();
			typeContext._pushedContext = pushedContext;
			typeContext._data = new RdData();
		}
	}
	
	public void pushByType(int type, int flags, RdData data)
	{
		RdContext typeContext = _contextStack[type];
		RdContext pushedContext = null;
		if (typeContext == null)
		{
			pushedContext = new RdContext(this, type, "" + type, data);
			_contextStack[type] = pushedContext;
		}
		else
		{
			pushedContext = typeContext.shallowCloneContext();
			typeContext._pushedContext = pushedContext;
			typeContext._data = data;
		}
	}
	
	public RdData popByType(int type, int flags)
	{
		RdContext typeContext = _contextStack[type];
		if (typeContext == null || !(typeContext._data instanceof RdData))
		{
			return null;
		}
		RdData curData = (RdData)typeContext._data;
		if (typeContext._pushedContext == null)
		{
			_contextStack[type] = null;
		}
		else
		{
			typeContext._pushedContext = typeContext._pushedContext._pushedContext;
		}
		return curData;
	}
//+endsection Push and pop

	//+section Implementation of RdAppender interface
	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext paramCxt, int flags) throws IOException
	{
		if (depth > 10)
		{
			appendable.append("\nDepth " + depth + " too deep for recursive formatting");
			return;
		}
		if (_type == WRAPPER_CONTEXT && _isInit)
		{
			// See which contexts we search through.
			int endIndex = CONTEXT_ARRAY_SIZE - 1;
			boolean isFirst = true;
			for (int i = endIndex; i > WRAPPER_CONTEXT; i--)
			{
				RdContext cxt = _contextStack[i];
				if (cxt != null)
				{
					String contextDes = CONTEXT_TYPE_DESCRIPTIONS[i];
					appendDebugInteriorDataContext(appendable, key, cxt, depth, contextDes,
						paramCxt, flags, isFirst);
					isFirst = false;
				}
			}
		}
		else
		{
			boolean isFirst = true;
			if (_lookupFirst != null)
			{
				appendDebugInteriorDataContext(appendable, key, _lookupFirst, depth, 
					"lookupFirst", paramCxt, flags, isFirst);
				isFirst = false;
			}
			if (_pushedLookupFirst != null)
			{
				appendDebugInteriorDataContext(appendable, key, _pushedLookupFirst, depth, 
					"pushedLookupFirst", paramCxt, flags, isFirst);
				isFirst = false;
			}
			if (_data != null)
			{
				if (!isFirst)
				{
					appendable.append('\n');
				}
				RdResourceFormat.formatKeyMap(appendable, _data, paramCxt, key, depth, flags);
				
				// Has line feed at end.
				isFirst = true;
			}
			if (_lookupAfter != null)
			{
				appendDebugInteriorDataContext(appendable, key, _lookupAfter, depth, 
					"lookupAfter", paramCxt, flags, isFirst);
				isFirst = false;
			}
			if ( _pushedLookupAfter != null)
			{
				appendDebugInteriorDataContext(appendable, key, _pushedLookupAfter, depth, 
					"pushedLookupAfter", paramCxt, flags, isFirst);
				isFirst = false;
			}
			if (_pushedContext != null)
			{
				appendDebugInteriorDataContext(appendable, key, _pushedContext, depth, 
					"pushedContext", paramCxt, flags, isFirst);
				isFirst = false;
			}
		}
	}
	//+endsection Implementation of RdAppender interface

	public void appendDebugInteriorDataContext(Appendable appendable, RdKey key, RdContext cxt, 
		int depth, String contextDes, RdContext paramCxt, int flags, boolean isFirst) throws IOException
	{
		appendDebugSectionString(appendable, depth, contextDes, false); 
		cxt.appendTo(appendable, key, depth + 1, paramCxt, flags);	
		appendDebugSectionString(appendable, depth, contextDes, true); 
	}
	
	public void appendDebugSectionString(Appendable appendable, int depth, String section, 
		boolean isEnd) 
		throws IOException
	{
		char ch = (isEnd) ? ']' : '[';
		if (isEnd)
		{
			appendable.append(section);
			appendable.append(".end");
		}
		for (int i = 0; i < depth + 1; i++)
		{
			appendable.append(ch);
		}
		if (!isEnd)
		{
			appendable.append(section);
			appendable.append(".start");
		}
		appendable.append('\n');
	}

	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}

}
