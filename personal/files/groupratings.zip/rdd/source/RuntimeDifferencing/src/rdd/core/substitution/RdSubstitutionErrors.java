package rdd.core.substitution;

import java.util.ArrayList;
import java.util.List;

public class RdSubstitutionErrors
{
	public List<RdSubstitutionError> _substitutionErrors = new ArrayList<RdSubstitutionError>();
}
