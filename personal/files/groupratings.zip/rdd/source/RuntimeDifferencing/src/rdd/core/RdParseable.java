package rdd.core;

import java.io.IOException;
import java.io.Reader;

public interface RdParseable
{
	public void parse(Reader reader, RdParsingState state, RdContext cxt, int flags) throws IOException;
}
