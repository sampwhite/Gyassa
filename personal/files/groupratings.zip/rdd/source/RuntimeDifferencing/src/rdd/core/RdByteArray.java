package rdd.core;

import java.io.IOException;
import java.io.OutputStream;

import rdd.core.io.IoUtils;

public class RdByteArray extends OutputStream
{
	public byte[] _buf;
	public int _len;
	
	@Override
	public void write(int b) throws IOException
	{
		// TODO Auto-generated method stub
		if (_buf == null || _len + 1 >= _buf.length)
		{
			prepareWrite(1);
		}
		_buf[_len++] = (byte)b;
		
	}

	@Override
	public void write(byte b[], int off, int len) throws IOException
	{
		prepareWrite(len);
		System.arraycopy(b, off, _buf, _len, len);
		_len += len;
	}
	
	public void prepareWrite(int len)
	{
		if (_buf == null || _len + len >= _buf.length)
		{
			byte b[] = new byte[3 * (_len + len) + IoUtils.STANDARD_LARGE_FILE_WRITE_BUFFER];
			if (_len > 0)
			{
				System.arraycopy(_buf, 0, b, 0, _len);
			}
			_buf = b;
		}
	}
	
	public void reset()
	{
		// Deliberately do NOT clear out _buf, this object is intended for intensive reuse.
		_len = 0;
	}

}
