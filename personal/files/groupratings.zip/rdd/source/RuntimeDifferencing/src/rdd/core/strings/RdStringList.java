package rdd.core.strings;

public interface RdStringList
{
	public String[][] getStringList();
}
