package rdd.core.strings;

public interface RdStringPackage
{
	public String[] getStringListClasses();
	public String[] getLanguageList();
}
