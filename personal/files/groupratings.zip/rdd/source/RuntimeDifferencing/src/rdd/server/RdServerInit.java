package rdd.server;

import rdd.core.RdContext;
import rdd.core.RdKey;
import rdd.core.RdTable;
import rdd.core.component.RdComponentUtils;

public class RdServerInit
{
	static public RdTable createEventRegistrationTable(RdContext cxt)
	{
		return new RdTable(
			new RdKey[]{
				RdComponentUtils.COMPONENT_NAME, 
				RdComponentUtils.COMPONENT_LOAD_TYPE,
				RdComponentUtils.COMPONENT_STATUS},
			new Object[][]{
				{"RuntimeDifferencing", "global", "enabled"},
				{"Jetty", "global", "enabled"},
				{"Database", "global", "enabled"},
			});
	}

}
