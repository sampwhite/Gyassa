package rdd.core.storage;


import rdd.core.RdData;
import rdd.core.RdTable;

public class RdFileList
{
	public RdTable _fileListTable;
	public RdData _fileListStorageData;
	
	public RdFileList(RdTable fileListTable, RdData fileListStorageData)
	{
		_fileListTable = fileListTable;
		_fileListStorageData = fileListStorageData;
	}
}
