package rdd.core.component;

import rdd.core.RdContext;
import rdd.core.RdContextUtils;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;

public class RdComponentUtils
{
	static public int FAST_COMPONENT_DATA_LOOKUP_INDEX = -1;
	static public RdKey COMPONENT_DATA_LOOKUP_KEY = RdGlobalKeys.registerGlobalKey(
		"ComponentData", RdKey.COMPLEX, RdKey.F_IS_NOT_SERIALIZABLE);
	static public boolean _isInit;
	static public boolean _syncObj[] = {false};
	
	//+section Columns of component list table 
	/**
	 * The component name
	 */
	static public RdKey COMPONENT_NAME = RdGlobalKeys.registerGlobalKey(
		"rdComponentName", RdKey.STRING);

	/**
	 * The load type of the component. A component can either be loaded at boot
	 * and then ignored, loaded as a standard global component, or loaded as an "app" component.
	 * If it is loaded as an application component, then it can be stored somewhere
	 * else then the default system shared storage location. An "app" component cannot
	 * load code to be executed by the global class loader, it can only load into
	 * the class loader attached to the application. If an application component is loaded
	 * into multiple applications then there is a separate instance of each component that
	 * is loaded.
	 */
	static public RdKey COMPONENT_LOAD_TYPE = RdGlobalKeys.registerGlobalKey(
		"rdComponentStorageType", RdKey.STRING);

	/**
	 * The component state which can be: disabled, enabled, or active. Disabled components
	 * are ignored, components that enabled but not active do not have their "init"
	 * resources loaded and acted on (but their "boot" resources are loaded and acted on).
	 */
	static public RdKey COMPONENT_STATUS = RdGlobalKeys.registerGlobalKey(
		"rdComponentStatus", RdKey.STRING);
	
	/**
	 * A short description of the component that is used by developers in source code
	 * controlled lists of components.
	 */
	static public RdKey COMPONENT_DESCRIPTION = RdGlobalKeys.registerGlobalKey(
		"rdComponentDescription", RdKey.STRING);
	//+endsection Columns of component list table
	
	//+section Component attributes
	/**
	 * The internal version of the component. The one to test against
	 * to see if one version of a component is more recent than another.
	 */
	static public RdKey COMPONENT_CODE_VERSION = RdGlobalKeys.registerGlobalKey(
		"ComponentCodeVersion", RdKey.STRING);
	
	/**
	 * The product version of the component. The version used to label the bundle that
	 * deploys the component and used when identifying the version in technical
	 * discussions.
	 */
	static public RdKey COMPONENT_DISPLAY_VERSION = RdGlobalKeys.registerGlobalKey(
		"ComponentDisplayVersion", RdKey.STRING);
	
	/**
	 * The date of the last significant edit of the component in YY_MM_DD format.
	 */
	static public RdKey COMPONENT_LAST_EDIT_DATE = RdGlobalKeys.registerGlobalKey(
		"ComponentLastEditDate", RdKey.STRING);
	
	/**
	 * The component features of the form:
	 * feature1(version),feature2(version),...
	 */
	static public RdKey COMPONENT_FEATURES = RdGlobalKeys.registerGlobalKey(
		"ComponentFeatures", RdKey.STRING);
	
	/**
	 * The required features from other components that are needed before this component
	 * can become "active". It is in the same format as for COMPONENT_FEATURES.
	 */
	static public RdKey COMPONENT_REQUIRED_FEATURES = RdGlobalKeys.registerGlobalKey(
		"ComponentRequiredFeatures", RdKey.STRING);
	//+endsection Component attributes

	/**
	 * Some components are made with hardwired references to optimize for typical use cases.
	 */
	static public RdComponentDefinition _globalSystemComponent = new RdComponentDefinition("system",
		RdComponentDefinition.F_IS_SYSTEM);
	static public RdComponentDefinition _globalDbstorageComponent = new RdComponentDefinition(
		"dbstorage", RdComponentDefinition.F_LARGE_STORAGE);
	
	static public void init(RdContext cxt)
	{
		FAST_COMPONENT_DATA_LOOKUP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(COMPONENT_DATA_LOOKUP_KEY);
		_isInit = true;
	}
	
	static public void setApplicationComponentData(RdContext cxt, RdComponentData data)
	{
		if (!_isInit)
		{
			init(cxt);
		}
		RdContextUtils.setSharedCachedObject(COMPONENT_DATA_LOOKUP_KEY, cxt, 
			"components", data, null);		
	}
	
	/**
	 * Uses fast lookup mechanics to get the RdConnectionData object for this application.
	 * @param cxt The current context.
	 * @return The string data for this application.
	 */
	static public RdComponentData getApplicationComponentData(RdContext cxt)
	{
		if (!_isInit)
		{
			init(cxt);
		}
		RdComponentData data = (RdComponentData)RdContextUtils.getFastCachedObject(
			FAST_COMPONENT_DATA_LOOKUP_INDEX, cxt);
		if (data == null)
		{
			synchronized (_syncObj)
			{
				data = (RdComponentData)RdContextUtils.getFastCachedObject(
					FAST_COMPONENT_DATA_LOOKUP_INDEX, cxt);
				if (data == null)
				{
					setApplicationComponentData(cxt, new RdComponentData());
				}
			}
		}
		return data;
	}
}
