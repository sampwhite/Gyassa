package rdd.core.merge;

import java.util.HashMap;
import java.util.Map;

import rdd.core.RdResourceKey;

public class RdDiffPackage
{
	/**
	 * The previous last edit counter. If your current data's counter is before this counter
	 * then you cannot apply this diff to it.
	 */
	public long _prevEditCounter;
	
	/**
	 * The counter of the last edit captured by this diff.
	 */
	public long _curEditCounter;
	
	/**
	 * Map of updates to apply.
	 */
	public Map<RdResourceKey,RdDiffItem> _diffItems;
	
	/**
	 * Constructor
	 */
	public RdDiffPackage(long prevCounter, long curCounter)
	{
		_prevEditCounter = prevCounter;
		_curEditCounter = curCounter;
		_diffItems  = new HashMap<RdResourceKey,RdDiffItem>();
	}
}
