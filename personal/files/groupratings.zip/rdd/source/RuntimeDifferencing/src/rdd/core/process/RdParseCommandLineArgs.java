package rdd.core.process;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import rdd.core.RdAppRegistry;
import rdd.core.RdContext;
import rdd.core.RdData;
import rdd.core.RdParsingState;
import rdd.core.io.IoUtils;

public class RdParseCommandLineArgs
{
	static public final int F_DO_SHOW_USAGE = 1;
	static public final int F_DO_READ_FILE = 2;
	static public final int F_USE_NODE_CONFIG_FILE = 4;
	static public final int F_DO_ALL = F_DO_SHOW_USAGE | F_DO_READ_FILE | F_USE_NODE_CONFIG_FILE;
	
	static public final String USAGE_KEY = "PrintCommandLineUsage";
	static public final String FILE_KEY = "CommandLineFile";
	static public final String NODE_CONFIG_KEY = "NodeConfigFile";
	
	public RdContext _parsedArgs;
	public RdParseCommandArgRule[] _parseRules;
	public int _abilityFlags;
	public boolean _printUsage;
	public boolean _readArgsFromFile;
	public String _commandLineFilePath;
	
	// Error reporting.
	public boolean _badArg;
	public String _badArgName;
	public boolean _valueHadDash;
	public boolean _noValueForKey;
	public boolean _isInvalidPath;
	public String _errMsg;
	public IOException _readException;
	
	public RdParseCommandLineArgs(String[][] parseRules, int flags, RdContext parsedArgs)
	{
		_parsedArgs = parsedArgs;
		if (_parsedArgs == null)
		{
			_parsedArgs = RdAppRegistry.getThreadWrapperContext();
		}
		_abilityFlags = flags;
		int numRules = parseRules.length; // Extra rule for -usage and -input.
		if ((_abilityFlags & F_DO_SHOW_USAGE) != 0)
		{
			numRules++;
		}
		if ((_abilityFlags & F_DO_READ_FILE) != 0)
		{
			numRules++;
		}
		if ((_abilityFlags & F_USE_NODE_CONFIG_FILE) != 0)
		{
			numRules++;
		}
		
		_parseRules = new RdParseCommandArgRule[numRules];
		int curIndex = 0;
		for (int i = 0; i < parseRules.length; i++)
		{
			_parseRules[curIndex++] = new RdParseCommandArgRule(parseRules[i]);
		}
		if ((_abilityFlags & F_DO_SHOW_USAGE) != 0)
		{
			_parseRules[curIndex++] = new RdParseCommandArgRule(new String[]{"usage", USAGE_KEY, "",
				"Prints out available arguments to executable"});
		}
		if ((_abilityFlags & F_DO_READ_FILE) != 0)
		{
			_parseRules[curIndex++] = new RdParseCommandArgRule(new String[]{"file", FILE_KEY, "path", 
				"Reads command line arguments from a file using config names to identify parameters"});
		}
		if ((_abilityFlags & F_USE_NODE_CONFIG_FILE) != 0)
		{
			_parseRules[curIndex++] = new RdParseCommandArgRule(new String[]{"nodeconfig", 
				NODE_CONFIG_KEY, "path", "Uses server node configuration specified by file"});
		}
	}
	
	public void parseArgs(String[] args, int flags)
	{
		List<String> unProcessedArgs = new ArrayList<String>();
		boolean nextIsValue = false;
		String curKey = null;
		String curArg = null;
		for (int i = 0; i < args.length; i++)
		{
			if (nextIsValue)
			{
				String val = args[i];
				if (val.startsWith("-"))
				{
					// Illegal value.
					_errMsg = "Illegal value " + val + " for argument of " + curArg;
					_badArg = true;
					_badArgName = curArg;
					_valueHadDash = true;
					break;
				}
				_parsedArgs.put(_parsedArgs, curKey, val);
				nextIsValue = false;
			}
			else
			{
				String arg = args[i];
				if (arg.startsWith("-"))
				{
					int offset = 1;
					if (arg.startsWith("--"))
					{
						offset = 2;
					}
					String argKey = arg.substring(offset);
					for (RdParseCommandArgRule rule : _parseRules)
					{
						// Simple pattern matching for now.
						if (rule._argPattern.equals(argKey))
						{
							curKey = rule._key;
							curArg = argKey;
							if ((rule._flags & RdParseCommandArgRule.F_HAS_VALUE) != 0)
							{
								nextIsValue = true;
							}
							else
							{
								_parsedArgs.put(_parsedArgs, curKey, Boolean.TRUE);
							}
							if (curKey.equals(USAGE_KEY))
							{
								_printUsage = true;
							}
							else if (curKey.equals(FILE_KEY))
							{
								_readArgsFromFile = true;
							}
						}
					}
				}
				else
				{
					unProcessedArgs.add(arg);
				}
			}
		}
		
		if (nextIsValue)
		{
			_badArg = true;
			_noValueForKey = true;
			_errMsg = "No value for argument of " + curArg;
			_printUsage = true;
		}
		if (!_printUsage)
		{
			// See if there is a path to read in.
			if (_readArgsFromFile)
			{
				CharSequence fileNameSeq = _parsedArgs.getS(FILE_KEY);
				String fileName = fileNameSeq.toString();
				_commandLineFilePath = IoUtils.createAbsolutePath(null, fileName, _parsedArgs,
					IoUtils.F_USE_DEFAULTS);
				if ((flags & F_DO_READ_FILE) != 0)
				{
					readCommandFile();
				}
		}
		}
		if (!_printUsage)
		{
			// Go through and validate paths.
			for (RdParseCommandArgRule rule : _parseRules)
			{
				if ((rule._flags & RdParseCommandArgRule.F_IS_PATH) != 0)
				{
					CharSequence path = _parsedArgs.getS(rule._key);
					if (path.length() > 0)
					{
						String fullPath = IoUtils.createAbsolutePath(null, path, _parsedArgs,
							IoUtils.F_USE_DEFAULTS);
						File f = new File(fullPath);
						if (!f.exists())
						{
							// A bad file specification.
							_badArg = true;
							_errMsg = "File " + fullPath + " cannot be found for command line argument " + rule._key;
							_printUsage = true;
						}
					}
				}
			}
		}
		if (_printUsage)
		{
			if ((flags & F_DO_SHOW_USAGE) != 0)
			{
				printErrorAndUsage();
			}
		}
		else
		{
			RdProcessConfig._processArgs = _parsedArgs.getLocalData();
			if (RdProcessConfig._appType == null)
			{
				String appType = System.getProperty("apptype");
				if (appType == null)
				{
					appType = (_abilityFlags & F_USE_NODE_CONFIG_FILE) != 0 ? "server" : "client";
				}
				RdProcessConfig._appType = appType;
			}
		}
	}
	
	public void printErrorAndUsage()
	{
		if (_badArg)
		{
			System.err.println(_errMsg);
			if (_readException != null)
			{
				System.err.println(_readException);
				_readException.printStackTrace(System.out);
			}
		}
		printUsage();
	}
	
	public void printUsage()
	{
		System.out.println("Usage:\n");
		for (RdParseCommandArgRule rule : _parseRules)
		{
			String argument = "<noargument>";
			if ((rule._flags & RdParseCommandArgRule.F_IS_PATH) != 0)
			{
				argument = "<path-arg>";
			}
			else if ((rule._flags & RdParseCommandArgRule.F_HAS_VALUE) != 0)
			{
				argument = "<var-arg>";
			}
			System.out.println("-" + rule._argPattern + " " + argument + " " + rule._description + 
				((rule._argPattern.equals("file") || rule._argPattern.equals("usage")) ? "" : 
					" (config name is " +  rule._key + ")"));
		}
	}
	
	public void readCommandFile()
	{
		String absolutePath = _commandLineFilePath;
		
		try
		{
			Reader r = IoUtils.openBufferedReader(absolutePath, IoUtils.F_USE_DEFAULTS);
			Map localData = _parsedArgs.getLocalData();
			RdData data = new RdData();
			RdParsingState parsingState = new RdParsingState(absolutePath, _parsedArgs);
			data.parse(r, parsingState, _parsedArgs, 0);
			localData.putAll(data);
		}
		catch (IOException e)
		{
			_readException = e;
			_badArg = true;
			_errMsg = "Error reading file " + absolutePath + " for program arguments. " + e.getMessage();
			_printUsage = true;
		}
	}
}
