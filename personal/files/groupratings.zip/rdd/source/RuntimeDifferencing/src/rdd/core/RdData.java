package rdd.core;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import rdd.core.resource.RdResourceFormat;


/**
 * A multi-purpose data object used for a great variety of types of data. Some of the attributes in this
 * object will not be of relevance unless the object is being used for a specific type of data. The intent
 * is that this object be used instead of a generic map object any time lookup is being used by "well defined variables".
 */
public class RdData implements RdAppender, RdParseable, Map<RdKey,Object>, Cloneable, RdCloneable
{
	//+section RdData types.
	static public int GENERIC = 0;
	static public int RESOURCE_CONTAINER = 1;
	//+endsection RdData types.
	
	/**
	 * The purpose and utility of this data object.
	 */
	public int _type;
	
	/**
	 * Flags from RdDataFlags.
	 */
	public int _flags;
	
	/**
	 * If storage location specifies a load order for determining order of merges with other
	 * RdData objects, then this attribute has it.
	 */
	public int _loadOrder;
	
	/**
	 * Other resource data (such as strings, includes, etc.) that may have been loaded. Also will contain
	 * comments for loaded attributes.
	 */
	public List<RdResourceDefinition> _resourceData;
	
	/**
	 * Data that has been pushed up the search tree (the equivalent of "defaults" for the Properties object).
	 */
	public Map<RdKey,Object> _pushedData;
	
	/**
	 * The live modifiable data of this object.
	 */
	public Map<RdKey,Object> _currentData;
	
	//+section Special purpose attributes for variants used for specific purposes
	/**
	 * If this data is defining extra key properties, then some of that data will be found
	 * to fast look up attributes here.
	 */
	public RdResourceDefinition _resourceDefinition;
	
	//+endsection Special purpose attributes for variants used for specific purposes
	
	public RdData()
	{
		_currentData = new IdentityHashMap<RdKey,Object>();
	}
	
	/**
	 * Constructs a map object that has fall back lookup into the pushedData parameter.
	 * @param pushedData The data to be searched if a key cannot be found in the current
	 * data.
	 */
	public RdData(Map<RdKey,Object> pushedData)
	{
		_pushedData = pushedData;
		_currentData = new IdentityHashMap<RdKey,Object>();
	}
	
	/**
	 * This constructor is usually used when the RdData is going to support concurrent modification
	 * in which case the type parameter must be RdDataFlags.F_READ_ONLY | RdDataFlags.F_THREAD_SAFE and
	 * the Maps need to support synchronization (such as ConcurrentHashMap).
	 * @param type One of the supported types of Data objects.
	 * @param curData The data to be exposed through the map interface.
	 * @param pushedData THe data to be searched if a key cannot be found in curData.
	 */
	public RdData(int type, Map<RdKey,Object> curData, Map<RdKey,Object> pushedData)
	{
		_type = type;
		_pushedData = pushedData;
		_currentData = curData;
	}
	
	/**
	 * Constructs an RdData object as a HashMap equivalent but with flags to control whether it allows concurrent modification.
	 */
	public RdData(int flags)
	{
		if ((flags & RdDataFlags.F_THREAD_SAFE) != 0)
		{
			_currentData = new ConcurrentHashMap<RdKey,Object>();
		}
		else
		{
			_currentData = new IdentityHashMap<RdKey,Object>();
		}
		_flags = flags;
	}
	
	public RdValue getV(RdKey key)
	{
		RdValue retVal = RdDataUtils.getWithCoercion(_currentData, key, _flags);
		
		if ((retVal == null || retVal == RdGlobalValues.ORIGINALLY_NULL_VALUE) && _pushedData != null)
		{
			retVal = RdDataUtils.getWithCoercion(_pushedData, key, _flags);
		}
		if (retVal == null)
		{
			retVal = RdGlobalValues.ORIGINALLY_NULL_VALUE;
		}
		return retVal;
	}
	
	//+ section Implementation of Map interface
	@Override
	public int size()
	{
		return _currentData.size();
	}
	@Override
	public boolean isEmpty()
	{
		return _currentData.isEmpty();
	}
	@Override
	public boolean containsKey(Object key)
	{
		// TODO Auto-generated method stub
		return _currentData.containsKey(key);
	}
	@Override
	public boolean containsValue(Object value)
	{
		// TODO Auto-generated method stub
		return _currentData.containsValue(value);
	}
	/**
	 * This method violates consistency with other methods because
	 * it will search into _pushedData as well.
	 */
	@Override
	public Object get(Object key)
	{
		Object result = _currentData.get(key);
		if (result == null && _pushedData != null)
		{
			result = _pushedData.get(key);
		}
		return result;
	}
	@Override
	public Object put(RdKey key, Object value)
	{
		value = RdDataUtils.cooerceToSettableValue(key, value, _flags);
		return _currentData.put(key, value);
	}
	@Override
	public Object remove(Object key)
	{
		return _currentData.remove(key);
	}
	@Override
	public void putAll(Map<? extends RdKey, ? extends Object> m)
	{
		if ((_flags & RdDataFlags.F_READ_ONLY) != 0)
		{
			// Have to do it the slow way.
			Set<? extends RdKey> s= m.keySet();
			for (RdKey key : s)
			{
				Object v = m.get(key);
				put(key, v);
			}
		}
		else
		{
			_currentData.putAll(m);
		}
	}
	@Override
	public void clear()
	{
		_currentData.clear();
	}
	@Override
	public Set<RdKey> keySet()
	{
		return _currentData.keySet();
	}
	@Override
	public Collection<Object> values()
	{
		return _currentData.values();
	}
	@Override
	public Set<java.util.Map.Entry<RdKey, Object>> entrySet()
	{
		// TODO Auto-generated method stub
		return _currentData.entrySet();
	}
//+endsection Implementation of Map interface
	
	/**
	 * A simple depth 1 clone that will not have synchronization protection.
	 */
	@Override
	public Object clone()
	{
		RdData newData = new RdData(_pushedData);
		newData.putAll(_currentData);
		return newData;
	}
	
	public RdData shallowClone()
	{
		RdData newData = new RdData(_pushedData);
		newData._type = _type;
		newData._flags = _flags;
		newData._currentData = _currentData;
		return newData;
	}
	
	//+section RdCloneable interface
	@Override
	public Object clone(int depth, RdContext cxt)
	{
		RdData newData = shallowClone();
		if (depth > 0)
		{
			newData._currentData = (Map<RdKey,Object>)RdCloner.cloneObject(_currentData, 
				depth - 1, cxt);
			newData._flags &= ~RdDataFlags.F_READ_ONLY;
		}
		return newData;
	}
	//+endsection RdCloneable interface 


//+section Implementation of RdAppender interface
	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags) throws IOException
	{
		Set<RdKey> alreadyProcessedKeys = new HashSet<RdKey>();
		if (_resourceData != null)
		{
			for (RdResourceDefinition res : _resourceData)
			{
				RdResourceFormat.appendResource(res, this, appendable, key, alreadyProcessedKeys, depth, cxt, flags);
				flags |= RdContext.F_IS_NOT_FIRST;
			}
		}
		
	    // Any values that do not have explicit layout, we do here.
		Set<RdKey> keySet = keySet();
		List<RdResourceDefinition> resDefs = new ArrayList<RdResourceDefinition>();
		for (RdKey dataKey : keySet)
		{
			if ((dataKey.isSerializableValue() || ((flags & RdContext.F_DEBUG_FORMAT) != 0))
				&& !alreadyProcessedKeys.contains(dataKey))
			{
				int resType = RdResourceTypes.determineResourceTypeFromValueType(dataKey._type, RdResourceTypes.NAMEVALUE);
				RdResourceKey resKey = RdResourceUtils.getOrCreateResourceKey(resType, dataKey._name);
				RdResourceDefinition resDef = new RdResourceDefinition(resKey, null);
				resDef._key = dataKey;
				resDefs.add(resDef);
			}
		}
		Collections.sort(resDefs);
		
		for (RdResourceDefinition resDef : resDefs)
		{
			RdResourceFormat.appendResource(resDef, this, appendable, key, alreadyProcessedKeys, depth, cxt, flags);
			flags |= RdContext.F_IS_NOT_FIRST;
		}
		
		if ((flags & RdContext.F_DEBUG_FORMAT) != 0 && _pushedData != null)
		{
			if ((flags & RdContext.F_IS_NOT_FIRST) != 0)
			{
				appendable.append("\n");
			}
			for (int i = 0; i < depth; i++)
			{
				appendable.append("[");
			}
			appendable.append("[_pushedData.start");
			RdResourceFormat.formatKeyMap(appendable, _pushedData, cxt, key, depth + 1, flags);
			appendable.append("\n_pushedData.end]");
			for (int i = 0; i < depth; i++)
			{
				appendable.append("]");
			}
		}
	}
//+endsection Implementation of RdAppender interface


//+section Implementation of RdParseable interface
	@Override
	public void parse(Reader reader, RdParsingState state, RdContext cxt, int flags) throws IOException
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		if (state == null)
		{
			state = new RdParsingState("<reader>", cxt);
		}
		List<RdResourceDefinition> resources = new ArrayList<RdResourceDefinition>();
		RdResourceFormat.parseResources(reader, resources, state, cxt, flags);
		if (!state._failed)
		{
			for (RdResourceDefinition res : resources)
			{
				if (res._isDataValue)
				{
					_currentData.put(res._key, res._parsedObject);
				}
			}
		}
		_resourceData = resources;
	}
//+endsection Implementation of RdParseable interface
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
