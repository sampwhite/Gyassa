package rdd.security;

import java.util.List;

import rdd.core.RdData;

public class RdSecurityGroup
{
	//+section Hardwired group domains
	static public String LOCAL_DOMAiN = "#";
	static public String USER_NAME_PREFIX = "&";
	//+endsection
	
	/** Possible features of user group. These flags are meant to be used
	 * as filters for choice lists.
	 **/
	//+section User group flags
	/**
	 * The group is a wrapper for a user. Every user has a group associated with them
	 * automatically. Generally such a group is F_IS_USER_LIST and F_IS_DATA_GROUP as
	 * well. If the user is locally defined (not from a central user store), then
	 * F_IS_LOCAL is set as well.
	 */
	static public final int F_IS_USER = 1;
	
	/**
	 * Group can be used for sending notifications (such as email). It will show
	 * up in drop down lists for notification targets. In this case the the group
	 * is presumed to have an easily calculated user and group membership list.
	 */
	static public final int F_IS_USER_LIST = 2;
	
	/**
	 * The group can be used to grant privileges. In this case it is assumed that
	 * a particular user or group can quickly determine (following membership relationships
	 * as well) which privilege groups the user or group is in and that the list
	 * of such groups is fairly small.
	 */
	static public final int F_IS_PRIVILEGE_GROUP = 4;
	
	/**
	 * The group is a local group. The group is defined and managed by a local application
	 * or server and not by a global user storage service (such as LDAP).
	 */
	static public final int F_IS_LOCAL = 8;
	
	/**
	 * The group is a container group. A user (or group) that has been granted rights to
	 * a child group is granted rights to the container.
	 */
	static public final int F_IS_CONTAINER = 16;
	
	/**
	 * The group can be assigned as an attribute to data (for example it can be a value in
	 * a column of a table). In some cases it can be multiply assigned. The group will
	 * show up in selection lists for groups to assign to a particular data object or
	 * row in a database table.
	 */
	static public final int F_IS_DATA_GROUP = 32;
	
	/**
	 * The group is a propagating group. If the group is assigned as an attribute to data,
	 * then any child groups will be assigned as well. Changing propagation children can
	 * be an expensive process because of all the data that may need to be changed as a result.
	 * Only data that allows complex security models with multi-valued group assignments supports 
	 * this option.
	 */
	static public final int F_IS_PROPAGATING_GROUP = 64;
	
	/**
	 * The groups security relationship is rule or criteria based. For example, the group Everyone
	 * is a group that every user has rights to. If this flag is set, then this group will
	 * not be created using a typical querying process.
	 */
	static public final int F_IS_RULE_BASED_GROUP = 128;
	//+section End section.
	
	/**
	 * Domain or organization path of this group. Local groups have an organization path of #. The
	 * organization path is used to eliminate naming conflicts. If the organization path
	 * can be made shorter and still guarantee that names will not conflict (or such conflicts
	 * can be tolerated), then the shorter organization path should be tolerated. The only
	 * requirement is that given the organization path and the name, the definition of the group
	 * can be successfully retrieved from external storage.
	 */
	public String _orgPath;
	
	/**
	 * The name of the group. The name is only unique within any given organization path. If the
	 * group is a wrapper for a user name, then the group name is the user name prefixed
	 * by an &. In any given application, there should be exactly one RdGroup object
	 * with a given name and organization path. Two groups can compare object addresses to
	 * see if they are the same group (speeding up some security checks).
	 */
	public String _name;
	
	/**
	 * The description of the group.
	 */
	public String _description;
	
	/**
	 * The flags indicating features about this group (see flags above).
	 */
	public int _flags;
	
	/**
	 * If the group has F_IS_CONTAINER set, then these are the child groups that grant privilege
	 * to this group. Generally, a security system will be unscalable if more than 5% of groups
	 * have more than 10 groups in this array.
	 */
	public List<RdSecurityGroup> _childGroups;
	
	/**
	 * If the group has F_IS_PROPAGATING_GROUP, then any resource or data that has this
	 * group assigned to it, will have all these groups assigned as well. Generally, a
	 * security system will be unscalable. if more than 5% of groups have more than 5 groups in
	 * this array. Note that the effect of this list on a user's ability to access data
	 * is the same as the _childGroups attribute, the only difference is implementation. In
	 * particular, if a user is granted privilege rights to either a group in the _childGroups or
	 * _propagatedGroups list they will get the rights granted by this group to a data object.
	 */
	public List<RdSecurityGroup> _propagatedGroups;
	
	/**
	 * Any other interesting properties about the group.
	 */
	public RdData _properties;
}
