package rdd.core;

public class RdDataFlags
{
	/**
	 * Content of object is likely from a cache. It can be modified but only if you want to impact access by
	 * others accessing the object simultaneously. Also, accessing this object may have thread safety implications.
	 */
	static public final int F_READ_ONLY = 1;
	
	/**
	 * Object is a shared copy, but the stored version may be in a container which was created by this thread. Modifying
	 * this object will modify the version that is stored, but if F_READ_ONLY is not set, then it is safe to modify.
	 */
	static public final int F_SHARED_COPY = 2;
	
	/**
	 * This object supports concurrent modification. Flag is only relevant if F_READ_ONLY is true.
	 * In that case, unless this flag is set, it is not safe to change the contents of the object.
	 */
	static public final int F_THREAD_SAFE = 4;
	
	/**
	 * Used for RdTable objects. If this flag is set, then an auxiliary column has been created
	 * that tracks the row count. This allows the indexed rows to know precisely where they
	 * came from in the original table.
	 */
	static public final int F_HAS_ROW_TRACKING_COUNTERS = 8;
	
	/**
	 * Specifies whether the object has a load order that determines the order in which
	 * a merge should be done with other RdData objects that share a common RdResourceKey lookup
	 * key for some of their values.
	 */
	static public final int F_HAS_LOAD_ORDER = 16;
	
	static public boolean canModify(int flags)
	{
		return ((flags & (F_READ_ONLY | F_THREAD_SAFE)) != F_READ_ONLY);
	}
	
	static public int setIsSharedFlag(int containerFlags, int curFlags)
	{
		curFlags |= F_SHARED_COPY;
		if ((containerFlags & F_READ_ONLY) != 0)
		{
			curFlags |= F_READ_ONLY;
		}

		return curFlags;
	}
}
