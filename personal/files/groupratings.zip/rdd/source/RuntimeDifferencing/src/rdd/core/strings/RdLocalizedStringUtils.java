package rdd.core.strings;

import java.util.Locale;

import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdContextUtils;
import rdd.core.RdErrorCodes;
import rdd.core.RdException;
import rdd.core.RdFastKeyLookupInfo;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdResourceKey;
import rdd.core.RdResourceTypes;
import rdd.core.RdResourceUtils;
import rdd.core.logger.RP;
import rdd.core.primitives.StrUtils;

public class RdLocalizedStringUtils
{
	static public String _systemLangId;
	static public RdKey _systemLangKey;
	
	/**
	 * Strings are initialized so that the language index is always 0 for the system strings.
	 */
	static public final int SYSTEM_LANG_INDEX = 0;
	static public String ENGLISH_LANG = "en";
	static public RdKey ENGLISH_LANG_KEY;
	static public int _englishIndex = 0;
	
	static public RdFastKeyLookupInfo _stringLanguageIdFastLookupIndices = 
		new RdFastKeyLookupInfo("strings");
	
	static public int FAST_STRINGS_LOOKUP_INDEX = -1;
	static public RdKey STRINGS_LOOKUP_KEY = RdGlobalKeys.registerGlobalKey("RdLocalizedStrings", 
		RdKey.COMPLEX, RdKey.F_IS_NOT_SERIALIZABLE);
	
	static public void initLocalizedStringEnvironment(RdContext cxt)
	{
		FAST_STRINGS_LOOKUP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(STRINGS_LOOKUP_KEY);
		RdContextUtils.setSharedCachedObject(STRINGS_LOOKUP_KEY, cxt, "strings", 
			new RdLocalizedStrings(), null);
		ENGLISH_LANG_KEY = getLanguageIdKey(ENGLISH_LANG, cxt);
	}
	
	static public void loadStringsFromPackage(RdStringPackage strPackage, RdContext cxt)
		throws RdException
	{
		// Determine our current locale.
		Locale systemLocale = Locale.getDefault();
		String lang = systemLocale.getLanguage();
		String country = systemLocale.getCountry();
		String[] stringListClasses = strPackage.getStringListClasses();
		String[] langIds = strPackage.getLanguageList();
		String matchingLang = null;
		synchronized (_stringLanguageIdFastLookupIndices)
		{
			if (_stringLanguageIdFastLookupIndices._numRegisteredKeys == 0)
			{
				for (String translatedLangId : langIds)
				{
					// We are going to assume the language IDs are in alignment with the Java VM's.
					// At some point there may need to be a mapping table. Creating a Locale
					// object around "translatedLangId" and then testing does not handle the country code
					// very well. The "translatedLangId" is typically of the form
					// xx_yy with xx being the language and yy being the country.
					if (StrUtils.matchesRangeIgnoreCase(translatedLangId, lang, 0, 2))
					{
						if (StrUtils.matchesRangeIgnoreCase(translatedLangId, country, 3, 2))
						{
							// Exact hit for both language and country, need to go no further.
							matchingLang = translatedLangId;
							break;
						}
						// Default to languages earlier in the list.
						if (matchingLang == null)
						{
							matchingLang = translatedLangId;
						}
					}
				}
				
				// Bias towards English.
				if (matchingLang == null)
				{
					matchingLang = ENGLISH_LANG;
				}
				_systemLangId = matchingLang;
				_systemLangKey = getLanguageIdKey(_systemLangId, cxt);
				
				// The system language is always at index 0.
				_stringLanguageIdFastLookupIndices.getOrRegisterKeyIndex(_systemLangKey);
				
				// Get the English language index.
				if (ENGLISH_LANG_KEY != _systemLangKey)
				{
					_englishIndex = _stringLanguageIdFastLookupIndices.getOrRegisterKeyIndex(ENGLISH_LANG_KEY);
				}
			}
		}
		
		for (String listClass : stringListClasses)
		{
			for (String translatedLangId : langIds)
			{
				loadStrings(listClass, translatedLangId, cxt);
			}
		}
	}
	
	static public RdKey getLanguageIdKey(String langId, RdContext cxt)
	{
		RdCharArray tempArray = cxt.temporaryAllocateCharArray();
		tempArray.prepareForAppend(langId.length() + 5);
		RdKey retVal = null;
		try
		{
			tempArray.append("lang_");
			tempArray.append(langId);
			for (int i = 5; i < tempArray._len; i++)
			{
				char ch = tempArray._chars[i];
				if (ch >= 'A' && ch <= 'Z')
				{
					ch = (char)(ch + ('a' - 'A'));
				}
				else if (ch == '.' || ch == ' ' || ch == ':')
				{
					ch = '_';
				}
				tempArray._chars[i] = ch;
			}
			
			// For those examining the variable using a debugger.
			tempArray._toStringCache = null;
			
			// Get the RdKey.
			retVal = cxt.getEquivalentKeyObject(tempArray, RdContext.F_CREATE_IF_MISSING);
		}
		catch (Exception ignore)
		{
			RP.errT(ignore);
		}
		return retVal;
	}
	
	/**
	 * Gets the array index into the _localizedStrings attribute of the RdStringData class
	 * to use when looking up a particular language's version of a localized string.
	 * @param key Key to translate into an integer array index. Usually this parameter
	 * is created using the method getLanguageIdKey.
	 * @param cxt Current context
	 * @return An index to use when looking up this language's localized string.
	 */
	static public int getOrRegisterLangIdIndex(RdKey key, RdContext cxt)
	{
		return _stringLanguageIdFastLookupIndices.getOrRegisterKeyIndex(key);
	}
	
	/**
	 * Uses fast lookup mechanics to get the RdLocalizedStrings objects for this application.
	 * @param cxt The current context.
	 * @return The string data for this application.
	 */
	static public RdLocalizedStrings getLocalizedStrings(RdContext cxt)
	{
		return (RdLocalizedStrings)RdContextUtils.getFastCachedObject(FAST_STRINGS_LOOKUP_INDEX, cxt);
	}
	
	/**
	 * Stores strings into the global environment. This method is only called during
	 * the boot up period and is used for large super static (typical would be 5000+
	 * strings with two month iterations between getting the next translations incorporated)
	 * bundles that are programatically managed by utilities. The base RDD core localizes
	 * all its strings using this approach.
	 * @param stringsClassName The root name of the Java class that holds
	 * localized strings and implements the interface RdStringList.
	 * @param langId The specific languages desired. It is suffixed with an
	 * underscore separator to the stringsClassName to compute the specific
	 * Java class to instantiate.
	 * @param cxt The current context with access to the global environment.
	 * @throws RdException
	 */
	static public void loadStrings(String stringsClassName, String langId, RdContext cxt) 
		throws RdException
	{
		String localizedClassName = stringsClassName + "_" + langId;
		
		// First see if we can actually find the class.
		RdStringList stringList = null;
		try
		{
			Class c = Class.forName(localizedClassName);
			
			Object o = c.newInstance();
			
			// For now, assume object implements our own custom interface, in the future
			// we may look to see if the object is a ResourceBundle.
			stringList = (RdStringList)o;
		}
		catch (Exception e)
		{
			RdException rde = new RdException(RdErrorCodes.RESOURCE_NOT_FOUND, 
				"rdceStringResourceFailedToLoad", stringsClassName, langId);
			rde.initCause(e);
			throw rde;
		}
		RdKey langKey = getLanguageIdKey(langId, cxt);
		int langIndex = getOrRegisterLangIdIndex(langKey, cxt);
		RdLocalizedStrings stringsContainer = getLocalizedStrings(cxt);
		
		String[][] strings = stringList.getStringList();
		for (String[] pair : strings)
		{
			String key = pair[0];
			String localizedString = pair[1];
			RdResourceKey resKey = RdResourceUtils.getOrCreateResourceKey(RdResourceTypes.STRING, key);
			RdStringData strData = stringsContainer.getOrCreateStringData(resKey);
			addLocaleString(strData, langIndex, localizedString);
		}
	}
	
	/**
	 * Utility method to place a locale string at its proper index into the structure that
	 * holds all the translations for a particular string key.
	 * @param strData The structure that holds all the translations.
	 * @param langIndex The index at which this particular string can be found.
	 * @param localizedString The version of the string for this particular language index.
	 */
	static public void addLocaleString(RdStringData strData, int langIndex, String localizedString)
	{
		synchronized (strData)
		{
			if (strData._localizedStrings == null || langIndex >= strData._localizedStrings.length)
			{
				int numLangs = _stringLanguageIdFastLookupIndices._numRegisteredKeys;
				String[] stringArray = new String[numLangs];
				if (strData._localizedStrings != null)
				{
					System.arraycopy(strData._localizedStrings, 0, stringArray, 0, 
						strData._localizedStrings.length);
				}
				strData._localizedStrings = stringArray;
			}
			strData._localizedStrings[langIndex] = localizedString;
		}
	}
	
	/**
	 * Convenience method for calling RdResourceUtils.getOrCreateResourceKey with
	 * the appropriate parameters.
	 * @param key The string version of a key that will look up a localized version
	 * of a resource key.
	 * @param cxt The current context.
	 * @return The RdResourceKey global object (unique globally for each key).
	 */
	static public RdResourceKey getResourceKeyForStringKey(String key, RdContext cxt)
	{
		return RdResourceUtils.getOrCreateResourceKey(RdResourceTypes.STRING, key);
	}
	
	/**
	 * Gets a localized version of string (the localized version may have substitution parameters).
	 * The langIndex should either be SYSTEM_LANG_INDEX or retrieved from RdUser. The
	 * stringId can be retrieved using getResourceKeyForStringKey.
	 * @param langIndex The language index registered using the method getOrRegisterLangIdIndex
	 * @param stringId The global unique identifier for the localized variants for a particular
	 * string key.
	 * @param cxt The current context
	 * @return The string to use in formatting a localized output for end users.
	 */
	static public String getLocalizedString(int langIndex, RdResourceKey stringId, RdContext cxt)
	{
		if (_stringLanguageIdFastLookupIndices._numRegisteredKeys == 0)
		{
			RP.error("system", "Localized string requested without initialization of string layer",
				null, cxt);
			return stringId._resourceName;
		}
		RdLocalizedStrings strings = getLocalizedStrings(cxt);
		RdStringData stringData = strings.getStringData(stringId);
		String retVal = null;
		if (stringData != null && stringData._localizedStrings != null)
		{
			if (langIndex < stringData._localizedStrings.length)
			{
				retVal = stringData._localizedStrings[langIndex];
			}
			if (retVal == null)
			{
				if (RP._isVerbose)
				{
					RdKey langId = null;
					if (langIndex < _stringLanguageIdFastLookupIndices._registeredKeys.size())
					{
						langId = _stringLanguageIdFastLookupIndices._registeredKeys.get(langIndex);
					}
					String langStr = (langId != null) ? langId._name : "<index: " + langIndex + ">";
					RP.debug("strings", "Localized string for key " + stringId._resourceName +
						" and language " + langStr + " is missing", cxt);
				}
				retVal = stringData._localizedStrings[SYSTEM_LANG_INDEX];
				if (retVal == null && SYSTEM_LANG_INDEX != _englishIndex)
				{
					retVal = stringData._localizedStrings[_englishIndex];
				}
			}
		}
		return retVal;
	}
}
