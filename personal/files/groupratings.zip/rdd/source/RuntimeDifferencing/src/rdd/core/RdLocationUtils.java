package rdd.core;

import java.util.HashMap;
import java.util.Map;

public class RdLocationUtils
{
	static public RdKey RD_LOCATION_MAP_KEY = RdGlobalKeys.registerGlobalKey("RdLocationMap",
		RdKey.MAP, RdKey.F_IS_NOT_SERIALIZABLE);
	
	/**
	 * The fast look up index for the map that binds a protocol path to a RdLocation object.
	 */
	static public int FAST_LOCATION_MAP_INDEX = -1;
	
	static public void init(RdContext cxt)
	{
		FAST_LOCATION_MAP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(RD_LOCATION_MAP_KEY);
		RdContextUtils.setSharedCachedObject(RD_LOCATION_MAP_KEY, cxt, "locations", 
			new HashMap<String,RdLocation>(), null);
	}
	
	static public RdLocation getLocationWrapper(String locationProtocol, RdContext cxt)
	{
		Map<String,RdLocation> locationMap = (Map<String,RdLocation>)
			RdContextUtils.getFastCachedObject(FAST_LOCATION_MAP_INDEX, cxt);
		RdLocation location;
		synchronized (locationMap)
		{
			location = locationMap.get(locationProtocol);
			if (location == null)
			{
				location = new RdLocation(locationProtocol);
				if (locationProtocol.startsWith("comp://"))
				{
					int endCompNameIndex = locationProtocol.indexOf('/', 8);
					if (endCompNameIndex < 0)
					{
						endCompNameIndex = locationProtocol.length();
					}
					
					location._componentName = locationProtocol.substring(7, endCompNameIndex);
					if (endCompNameIndex < locationProtocol.length() - 1)
					{
						location._relativePath = locationProtocol.substring(endCompNameIndex + 1);
					}
				}
				locationMap.put(locationProtocol, location);
			}
		}
		return location;
	}
	
	static public RdLocation getLocationWrapper(String compName, String relativePath, RdContext cxt)
	{
		Map<String,RdLocation> locationMap = (Map<String,RdLocation>)
			RdContextUtils.getFastCachedObject(FAST_LOCATION_MAP_INDEX, cxt);
		RdLocation location;
		synchronized (locationMap)
		{
			String protocolPath = "comp://" + compName + "/" + relativePath;
			location = locationMap.get(protocolPath);
			if (location == null)
			{
				location = new RdLocation(protocolPath);
				location._componentName = compName;
				location._relativePath = relativePath;
			}
		}
		return location;
	}
}
