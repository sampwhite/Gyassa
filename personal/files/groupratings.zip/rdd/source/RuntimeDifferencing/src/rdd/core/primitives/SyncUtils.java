package rdd.core.primitives;

import rdd.core.RdContext;

public class SyncUtils
{
	/**
	 * A more convenient sleep method. This method has no exceptions
	 * that need to be handed.
	 * @param milliseconds The amount to sleep.
	 * @param cxt The current context.
	 */
	static public void sleep(int milliseconds, RdContext cxt)
	{
		try
		{
			Thread.sleep(milliseconds);
		}
		catch (Throwable t)
		{
			// Total suppression.
		}
	}
}
