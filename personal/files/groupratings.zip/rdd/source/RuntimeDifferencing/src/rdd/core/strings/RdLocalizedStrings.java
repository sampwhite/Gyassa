package rdd.core.strings;

import java.util.HashMap;
import java.util.Map;

import rdd.core.RdDataFlags;
import rdd.core.RdResourceKey;

public class RdLocalizedStrings
{
	/**
	 * Strings that are loaded from static resources. Since strings can take up a lot
	 * of memory for large applications, it is best if multiple applications can
	 * share as much string data as possible.
	 */
	public RdLocalizedStrings _parentStrings;
	
	/**
	 * The string data for this object.
	 */
	public Map<RdResourceKey,RdStringData> _strings;
	
	public RdLocalizedStrings()
	{
		_strings = new HashMap<RdResourceKey,RdStringData>();
	}
	
	public synchronized RdStringData getStringData(RdResourceKey stringId)
	{
		RdStringData strData = _strings.get(stringId);
		if (strData == null && _parentStrings != null)
		{
			strData = _parentStrings.getStringData(stringId);
		}
		return strData;
	}
	
	public synchronized RdStringData getOrCreateStringData(RdResourceKey stringId)
	{
		
		RdStringData data =  _strings.get(stringId);
		if (data == null && _parentStrings != null)
		{
			data = _parentStrings.getStringData(stringId);
			if (data != null)
			{
				data._flags |= RdDataFlags.F_READ_ONLY | RdDataFlags.F_SHARED_COPY;
				_strings.put(stringId, data);
			}
		}
		if (data == null)
		{
			data = new RdStringData(stringId);
			_strings.put(stringId, data);
		}
		return data;
	}
}
