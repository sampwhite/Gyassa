package rdd.core.process;

import java.util.Map;

import rdd.core.RdKey;

public class RdProcessConfig
{
	static public Map<RdKey,Object> _processArgs;
	
	static public String _appType;
}
