package rdd.core;

/**
 * Wrapper for a protocol path that uniquely identifies where to find a package of data.
 * The RdLocation objects are uniquely defined for each possible canonical location and
 * are used to optimize maintenance of hash tables of cached resources.
 */
public class RdLocation
{
	/**
	 * A string that is sufficient to fully describe the location of the resource shource in
	 * a canonical way (another such string would point to another resource data source).
	 */
	public String _protocolPath;
	
	/**
	 * Component loaded from (if it was a component that provided the data).
	 */
	public String _componentName;
	
	/**
	 * Relative path inside component (if that is how protocol path is constructed).
	 */
	public String _relativePath;
	
	/**
	 * Simple constructor.
	 */
	public RdLocation(String protocolPath)
	{
		_protocolPath = protocolPath;
	}
	
	@Override
	public String toString()
	{
		return _protocolPath;
	}
}
