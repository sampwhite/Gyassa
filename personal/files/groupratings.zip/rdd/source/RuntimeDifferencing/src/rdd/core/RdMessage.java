package rdd.core;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import rdd.core.primitives.StrUtils;

/**
 * A message before it is localized.
 */
public class RdMessage implements RdAppender
{
	//+section Flags
	static public int F_IS_RAW_MESSAGE = 1;
	static public int F_IS_ENCODED_MESSAGE = 2;
	//+endsection
	
	public int _flags;
	public String _rawMsg;
	public String _encodedMsg;
	public String _msgKey;
	public Object[] _msgParams;
	public Map<String,Object> _msgExtraData;
	
	/**
	 * The preferred constructor.
	 * @param msgKey The lookup key for finding a localization of a string.
	 * @param msgParams The parameters to use to fill in the parameters of the string.
	 */
	public RdMessage(String msgKey, Object ... msgParams)
	{
		_msgKey = msgKey;
		_msgParams = msgParams;
	}
	
	/**
	 * Constructors used by other objects that are processors of messages.
	 * @param flags What type of message
	 * @param msgKey The key to lookup the message
	 * @param params Parameters to fill out the message.
	 */
	public RdMessage(int flags, String msgKey, Object[] params)
	{
		_msgKey = msgKey;
		_flags = flags;
		_msgParams = params;
	}
	
	/**
	 * Used for raw or unlocalized messages that have been put into an "encoded form".
	 * @param flags What type of message.
	 * @param msg The message to capture.
	 */
	public RdMessage(int flags, String msg)
	{
		
		if ((flags & F_IS_ENCODED_MESSAGE) != 0)
		{
			_encodedMsg = msg;
			_flags = flags;
		}
		else
		{
			_flags = F_IS_RAW_MESSAGE | flags;
			_rawMsg= msg;
		}
	}
	
	public void attachData(String key, Object data)
	{
		if (_msgExtraData == null)
		{
			_msgExtraData = new HashMap<String,Object>();
		}
		_msgExtraData.put(key, data);
	}
	
	public String getEncodedMessage()
	{
		RdContext cxt = RdAppRegistry.getThreadWrapperContext();
		RdCharArray temp = cxt.temporaryAllocateCharArray();
		try
		{
			appendTo(temp, null, 0, cxt, 0);
			
		}
		catch (Throwable t)
		{
			// Shouldn't happen, harass user if it happens because message reporting is broken.
			t.printStackTrace();
		}
		String msg = temp.toString();
		cxt.releaseTemporaryAllocatedCharArray(temp);
		return msg;
	}

	//+section RdAppender methods
	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags) throws IOException
	{
		appendable.append('^');
		appendable.append(_msgKey);
		if (_msgParams != null && _msgParams.length > 0)
		{
			RdCharArray tempVal = cxt.temporaryAllocateCharArray();
			appendable.append('(');
			for (int i = 0; i < _msgParams.length; i++)
			{
				if (i > 0)
				{
					appendable.append(',');
				}
				tempVal.reset();
				RdDataUtils.appendTo(tempVal, _msgParams[i], key, depth, cxt, 0);
				StrUtils.appendEncodedStr(appendable, tempVal, key, cxt, StrUtils.F_ENCODE_FUNCTION_CHARS);
			}
			appendable.append(')');
			cxt.releaseTemporaryAllocatedCharArray(tempVal);
		}
	}
	//+endsection RdAppender methods
	
	@Override
	public String toString()
	{
		return getEncodedMessage();
	}
}
