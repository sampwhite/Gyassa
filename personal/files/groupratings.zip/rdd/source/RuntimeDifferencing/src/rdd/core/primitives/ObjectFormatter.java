package rdd.core.primitives;

import rdd.core.RdContext;

/**
 * Used to allow low level primitive classes access to application functionality.
 */
public interface ObjectFormatter
{
	public void appendFormattedObject(Appendable appendable, Object obj, RdContext cxt, int flags);
}
