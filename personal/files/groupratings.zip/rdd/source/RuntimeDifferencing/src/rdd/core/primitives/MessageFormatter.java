package rdd.core.primitives;

import java.io.IOException;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.logger.RP;

/**
 * We have our own message formatter for performance reasons.
 */
public class MessageFormatter
{
	static public ObjectFormatter _objectFormatter;
	
	static public CharSequence createFormattedMessage(CharSequence str, RdContext cxt,
		Object ... params)
	{
		RdCharArray array = new RdCharArray();
		appendFormattedMessage(array, str, 0, str.length(), params, cxt, 0);
		return array;
	}
	
	static public void appendFormattedMessage(Appendable appendable, CharSequence str, int start, 
		int end, Object[] params, RdContext cxt, int flags)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		char[] buf = null;
		if (str instanceof RdCharArray)
		{
			buf = ((RdCharArray)str)._chars;
		}
		int startIndex = start;
		boolean foundLeftBrace = false;
		int startLeftBraceIndex = -1;
		try
		{
			for (int i = start; i < end; i++)
			{
				char ch = (buf != null) ?  buf[i] : str.charAt(i);
				if (foundLeftBrace)
				{
					if (ch == '}')
					{
						appendable.append(str, startIndex, startLeftBraceIndex);
						int paramIndex = RdConversions.convertToInteger(str, 
							startLeftBraceIndex + 1, i, -1) - 1;
						if (params != null && paramIndex >= 0 && paramIndex < params.length)
						{
							Object o = params[paramIndex];
							if (_objectFormatter != null)
							{
								_objectFormatter.appendFormattedObject(appendable, o, cxt, flags);
							}
							else
							{
								appendable.append("" + o);
							}
						}
						startIndex = i + 1;
						foundLeftBrace = false;
					}
					else if (ch == '{' && i == startLeftBraceIndex + 1)
					{
						//  Escape syntax for left brace.
						appendable.append(str, startIndex, startLeftBraceIndex + 1);
						startIndex = i + 1;
						foundLeftBrace = false;
					}
				}
				else if (ch == '{')
				{
					foundLeftBrace = true;
					startLeftBraceIndex = i;
				}
			}
			if (startIndex < end)
			{
				appendable.append(str, startIndex, end);
			}
		}
		catch (IOException e)
		{
			RP.errT(e);
		}
	}
}
