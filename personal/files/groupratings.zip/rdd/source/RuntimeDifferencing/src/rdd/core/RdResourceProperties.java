package rdd.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import rdd.core.primitives.MapUtils;
import rdd.core.primitives.RdConversions;
import rdd.core.strings.RdLocalizedStringUtils;

public class RdResourceProperties implements RdAppender, RdParseMapCallback
{
	//+section Merge Types
	static public final int MERGE = 0;
	static public final int REPLACE = 1;
	static public final int APPEND = 2;
	static public String MERGE_TYPE_LABELS[] = {"merge", "replace", "append"};
	//+endsection Merge Types
	
	static public final RdCharArray PRIMARY_KEY_ARRAY = new RdCharArray("primarykey");
	static public final RdCharArray MERGE_KEY_TYPE_ARRAY = new RdCharArray("type");
	static public final RdCharArray MERGE_KEY_FROM_ARRAY = new RdCharArray("keyfrom");
	static public final RdCharArray MERGE_KEY_TO_ARRAY = new RdCharArray("keyto");
	static public final RdCharArray MERGE_KEY_IS_CASE_INSENSITIVE = new RdCharArray("iscaseinsensitive");
	static public final RdCharArray LANG_ARRAY = new RdCharArray("lang");
	static public final RdCharArray MERGE_BLANKS = new RdCharArray("blanks");
	
	static public final RdCharArray MERGE_PREFIX_ARRAY = new RdCharArray("merge");
	
	// Branching on first character (and looking through common prefixes).
	static public final int MERGE_PREFIX_INDEX = 0;
	static public final int PRIMARY_KEY_INDEX = 1;
	static public final int LANG_INDEX = 2;
	static public final RdCharArray[] PREFIX_TEST_ARRAYS = {MERGE_PREFIX_ARRAY, PRIMARY_KEY_ARRAY, LANG_ARRAY};
	static public final int MERGE_TYPE_INDEX = 0;
	static public final int MERGE_KEY_FROM_INDEX = 1;
	static public final int MERGE_KEY_TO_INDEX = 2;
	static public final int MERGE_BLANKS_INDEX = 3;
	static public final int MERGE_IS_CASE_INSENSITIVE = 4;
	static public final RdCharArray[] MERGE_ARRAYS = {MERGE_KEY_TYPE_ARRAY, MERGE_KEY_FROM_ARRAY, 
		MERGE_KEY_TO_ARRAY, MERGE_BLANKS, MERGE_KEY_IS_CASE_INSENSITIVE};

	//+section Attributes
	public int _mergeType;
	public boolean _mergeIsCaseInsensitive = false;
	public String _primaryKey;
	public String _mergeKeyFrom;
	public String _mergeKeyTo;
	public RdKey _lang;
	public boolean _mergeBlanks;
	public boolean _publishToAppEnv;
	public Map<RdKey,Object> _otherParams;
	public List<RdKey> _removedKeys;
	//+endsection Attributes
	
	//+section Interface RdAppender
	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags) throws IOException
	{
		int appendFlags = RdDataUtils.F_USE_MAP_SEPARATOR;
		if (_mergeType != 0)
		{
			String mergeTypeLabel = (_mergeType >= 0 && _mergeType < MERGE_TYPE_LABELS.length) ?
				MERGE_TYPE_LABELS[_mergeType] : "<invalid>";
			RdDataUtils.appendNameValue(appendable, "mergeType", mergeTypeLabel, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_primaryKey != null)
		{
			RdDataUtils.appendNameValue(appendable, "primaryKey", _primaryKey, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_mergeKeyFrom != null)
		{
			RdDataUtils.appendNameValue(appendable, "mergeKeyFrom", _mergeKeyFrom, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_mergeKeyTo != null)
		{
			RdDataUtils.appendNameValue(appendable, "mergeKeyTo", _mergeKeyTo, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_lang != null)
		{
			RdDataUtils.appendNameValue(appendable, "lang", _lang._name, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_mergeBlanks)
		{
			RdDataUtils.appendNameValue(appendable, "mergeBlanks", null, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_mergeIsCaseInsensitive)
		{
			RdDataUtils.appendNameValue(appendable, "mergeIsCaseInsensitive", null, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_publishToAppEnv)
		{
			RdDataUtils.appendNameValue(appendable, "publishToAppEnv", null, cxt, appendFlags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_otherParams != null)
		{
			if ((appendFlags & RdDataUtils.F_PREPEND_SEPARATOR) != 0)
			{
				appendable.append(";");
			}
			RdDataUtils.appendTo(appendable, _otherParams, key, depth + 1, cxt, flags);
			appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
		}
		if (_removedKeys != null)
		{
			for (RdKey removedKey : _removedKeys)
			{
				if ((appendFlags & RdDataUtils.F_PREPEND_SEPARATOR) != 0)
				{
					appendable.append(";");
				}
				appendable.append('~');
				appendable.append(removedKey._name);
				appendFlags |= RdDataUtils.F_PREPEND_SEPARATOR;
			}
		}
	}
	//+endsection Interface RdAppender

	//+section Interface RdParseMapCallback
	@Override
	public void onParseNameValue(char[] keyArray, int keyStart, int keyEnd, char[] valArray, int valStart, int valEnd, 
		RdParsingState state, int flags)
	{
		boolean matchedKey = false;
		char[] curTestArray = null;
		RdCharArray[] curTestingArrays = PREFIX_TEST_ARRAYS;
		int numCharsChecked = 0;
		int chosenIndex = -1;
		boolean isMerge = false;
		char firstCh = keyArray[keyStart];
		boolean removingKey = false;
		if (firstCh == '~')
		{
			removingKey = (firstCh == '~');
			keyStart++;
		}

		for (int i = keyStart; i < keyEnd; i++)
		{
			char ch = keyArray[i];
			if (ch >= 'A' && ch <= 'Z')
			{
				ch = (char)('a' + (ch - 'A'));
				keyArray[i] = ch;
			}
			if (curTestArray != null)
			{
				if (curTestArray[numCharsChecked++] == ch)
				{
					if (numCharsChecked == curTestArray.length)
					{
						// See if doing prefix.
						if (curTestingArrays == PREFIX_TEST_ARRAYS)
						{
							if (chosenIndex == MERGE_PREFIX_INDEX)
							{
								isMerge = true;
								curTestingArrays = MERGE_ARRAYS;
								curTestArray = null;
							}
							else
							{
								matchedKey = true;
								break;
							}
						}
						else
						{
							matchedKey = true;
						}
					}
				}
				else
				{
					break;
				}
			}
			else
			{
				boolean foundIt = false;
				for (int j = 0; j < curTestingArrays.length; j++)
				{
					if (ch == curTestingArrays[j]._chars[0])
					{
						foundIt = true;
						chosenIndex = j;
						numCharsChecked = 1;
						curTestArray = curTestingArrays[j]._chars;
						break;
					}
				}
				if (!foundIt)
				{
					break;
				}
			} // if (curTestArray != null)
			
			if (matchedKey)
			{
				boolean usesStringVal = (!isMerge ||
					chosenIndex == MERGE_KEY_FROM_INDEX || chosenIndex == MERGE_KEY_TO_INDEX);
				String val = (!removingKey && usesStringVal) ? 
					new String(valArray, valStart, valEnd - valStart) : null;
				if (isMerge)
				{
					switch (chosenIndex)
					{
					case MERGE_TYPE_INDEX:
						_mergeType = MERGE;
						if (valStart < valEnd && !removingKey)
						{
							char firstChar = valArray[valStart];
							if (firstChar == 'a' || firstChar == 'A')
							{
								_mergeType = APPEND;
							}
							else if (firstChar == 'r' || firstChar == 'R')
							{
								_mergeType = REPLACE;
							}
						}
					break;
					case MERGE_KEY_FROM_INDEX:
						_mergeKeyFrom = val;
						break;
					case MERGE_KEY_TO_INDEX:
						_mergeKeyTo = val;
						break;
					case MERGE_BLANKS_INDEX:
						_mergeBlanks = RdConversions.convertToBool(valArray, valStart, valEnd, !removingKey);
					case MERGE_IS_CASE_INSENSITIVE:
						_mergeIsCaseInsensitive = RdConversions.convertToBool(valArray, valStart, valEnd, !removingKey);
						break;
					}
				}
				else // !isMerge
				{
					switch (chosenIndex)
					{
					case PRIMARY_KEY_INDEX:
						_primaryKey = val;
						break;
					case LANG_INDEX:
						_lang = RdLocalizedStringUtils.getLanguageIdKey(val, state._cxt);
					}
				}
			}
		} // for (int i = keyStart; i < keyEnd; i++)
		
		// Note that they key is now lower cased.
		if (!matchedKey)
		{
			String skey = new String(keyArray, keyStart, keyEnd - keyStart);
			RdKey key = state._cxt.getEquivalentKeyObject(skey, RdContext.F_CREATE_IF_MISSING);
			if (_otherParams == null)
			{
				_otherParams = new IdentityHashMap<RdKey,Object>();
			}
			if (!removingKey)
			{
				String val = (valStart < valEnd) ? new String(valArray, valStart, valEnd - valStart) : "1";
				_otherParams.put(key, val);
			}
			else
			{
				if (_removedKeys == null)
				{
					_removedKeys = new ArrayList<RdKey>();
				}
				_removedKeys.add(key);
				_otherParams.remove(key);
			}
		}
	}
	//+endsection Interface RdParseMapCallback
	
	public RdResourceProperties makeMergeableCopy()
	{
		RdResourceProperties resProps = new RdResourceProperties();
		resProps._publishToAppEnv = resProps._publishToAppEnv;
		if (resProps._otherParams != null)
		{
			resProps._otherParams = MapUtils.cloneMap(resProps._otherParams);
		}
		return resProps;
	}
	
	public void mergeResourceProperties(RdResourceProperties propsToMergeIn, RdContext cxt)
	{
		if (propsToMergeIn._publishToAppEnv)
		{
			propsToMergeIn._publishToAppEnv = true;
		}
		if (propsToMergeIn._otherParams != null)
		{
			if (_otherParams == null)
			{
				_otherParams = MapUtils.cloneMap(propsToMergeIn._otherParams);				
			}
			else
			{
				if (propsToMergeIn._removedKeys != null)
				{
					for (RdKey key : propsToMergeIn._removedKeys)
					{
						_otherParams.remove(key);
					}
				}
				MapUtils.mergeKeyMaps(propsToMergeIn._otherParams, _otherParams, cxt, 0);
			}
		}
	}

}
