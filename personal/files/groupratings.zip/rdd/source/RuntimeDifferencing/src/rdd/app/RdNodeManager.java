package rdd.app;

import java.io.IOException;

import rdd.core.RdContext;
import rdd.core.RdData;
import rdd.core.RdEventUtils;
import rdd.core.RdException;
import rdd.core.RdKey;
import rdd.core.RdTable;
import rdd.core.io.FilePathUtils;
import rdd.core.io.ResourceIO;
import rdd.core.logger.LogStreams;
import rdd.core.logger.RotatingFileLogger;
import rdd.core.primitives.MapUtils;
import rdd.core.process.RdParseCommandLineArgs;
import rdd.core.process.RdProcessConfig;
import rdd.core.storage.RdStorage;
import rdd.sharedfilestorage.RdSharedFileStorageUtils;

public class RdNodeManager
{
	static public RdKey NODE_DATA_DIR_KEY;
	static public RdKey NODE_NAME_KEY;
	static public RdKey APP_FEATURES_KEY;
	
	static public boolean _isPreInit = false;
	
	/**
	 * Initialization that occurs before and just after the reading in the first configuration files
	 * for a node. This configuration cannot be repeated and applies to all applications running in
	 * this process.
	 * 
	 * @param cxt
	 *            The active thread context
	 * @throws RdException
	 */
	static public void preInit(RdContext cxt) throws IOException, RdException
	{
		if (_isPreInit)
		{
			throw new RdException("rdceNodeManagerAlreadyPreInit");
		}
		NODE_DATA_DIR_KEY = cxt.getEquivalentKeyObject("NodeDataDir", RdContext.F_CREATE_IF_MISSING);
		NODE_NAME_KEY = cxt.getEquivalentKeyObject("NodeName", RdContext.F_CREATE_IF_MISSING);
		
		APP_FEATURES_KEY = cxt.getEquivalentKeyObject("AppFeatures", 
			RdContext.F_CREATE_IF_MISSING);
		
		CharSequence configFilePath = cxt.getS(RdParseCommandLineArgs.NODE_CONFIG_KEY);
		if (configFilePath.length() == 0)
		{
			throw new RdException("rdceNoNodeConfigFile");
		}

		cxt.push(RdContext.F_STANDARD_PUSHPOP);
		ResourceIO.readResourceFile(cxt, configFilePath, RdContext.F_STANDARD_SEARCH);
		RdData data = cxt.pop(RdContext.F_STANDARD_PUSHPOP);
		RdContext globalContext = cxt._contextStack[RdContext.GLOBAL_CONTEXT];
		MapUtils.mergeKeyMaps(data, globalContext, cxt, MapUtils.F_DO_NOT_REPLACE_EXISTING);
		CharSequence nodeDataDir = cxt.getS(NODE_DATA_DIR_KEY);
		if (nodeDataDir.length() == 0)
		{
			nodeDataDir = FilePathUtils.getParent(configFilePath) + "data/";
		}
		nodeDataDir = FilePathUtils.normalizeFilePath(nodeDataDir, cxt, FilePathUtils.F_IS_DIR);
		globalContext.put(NODE_DATA_DIR_KEY, nodeDataDir);
		String logPath = nodeDataDir + "logs/";
		String nodeName = cxt.getS(NODE_NAME_KEY).toString();
		RotatingFileLogger fileLogger = new RotatingFileLogger(nodeName,
			RdProcessConfig._appType, logPath, 0);
		fileLogger.init(cxt);
		LogStreams._lOut.addStream(fileLogger);
		LogStreams._lErr.addStream(fileLogger);
		
		// Initialize various static classes.
		initCoreApis(cxt);
		
		// Read in media files (including initial component list). 
		readMediaConfig(cxt);

		// Configure as much as we can given no input from shared storage.
		// The application features will determine which rows in the component 
		// listing are active.
		configurePreBootSystem(cxt);
		
		_isPreInit = true;
	}
	
	static public void registerBootEventHandlers(RdContext cxt) throws RdException
	{
		// Set up support for shared file system storage.
		registerSharedFileStorageEventHandler(cxt);
		
		// Apply media components event registration. TODO
	}
	
	/**
	 * Initializes various parts of the RDD core engine that need to be available before
	 * data is read in and processed to configure the application.
	 * @param cxt The current context.
	 * @throws RdException
	 */
	static public void initCoreApis(RdContext cxt) throws RdException
	{
		RdEventUtils.init(cxt);
		RdStorage.init(cxt);
	}
	
	/**
	 * Reads in the configuration from the media directory (which is considered to be read
	 * only). The location of files may be different if the media files are read directly from
	 * a git repository. The idea is to minimize the need for an actual install if running
	 * directly from source code.
	 * @param cxt The current context.
	 */
	static public void readMediaConfig(RdContext cxt)
	{
		// TODO
	}
	
	static public void registerSharedFileStorageEventHandler(RdContext cxt) throws RdException
	{
		RdTable eventRegTable = RdSharedFileStorageUtils.createEventRegistrationTable(cxt);
		RdEventUtils.registerForEvents(eventRegTable, cxt);
	}
	
	/**
	 * Loads up the components that are enabled by the feature list (see APP_FEATURES_KEY).
	 * The components will then load up the required shared libraries that are needed.
	 * If the libraries are 3rd party, the component listing will provide an alternate
	 * URL from which to download the library. DLLs and SOs may require some manual intervention
	 * to get configured on a developer system.
	 * @param cxt
	 */
	static public void configurePreBootSystem(RdContext cxt)
	{
		// TODO
	}
}
