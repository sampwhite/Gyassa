package rdd.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Contains definition of global configuration and convenience access to the thread context. 
 * @author Sam
 *
 */
public class RdAppRegistry
{
	static public RdThreadLocalContext _threadWrapperContext = new RdThreadLocalContext();

	static public RdContext _globalContext = new RdContext(null, RdContext.GLOBAL_CONTEXT, "<global>", 
		new RdData(RdDataFlags.F_SHARED_COPY | RdDataFlags.F_THREAD_SAFE));
	
	static public Map<String,RdContext> _appContext = new ConcurrentHashMap<String,RdContext>();
	
	static public RdContext getThreadWrapperContext()
	{
		return _threadWrapperContext.get();
	}
}
