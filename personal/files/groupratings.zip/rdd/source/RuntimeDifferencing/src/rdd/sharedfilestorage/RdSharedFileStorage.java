package rdd.sharedfilestorage;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import rdd.core.RdCommonKeys;
import rdd.core.RdContext;
import rdd.core.RdContextUtils;
import rdd.core.RdData;
import rdd.core.RdErrorCodes;
import rdd.core.RdEventId;
import rdd.core.RdEventInterface;
import rdd.core.RdEventParams;
import rdd.core.RdEventRegistration;
import rdd.core.RdException;
import rdd.core.io.FilePathUtils;
import rdd.core.io.IoUtils;
import rdd.core.io.ResourceIO;
import rdd.core.logger.RP;
import rdd.core.storage.RdConnectionData;
import rdd.core.storage.RdFileInfo;
import rdd.core.storage.RdFileList;
import rdd.core.storage.RdFileListUtils;
import rdd.core.storage.RdStorage;
import rdd.core.storage.RdStorageParameters;

public class RdSharedFileStorage implements RdEventInterface
{
	public Map<String,ActiveLock> _activeFileLocks;
	public boolean _systemUsesSharedStorage;
	
	@Override
	public void init(RdContext cxt) throws RdException
	{
		_systemUsesSharedStorage = RdStorage.getSystemStorageType(cxt) <= RdStorage.FILE_TYPE;
		if (_systemUsesSharedStorage)
		{
			CharSequence sharedDir = cxt.getS(RdSharedFileStorageUtils.SHARED_FILES_DIRECTORY_KEY);
			if (sharedDir.length() == 0)
			{
				throw new RdException("rdceSharedFileSystemNotConfigured");
			}
			sharedDir = FilePathUtils.normalizeFilePath(sharedDir, cxt, FilePathUtils.F_IS_DIR);
			String testFile = sharedDir + "test.txt";
			String msg = "This file was created to test the shared file system";
			
			// Create test file and leave it to verify that permissions on the file system
			// do not change based on which process from which machine tries to access it.
			IoUtils.createFileWithMessage(testFile, msg);
			_activeFileLocks = new HashMap<String,ActiveLock>();
			
			RdConnectionData systemConnectionData = new RdConnectionData("system", sharedDir);
			systemConnectionData._isSystemStorage = true;
			RdContextUtils.setSharedCachedObject(RdStorage.SYSTEM_CONNECTION_DATA_KEY, cxt, 
				"storage", systemConnectionData, null);
		}
	}

	@Override
	public int handleEvent(RdEventRegistration eventRegistration, RdEventParams params,
		RdContext cxt) throws RdException
	{
		RdStorageParameters storageParams = (RdStorageParameters)params._param;
		
		// We don't audit or cache, so we don't do anything for events that were handled.
		if (params._handledEvent)
		{
			return CONTINUE;
		}
		
		// See if main task is finished and that means we don't have to implement certain events.
		if (storageParams._handledMainEvent && (params._event == storageParams._mainTopLevelEvent
			|| params._event == RdStorage._prepareStorageCall))
		{
			return CONTINUE;
		}
		
		// Transaction counter event handled in a special way.
		RdEventId event = eventRegistration._event;
		RdConnectionData curData = storageParams._connectionData;
		if (curData._type == RdStorage.FILE_TYPE)
		{
			RdEventId topLevelEvent = storageParams._mainTopLevelEvent;
			boolean handledEvent = true;
			if (event == RdStorage._prepareStorageCall)
			{
				prepareForStorageCall(topLevelEvent, storageParams, cxt);
			}
			else if (event == RdStorage._incrementTransactionCounter)
			{
				incrementTransactionCounter(storageParams, cxt);
			}
			else if (event == RdStorage._lock)
			{
				lock(storageParams, cxt);
			}
			else if (event == RdStorage._unlock)
			{
				unlock(storageParams, cxt);
			}
			else if (event == RdStorage._getFileInfo)
			{
				getFileInfo(storageParams, cxt);
			}
			else if (event == RdStorage._readData)
			{
				readData(storageParams, cxt);
			}
			else if (event == RdStorage._writeData)
			{
				writeData(storageParams, cxt);
			}
			else
			{
				handledEvent = false;
			}
			params._handledEvent = handledEvent;
		}
		
		return RdEventInterface.CONTINUE;
	}

	@Override
	public void applicationRelease(RdContext cxt)
	{
		synchronized (_activeFileLocks)
		{
			Set<String> _curLocks = _activeFileLocks.keySet();
			for (String file : _curLocks)
			{
				RP.trace("filestorage", "Lock on file " + file + " was not released", null);
				ActiveLock l = _activeFileLocks.get(file);
				l.release();
			}
			_activeFileLocks.clear();
		}
	}
	
	public void prepareForStorageCall(RdEventId topLevelEvent, RdStorageParameters parameters,
		RdContext cxt)
	{
		if (parameters._storageEventPrepared)
		{
			return;
		}
		if (!parameters._componentPathComputed)
		{
			parameters._componentPath = parameters._connectionData._fileDir
				+ parameters._component + "/";
			parameters._componentPathComputed = true;
		}
	}
	
	public void incrementTransactionCounter(RdStorageParameters params, 
		RdContext cxt) throws RdException
	{
		String tranCounterFile = params._connectionData._fileDir + "trancounter.rdd";
		ActiveLock counterLock = new ActiveLock(tranCounterFile);
		long counter;
		try
		{
			counterLock.lock();
		}
		catch (IOException e)
		{
			throw new RdException(e, "rdceFailedToCreateLockOnLockFile", tranCounterFile);
		}
		try
		{
			cxt.pushByType(RdContext.CALL_CONTEXT, 0);
			ResourceIO.readResourceFile(cxt, tranCounterFile, 0);
			CharSequence transactionCounter = cxt.getS("TransactionCounter", 0);
			if (transactionCounter.length() == 0)
			{
				transactionCounter = cxt.getS("StartingTransactionCounter", 0);
			}
			if (transactionCounter.length() > 0)
			{
				counter = Long.parseLong(transactionCounter.toString());
			}
			else
			{
				counter = 1;
			}
			long newCounter = counter + 1 + params._extraIncrementCount;
			cxt.put(cxt, "TransactionCounter", "" + newCounter);
			ResourceIO.writeResourceFile(cxt, tranCounterFile, 0);
			params._transactionCounterRetrieved = true;
			params._transactionCounter = counter;
			params._nextTransactionCounter = newCounter;
		}
		catch (IOException e)
		{
			throw new RdException(e, RdErrorCodes.GENERAL_SYSTEM_ERROR,
				"rdceFailedToWriteTransactionLockFile", tranCounterFile);
			
		}
		finally
		{
			cxt.popByType(RdContext.CALL_CONTEXT, 0);
			counterLock.release();
		}
	}
	
	public void lock(RdStorageParameters params, RdContext cxt) throws RdException
	{
		reserveDirectory(params, cxt);
	}
	
	public void reserveDirectory(RdStorageParameters params, 
		RdContext cxt) throws RdException
	{
		String dir = computeLockDirectory(params, cxt);
		IoUtils.checkOrCreateDirectories(dir, 1, 0, cxt);
		String lockFile = dir + "lockfile.lck";
		params._lockKey = lockFile;
		ActiveLock lock = new ActiveLock(lockFile);
		try
		{
			lock.lock();
			params._lockAcquired = true;
		}
		catch (IOException e)
		{
			throw new RdException(e, "rdceFailedToCreateLockOnLockFile", lockFile);
		}
		synchronized (_activeFileLocks)
		{
			ActiveLock l = _activeFileLocks.get(params._lockKey);
			if (l != null)
			{
				throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR, 
					"rdceReservingLockFileThatIsAlreadyLocked", lockFile);
			}
			_activeFileLocks.put(params._lockKey, lock);
		}
	}
	
	public void unlock(RdStorageParameters params, RdContext cxt) throws RdException
	{
		releaseDirectory(params, cxt);
	}
	
	public void releaseDirectory(RdStorageParameters params, RdContext cxt) throws RdException
	{
		if (params._lockKey == null)
		{
			String dir = computeLockDirectory(params, cxt);
			throw new RdException("rdceReleasingLockOnUnlockedDirectory", dir);
		}
		synchronized (_activeFileLocks)
		{
			ActiveLock l = _activeFileLocks.remove(params._lockKey);
			if (l == null)
			{
				throw new RdException("rdceLockKeyForDirectoryWasNotFound", params._lockKey);
			}
			l.release();
			params._lockAcquired = false;
			params._lockReleased = true;
		}
	}
	
	public String computeLockDirectory(RdStorageParameters params, RdContext cxt)
	{
		checkComputeListDirectory(params, cxt);
		return params._listingPath;
	}
	
	public void checkComputeListDirectory(RdStorageParameters params, RdContext cxt)
	{
		if (!params._computedListPath)
		{
			params._listingPath = computeListDirectory(params, cxt);
			params._computedListPath = true;
		}
	}
	
	public String computeListDirectory(RdStorageParameters params, RdContext cxt)
	{
		String dir = params._componentPath;
		if (params._listingSubDir!= null)
		{
			dir += params._listingSubDir;
			dir = FilePathUtils.normalizeFilePath(dir, cxt, FilePathUtils.F_IS_DIR);
		}
		return dir;
	}
	
	public void getFileInfo(RdStorageParameters params, RdContext cxt) throws RdException
	{
		if (!params._retrievedWorkingFileList)
		{
			getWorkingFileList(params, cxt);
		}
		if (params._workingFileList == null)
		{
			// Not an error, but failure to retrieve file info will be communicated
			// by attributes of "params".
			return;
		}
		
		RdFileInfo fileInfo = RdFileListUtils.findFileInfo(params._workingFileList, params, 
			params._relativePath, cxt);
		if (fileInfo != null)
		{
			params._fileInfoRetrieved = true;
			params._fileInfo = fileInfo;
			params._targetedResourceExits = true;
			params._relativePathUsed = params._relativePath;
		}
	}
	
	public void getWorkingFileList(RdStorageParameters params, RdContext cxt) throws RdException
	{
		checkComputeListDirectory(params, cxt);
		String fileListPath = params._listingPath + "filelist.rdd";
		cxt.pushByType(RdContext.CALL_CONTEXT, 0);
		boolean didLock = false;
		params._workingFileList = null;
		
		try
		{
			if (!params._lockAcquired && !params._isReadOnlyData)
			{
				reserveDirectory(params, cxt);
				params._lockAcquired = true;
				didLock = true;
			}
			ResourceIO.readResourceFile(cxt, fileListPath, 0);
			RdData fileListData = (RdData)cxt.getLocalData();
			RdFileList fileList = RdFileListUtils.createFileListFromData(fileListData, params, cxt);
			if (fileList != null)
			{
				params._workingFileList = fileList;
				params._hasWorkingFileList = true;
			}
		}
		catch (IOException e)
		{
			// If file is missing, that is considered to be OK.
			if (IoUtils.fileExists(fileListPath))
			{
				// A real error.
				throw new RdException(e, "rdceFailedToReadFileList", fileListPath);
			}
			
			// Create component directory.
			IoUtils.checkOrCreateDirectories(params._componentPath, 0, 0, cxt);
			if (params._listingSubDir != null)
			{
				IoUtils.checkOrCreateSubDirectory(params._componentPath, params._listingSubDir, 0, cxt);
			}
		}
		finally
		{
			cxt.popByType(RdContext.CALL_CONTEXT, 0);
			if (didLock)
			{
				releaseDirectory(params, cxt);
			}
		}
		
		// We retrieved it, even if it does not exist.
		params._retrievedWorkingFileList = true;
	}
	
	public void writeWorkingFileList(RdStorageParameters params, RdContext cxt) throws RdException
	{
		if (params._workingFileList == null)
		{
			return;
		}
		checkComputeListDirectory(params, cxt);
		String fileListPath = params._listingPath + "filelist.rdd";
		cxt.pushByType(RdContext.CALL_CONTEXT, 0, params._workingFileList._fileListStorageData);
		boolean didLock = false;
		params._workingFileList = null;
		
		try
		{
			if (!params._lockAcquired)
			{
				reserveDirectory(params, cxt);
				params._lockAcquired = true;
				didLock = true;
			}
			cxt.put(RdCommonKeys.LAST_EDIT_TRANSACTION_COUNTER, 
				new Long(params._transactionCounter));
			cxt.put(RdFileListUtils.LAST_EDIT_DATE, new Date());
			ResourceIO.writeResourceFile(cxt, fileListPath, 0);
			RdData fileListData = (RdData)cxt.getLocalData();
			RdFileList fileList = RdFileListUtils.createFileListFromData(fileListData, params, cxt);
			if (fileList != null)
			{
				params._workingFileList = fileList;
				params._hasWorkingFileList = true;
			}
		}
		catch (IOException e)
		{
			// If file is missing, that is considered to be OK.
			if (IoUtils.fileExists(fileListPath))
			{
				// A real error.
				throw new RdException(e, "rdceFailedToReadFileList", fileListPath);
			}
			
			// Create component directory.
			IoUtils.checkOrCreateDirectories(params._componentPath, 0, 0, cxt);
			if (params._listingSubDir != null)
			{
				IoUtils.checkOrCreateSubDirectory(params._componentPath, params._listingSubDir, 0, cxt);
			}
		}
		finally
		{
			cxt.popByType(RdContext.CALL_CONTEXT, 0);
			if (didLock)
			{
				releaseDirectory(params, cxt);
			}
		}

	}
	
	public void readData(RdStorageParameters params, RdContext cxt) throws RdException
	{
		boolean didLock = false;
		if (!params._lockAcquired  && !params._isReadOnlyData)
		{
			reserveDirectory(params, cxt);
			params._lockAcquired = true;
			didLock = true;
		}
		try
		{
			if (!params._fileInfoRetrieved)
			{
				getFileInfo(params, cxt);
			}
			if (params._targetedResourceExits)
			{
				String filePath = params._listingPath + params._relativePath;
				try
				{	
					ResourceIO.readResourceFile(cxt, filePath, params._formattingAndStorageOptionsFlags);
				}
				catch (IOException ioE)
				{
					throw new RdException(ioE, "rdceFailedToReadFile", filePath);
				}
				params._useDirectFileSystemAccess = true;
				params._resourceFilePath = filePath;
			}
			params._handledMainEvent = true;
		}
		finally
		{
			if (didLock)
			{
				releaseDirectory(params, cxt);
			}
		}
	}
	
	public void writeData(RdStorageParameters params, RdContext cxt) throws RdException
	{
		boolean didLock = false;
		String filePath = "<uncomputed>";
		try
		{
			if (!params._lockAcquired)
			{
				reserveDirectory(params, cxt);
				didLock = true;
			}
			if (!params._fileInfoRetrieved)
			{
				getFileInfo(params, cxt);
			}
			filePath = params._listingPath + params._relativePath;
			if (params._targetedResourceExits)
			{
				if ((params._formattingAndStorageOptionsFlags & RdContext.F_CREATE_STORAGE_ENTRY_ONLY) != 0)
				{
					// We are coming in with the expectation that this file does not already
					// exist.
					throw new RdException(RdErrorCodes.RESOURCE_ALREADY_EXISTS,
						"rdceReplacingFileThatIsNotSupposedToExist", params._component._name,
						params._relativePath);
				}
			}
			RdFileListUtils.addOrUpdateFileToWorkingFileInfo(params, params._relativePath, 0, cxt);
			
			ResourceIO.writeResourceFile(cxt, filePath, params._formattingAndStorageOptionsFlags);
			
			writeWorkingFileList(params, cxt);
			params._useDirectFileSystemAccess = true;
			params._resourceFilePath = filePath;
			params._handledMainEvent = true;
		}
		catch (IOException ioE)
		{
			throw new RdException(ioE, "rdceFailedToReadFile", filePath);
		}
		finally
		{
			if (didLock)
			{
				releaseDirectory(params, cxt);
			}
		}
	}
}
