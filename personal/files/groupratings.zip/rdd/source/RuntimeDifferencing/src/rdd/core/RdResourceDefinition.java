package rdd.core;

import java.io.IOException;

public class RdResourceDefinition implements Comparable, RdAppendDebug
{
	public RdKey _key;
	public RdResourceKey _resKey;
	public boolean _isDataValue;
	public boolean _descriptionIsInLine;
	public CharSequence _description;
	public CharSequence _text;
	public Object _parsedObject;
	public RdResourceProperties _properties;
	public RdResourceLocator _location;
	
	public RdResourceDefinition(RdResourceKey resKey, RdResourceLocator location)
	{
		// For simple name value pair.
		_resKey = resKey;
		if (location != null)
		{
			_location = location.clone();
		}
		else
		{
			_location = new RdResourceLocator("<internal>");
		}
	}
	
	//+section Interface Comparable
	@Override
	public int compareTo(Object o)
	{
		RdResourceKey rk1 = this._resKey;
		RdResourceKey rk2 = ((RdResourceDefinition)o)._resKey;
		if (rk2 == null)
		{
			return (rk1 == null) ? 0 : 1;
		}
		if (rk1 == null)
		{
			return -1;
		}

		if (rk1._resourceType != rk2._resourceType)
		{
			return rk1._resourceType - rk2._resourceType;
		}
		return rk1._resourceName.compareTo(rk2._resourceName);
	}
	//+endsection Interface Comparable
	
	//+section Interface RdAppendDebug
	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		// TODO Auto-generated method stub
		if (_key != null)
		{
			appendable.append("" +_key);
		}
		else
		{
			
			appendable.append(_resKey != null ? _resKey.toString() : "<unnamed>");
		}
		appendable.append("(");
		if (_properties != null)
		{
			appendable.append(",properties=[");
			_properties.appendTo(appendable, _key, 0, cxt, RdContext.F_DEBUG_FORMAT | flags);
			appendable.append("]");
		}
		if (_location != null)
		{
			appendable.append(",location=[");
			_location.appendDebug(appendable, cxt, flags);
			appendable.append("]");
			
		}
		appendable.append(")");
		if (_description != null && _description.length() > 0)
		{
			appendable.append("\n*description*\n");
			appendable.append(_description);
		}
		if (_text != null)
		{
			appendable.append("\n*text*\n");
			appendable.append(_text);
		}
		if (!_isDataValue && _parsedObject != null)
		{
			appendable.append("\n*body*\n");
			RdDataUtils.appendTo(appendable, _parsedObject, _key, 0, cxt, flags);
		}
	}
	//+endsection Interface RdAppendDebug
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}

