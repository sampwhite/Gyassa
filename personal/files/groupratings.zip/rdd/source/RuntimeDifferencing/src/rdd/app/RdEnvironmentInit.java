package rdd.app;

import rdd.core.RdContext;
import rdd.core.RdException;
import rdd.core.primitives.MessageFormatter;
import rdd.core.strings.RdLocalizedStringUtils;
import rdd.core.strings.RdStringPackage;

public class RdEnvironmentInit
{
	/**
	 * This is the method that gets called before configuration is retrieved from the file
	 * system. It may be the only configuration performed if the code is being executed
	 * inside a client application.
	 * @param cxt The current context.
	 * @throws RdException
	 */
	static public void preConfigLoadInit(RdContext cxt) throws RdException
	{
		MessageFormatter._objectFormatter = new RdObjectFormatter();
		initStrings(cxt);
	}
	
	static public void initStrings(RdContext cxt) throws RdException
	{
		RdLocalizedStringUtils.initLocalizedStringEnvironment(cxt);
		
		String noStringPackage = System.getProperty("nostringpackage");
		boolean loadedManufacturedPackage = false;
		if (noStringPackage == null)
		{
			// Hardwire an internal reference to a packaging of translated
			// strings. This allows this code to be used in client applications
			// without a reference to the file system.
			try
			{
				Class c = Class.forName("rdd.manufactured.StringPackage");
				RdStringPackage p = (RdStringPackage)c.newInstance();
				RdLocalizedStringUtils.loadStringsFromPackage(p, cxt);
				loadedManufacturedPackage = true;
			}
			catch (Exception e)
			{
				// We suppress this completely until some future moment when we truly
				// expect to have translated strings and large media deployments of strings.
			}
		}
		
		if (!loadedManufacturedPackage)
		{
			// Fall back to developer (Eclipse) friendly approach for those
			// who do not want to run with full set of strings.
			RdStringPackage p = new rdd.strings.RdCorePackage();
			RdLocalizedStringUtils.loadStringsFromPackage(p, cxt);
		}
	}
}
