package rdd.core;

import java.util.Collection;
import java.util.Date;
import java.util.Map;

/**
 * Wrapper for an object value. This object allows us to solve the following problems.
 * 1. Maintain string presentation versions of an object and the original object. In particular, it
 * optimizes Date and localized message handling.
 * 2. Manage "null" values explicitly instead of using the absence of a value, makes
 * the interactions with databases go much more smoothly when using "search" algorithms
 * to hunt through multiple value collections for a potential value.
 * 3. Give a value "state" information (@see F_READ_ONLY) that can control how
 * its handled depending on where it was stored (in particular is the object from a cache or created dynamically
 * for the current thread).
 */
public class RdValue implements RdCloneable
{
	/**
	 * Uses same type values as RdKey.
	 */
	public int _type;

	/**
	 * Flags that control how this value should be handled.
	 */
	public int _flags;
	
	/**
	 * The key used to find this value.
	 */
	public RdKey _key;
	
	/**
	 * If the value is contained inside another RdValue object, this is that object.
	 */
	public RdValue _parent;

	/**
	 * The context key used to determine if display value (@see _displayVal) is bound to the correct active user locale.
	 * This value cannot be set on read only values.
	 */
	public RdContextKey _contextDisplayKey;

	/**
	 * Alternate versions of same thing. The _sVal attribute, if it exists, must always be usable to recreate
	 * any other version (with potential loss of precision -- one of the reasons why RdValue exists as a class).
	 * Either _sVal or _oVal must always be set for this to be a validly defined object (unless it is null).
	 * The values that are put in these alternate renditions will be dependent on the "key" definition
	 * associated with this value. One of the biggest complications is knowing when these alternate values
	 * are no longer valid (the _parent attribute helps in notifying parent RdValue objects that their
	 * alternate _sVal is not valid any more but maintaining the _parent correctly is a constant chore).
	 */
	public CharSequence _sVal;
	public CharSequence _displayVal;
	public Object _oVal;
	public long _lVal;
	
	public RdValue(RdKey key, int type)
	{
		_key = key;
		_type = type;
	}
	
	public RdValue(RdKey key, Object obj)
	{
		_key = key;
		if (obj instanceof RdValue)
		{
			_type = ((RdValue)obj)._type;
			copy((RdValue)obj);
			return;
		}
		if (obj == null)
		{
			_type = RdKey.NULL;
		}
		else if (obj instanceof Boolean)
		{
			_type = RdKey.BOOLEAN;
			_sVal = ((Boolean)obj).booleanValue() ? "1" : "0";
		}
		else if (obj instanceof Date)
		{
			_lVal = ((Date)obj).getTime();
			_type = RdKey.DATE;
		}
		else if (obj instanceof RdMessage)
		{
			_type = RdKey.MESSAGE;
		}
		else if (obj instanceof RdData)
		{
			_type = RdKey.DATA;
		}
		else if (obj instanceof RdTable)
		{
			_type = RdKey.TABLE;
		}
		else if (obj instanceof Integer)
		{
			_type = RdKey.INTEGER;
			_lVal = ((Integer)obj).longValue();
		}
		else if (obj instanceof Long)
		{
			_type = RdKey.INTEGER;
			_lVal = ((Long)obj).longValue();
		}
		else if (obj instanceof Float)
		{
			_type = RdKey.FLOAT;
		}
		else if (obj instanceof CharSequence)
		{
			_type = RdKey.STRING;
			if (obj instanceof RdCharArray)
			{
				obj = obj.toString();
			}
			_sVal = (CharSequence)obj;
		}
		else if (obj instanceof Object[])
		{
			_type = RdKey.ARRAY;
		}
		else if (obj instanceof Collection)
		{
			_type = RdKey.COLLECTION;
		}
		else if (obj instanceof Map)
		{
			_type = RdKey.MAP;
		}
		_oVal = obj;
	}
	
	public RdValue shallowClone()
	{
		RdValue newValue = new RdValue(_key, _type);
		newValue.copy(this);
		return newValue;
	}
	
	//+section RdCloneable interface
	@Override
	public Object clone(int depth, RdContext cxt)
	{
		RdValue newValue = shallowClone();
		if (depth > 0 && _oVal != null)
		{
			newValue._oVal = RdCloner.cloneObject(_oVal, depth - 1, cxt);
		}
		return newValue;
	}
	//+endsection RdCloneable interface 
	
	/**
	 * Copies other attributes besides _type and _key. Also makes
	 * sure that RdTable objects can be safely accessed.
	 * @param from The RdValue to copy.
	 */
	public void copy(RdValue from)
	{
		_parent = from._parent;
		_contextDisplayKey = from._contextDisplayKey;
		_type = from._type;
		if ( from._oVal == null || _key == null || from._key == null ||
			((_key._flags & RdKey.F_STRING_NON_DEFAULT) == 0 && (from._key._flags & RdKey.F_STRING_NON_DEFAULT) == 0) )
		{
			_sVal = from._sVal;
		}
		if (_oVal instanceof RdTable)
		{
			_oVal = ((RdTable)_oVal).shallowClone();
		}
		else
		{
			_oVal = from._oVal;
		}
		_lVal = from._lVal;
	}
	
	public void setReadOnly()
	{
		if (_oVal instanceof RdData)
		{
			((RdData)_oVal)._flags |= RdDataFlags.F_READ_ONLY;
		}
		if (_oVal instanceof RdTable)
		{
			((RdTable)_oVal)._flags |= RdDataFlags.F_READ_ONLY;
		}
		_flags |= RdDataFlags.F_READ_ONLY;
	}
	
	public void fixupParentsForChildChange()
	{
		RdValue p = _parent;
		while (p != null)
		{
			if ((p._flags & RdDataFlags.F_READ_ONLY) == 0)
			{
				p._sVal = null;
			}
			p = p._parent;
		}
	}
	
	@Override
	public String toString()
	{
		RdContext cxt = RdAppRegistry.getThreadWrapperContext();
		RdCharArray temp = cxt.temporaryAllocateCharArray();
		String result = "<error>";
		try
		{
			if (_key != null)
			{
				temp.append(_key.toString());
				temp.append('=');
			}
			RdDataUtils.appendTo(temp, this, _key, 0, cxt, RdContext.F_DEBUG_FORMAT);
			result = temp.toString();
		}
		catch (Throwable t)
		{
			// Ignore
		}
		cxt.releaseTemporaryAllocatedCharArray(temp);
		return result;
	}
	
	public boolean isNull()
	{
		return (_type == RdKey.NULL);
	}
}