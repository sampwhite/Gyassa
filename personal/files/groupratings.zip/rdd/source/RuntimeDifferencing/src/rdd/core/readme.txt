The files in the "rdd.core" package should not have dependencies on files outside the rdd.core
package or its sub packages.