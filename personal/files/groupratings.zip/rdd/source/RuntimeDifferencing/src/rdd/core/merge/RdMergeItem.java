package rdd.core.merge;

import rdd.core.RdResourceKey;

public class RdMergeItem
{
	/**
	 * The key that is being merged on. It is used to retrieve the value from the
	 * resource data referenced by _loadLocation.
	 */
	public RdResourceKey _key;
	
	/**
	 * Whether this entry has disappeared since it was last loaded.
	 */
	public boolean _isDeleted;
	
	/**
	 * Merge flags to control how merging is done.
	 */
	public int _mergeFlags;
	
	/**
	 * The data. Usually a table, but can be be a string, Map, or RdData object
	 * as well.
	 */
	public Object _data;
	
	/**
	 * Tracks the transaction counter that marks the data the last time it was modified.
	 */
	public long _lastModifiedCounter;
	
	/**
	 * Value of _data object at the time the merge was successfully performed. Used to
	 * do differencing calculations against new data. If null, then all data in _data
	 * attribute is considered to be new and applied as if it did not exist before.
	 */
	public Object _dataWhenMerged;
	
	/**
	 * Whether the attribute _mergedData is considered valid.
	 */
	public boolean _isValidMerge;
	
	/**
	 * Where this data came from. Used to detect if this object is out of date.
	 */
	public RdMergeableData _sourceData;
	
	/**
	 * Index into the array that holds this object. Only valid if _isValidMerge
	 * is valid.
	 */
	public int _mergeArrayIndex;
	
	/**
	 * The prior version of this object. Used to do differencing calculation to minimize
	 * merge operations.
	 */
	public RdMergeItem _priorData;
}
