package rdd.core.storage;

import rdd.core.RdException;

public class RdCounterWrapper
{
	/**
	 * Whether counter value has been set.
	 */
	public boolean _isCounterSet;
	
	/**
	 * Computed counter value.
	 */
	public long _counter;
	
	/**
	 * Used for troubleshooting only.
	 */
	public long _nextCounter;

	/**
	 * Whether to wait for another thread to get the counter.
	 */
	public boolean _waitForAnotherThread;

	/**
	 * If not set, then the exception that caused the failure.
	 */
	public RdException _exception;
	
	
	public RdCounterWrapper()
	{
		// Allow default initializatio to go.
	}
}
