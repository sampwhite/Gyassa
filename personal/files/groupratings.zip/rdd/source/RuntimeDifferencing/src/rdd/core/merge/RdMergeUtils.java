package rdd.core.merge;

import rdd.core.RdContext;
import rdd.core.RdData;
import rdd.core.RdDataFlags;
import rdd.core.RdException;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdLoadOrder;
import rdd.core.RdLocation;
import rdd.core.RdResourceDefinition;
import rdd.core.RdResourceTypes;
import rdd.core.RdResourceValue;
import rdd.core.RdTable;
import rdd.core.RdTableUtils;
import rdd.core.strings.RdLocalizedStringUtils;
import rdd.core.strings.RdStringData;

public class RdMergeUtils
{
	//+section Data usage and source flags
	static public int F_LOADED_FROM_FILE = 1;
	//+endsection Data usage and source flags
	
	//+section Merge rules
	static public int F_MERGE_STANDARD = 1;
	static public int F_DELETE = 2;
	static public int F_PUBLISH_TO_SHARED_ENV = 4;
	static public int F_RESOURCE_DESIGN_CHANGED = 8;
	//+endsection Merge rules
	
	//+section Merge error types
	static public int E_INCONSISTENT_OVERLAY_TYPE = 1;
	//+endsection Merge error types
	
	/**
	 * The key to find the RdMergeState object inside the current context.
	 */
	static public RdKey RESORUCE_MERGE_STATE_KEY = RdGlobalKeys.registerGlobalKey(
		"ResourceMergeState", RdKey.COMPLEX);
	
	/**
	 * Updates resources loaded from a particular location. This method assumes that
	 * mergedResourceData already has a synchronization lock on it.
	 * @throws RdException
	 */
	static public void updateResourcesInternal(RdLocation location, RdData data, 
		long lastModifiedCounter, RdResourceMergeData mergedResourceData, RdMergeState mergeState,
		RdContext cxt, int flags) throws RdException
	{
		RdMergeableData curMergeData = mergedResourceData._dataMap.get(location);
	}
	
	/**
	 * Converts a RdData object into a mergeable unit of data.
	 */
	static public RdMergeableData buildMergeableData(RdLocation location, RdData data, RdContext cxt, 
		RdMergeState mergeState, long lastModifiedCounter, int flags) throws RdException
	{
		int loadOrder = RdLoadOrder.DEFAULT_ORDER._order;
		if ((data._flags & RdDataFlags.F_HAS_LOAD_ORDER) != 0)
		{
			loadOrder = data._loadOrder;
		}
		RdMergeableData mergeData = new RdMergeableData(location, lastModifiedCounter, loadOrder);
		if (data._resourceData == null)
		{
			return mergeData;
		}
		for (RdResourceDefinition def : data._resourceData)
		{
			if (def._resKey._resourceType != RdResourceTypes.TEXT)
			{
				Object val = null;
				if (def._isDataValue)
				{
					val = data.get(def._key);
				}
				else
				{
					val = def._parsedObject;
				}
				boolean isNew = false;
				RdResourceValue resVal = mergeData._loadedResources.get(def._resKey);
				if (resVal == null)
				{
					resVal = new RdResourceValue();
					isNew = true;
				}
				mergeIntoResourceValue(def, val, resVal, mergeState, cxt);
				if (isNew)
				{
					mergeData._loadedResources.put(def._resKey, resVal);
				}
			}
		}
		return mergeData;
	}
	
	/**
	 * Merge into resource value for values loaded from a particular RdLocation. It is
	 * not a method for doing overlays of resources that share a common RdResourceKey but
	 * come from different RdLocations. For example, a table or string may be defined more
	 * than once inside a particular file.
	 */
	static public void mergeIntoResourceValue(RdResourceDefinition def, Object val, 
		RdResourceValue resVal, RdMergeState mergeState, RdContext cxt) throws RdException
	{
		if (val == null)
		{
			return;
		}
		boolean isString = def._resKey._resourceType == RdResourceTypes.STRING;
		RdStringData stringData = null;
		if (resVal._resourceName == null)
		{
			resVal._resourceName = def._resKey;
			resVal._resourceDef = def;
			if (def._properties != null)
			{
				resVal._resourceProps = def._properties.makeMergeableCopy();
			}
			if (isString)
			{
				stringData = new RdStringData(def._resKey);
				resVal._resource = stringData;
			}
			else
			{
				resVal._resource = val;
			}
		}
		else
		{
			if (isString)
			{
				stringData = (RdStringData)resVal._resource;
			}
			else if (def._resKey._resourceType == RdResourceTypes.TABLE)
			{
				RdTable curTable = (RdTable)resVal._resource;
				RdTable newTable = (RdTable)val;
				RdTableUtils.mergeTablesByPrimaryKey(curTable, newTable, 0, cxt);
			}
		}
		if (isString)
		{
			RdKey langKey = (def._properties != null) ? def._properties._lang : 
				RdLocalizedStringUtils.ENGLISH_LANG_KEY;
			int langIndex = RdLocalizedStringUtils.getOrRegisterLangIdIndex(langKey, cxt);
			String localizedString = val.toString();
			RdLocalizedStringUtils.addLocaleString(stringData, langIndex, localizedString);
		}
	}
	
	
	static public void calculateUpdatedDiff(RdDiffItem overlay, RdDiffItem cur, RdDiffItem result,
		int diffActionFlags) throws RdException
	{
		
	}
}
