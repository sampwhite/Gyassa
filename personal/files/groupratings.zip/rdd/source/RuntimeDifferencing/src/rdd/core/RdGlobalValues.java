package rdd.core;

public class RdGlobalValues
{
	/**
	 * Differentiate between null values that are the absence and null values that are assigned.
	 * When searching for a value using a RdKey lookup key, the search will stop if NULL_VALUE
	 * is returned, but will continue if an actual null is returned (or ORIGINALLY_NULL_VALUE).
	 */
	static public final RdValue NULL_VALUE = new RdValue(RdGlobalKeys.NULL_KEY, RdKey.NULL);
	
	/**
	 * In cases where a "null" is not allowed as a return value, this version of the NULL_VALUE is used to indicate that
	 * the value should be treated as logically equivalent to a true "null" value when searching
	 * through multiple data collections for a particular lookup key. So a null test may look like this:
	 * if (value == null || value == RdValue.ORIGINALLY_NULL_VALUE)
	 * {
	 *     // Continue search for value someplace else.
	 * }
	 */
	static public final RdValue ORIGINALLY_NULL_VALUE = new RdValue(RdGlobalKeys.NULL_KEY, RdKey.NULL);

}
