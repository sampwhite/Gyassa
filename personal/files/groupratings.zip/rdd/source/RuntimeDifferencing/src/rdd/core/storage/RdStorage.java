package rdd.core.storage;


import java.util.ArrayList;
import java.util.List;

import rdd.core.RdContext;
import rdd.core.RdContextUtils;
import rdd.core.RdErrorCodes;
import rdd.core.RdEventId;
import rdd.core.RdEventParams;
import rdd.core.RdEventUtils;
import rdd.core.RdException;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.component.RdComponentData;
import rdd.core.component.RdComponentUtils;
import rdd.core.logger.RP;
import rdd.core.primitives.StrUtils;

/**
 * This class is the main API for accessing data files. It is implemented with filter handlers
 * and the handlers are implemented by classes outside the core package (and its sub packages).
 * These handlers need to be registered or calling this API will fail. It is the responsibility
 * of the caller to use the same RdStorageParameters for duration of a locked directory
 * and and files accessed in that directory (or sub directory).
 * 
 * One of the primary responsibilities of a "system" storage solution is to provide
 * a reliable global transaction counter that is transactionally guaranteed to
 * be forward going when accessed by multiple nodes in a cluster. A transactionally
 * guaranteed forward going counter has two properties.
 * 
 * 1. The same counter value is never given to more than one client that requests it.
 * 2. If two transactions edit the same data (could be same file or same rows in a table),
 * then the transactions must happen serially (one after the other) and the later edit
 * must have a larger transaction counter. A new counter value is assigned at the time
 * the resource (database table row, directory, or file) is exclusively locked for editing.
 * 
 * When a server starts up (and many command line support tools as well), the first act is
 * to retrieve configuration data and the list of inactive and active components. This
 * connection must be configured on the node and the basic system type must be set. Once
 * this basic configuration data is read, interior applications can be launched which
 * may have one or more additional connections to storage locations for content and
 * components. In particular, the configuration value SystemStorageConnectionType must
 * be set in the very first configuration file that is read in when a node is started.
 */
public class RdStorage
{
	//+section The different types of storage
	/**
	 * The storage uses a shared file system, not recommended for high performance scenarios,
	 * but perfect for developer or laptop demo. The file storage uses built in Java DB
	 * for database storage. No password information is needed to do connection.
	 */
	static public final int FILE_TYPE = 1;
	
	/**
	 * Storage is implemented by a specialized server using the RDD core infrastructure. The
	 * specialized server is an enhanced file server that supports some database mechanics.
	 * IP address, port, and password is needed to connect. This file server will NOT support
	 * load balancing or fail over without severely degrading contribution performance (editing
	 * will then require aggressive locking).
	 */
	static public final int SERVER_TYPE = 2;
	
	/**
	 * The storage solution is a database that can store BLOBs and CLOBs and can be accessed
	 * using standard JDBC style calls. Hostname, user name, port, and password are usually
	 * needed to connect. There are additional optional parameters for certain configurations.
	 * Some databases have load balancing and failover implementations, though usually at
	 * a cost to contribution speeds and general system stability. Note that there can
	 * be NO relaxation in the requirement for transactionally forward going counters.
	 */
	static public final int DB_TYPE = 3;
	
	/**
	 * The storage solution is a commercial device designed specifically to store large amounts
	 * of data for long durations. It is generally not optimized for fast turn over in content and
	 * may limit its utility for certain types of application features (such as interactive gaming).
	 * Connection information usually requires server name and password. In many cases
	 * the DEVICE_TYPE storage will only store some of the content with much of the base
	 * configuration and components stored in storage of DB_TYPE.
	 */
	static public final int DEVICE_TYPE = 4;
	//+endsection The different types of storage
	
	/**
	 * The identifiers for storage types. The values above act as indexes into this array.
	 */
	static public String[] STORAGE_TYPE_IDS = {"", "file", "rddserver", "database", "device"};
	
	static public int FAST_SYSTEM_CONNECTION_LOOKUP_INDEX = -1;
	static public RdKey SYSTEM_CONNECTION_DATA_KEY = RdGlobalKeys.registerGlobalKey(
		"SystemConnectionData", RdKey.COMPLEX, RdKey.F_IS_NOT_SERIALIZABLE);
	static public RdKey SYSTEM_CONNECTION_TYPE = RdGlobalKeys.registerGlobalKey(
		"SystemStorageConnectionType", RdKey.STRING, RdKey.F_IS_NOT_SERIALIZABLE);
	
	/**
	 * Used purely for data validation. When data is written to a file a value
	 * is set for this key. If the data is read in again and the currently loaded
	 * values have this key set, then the expectation is that the "read" will succeed.
	 */
	static public RdKey DATA_FROM_STORAGE_KEY = RdGlobalKeys.registerGlobalKey(
		"DataFromStorage", RdKey.BOOLEAN, RdKey.F_IS_NOT_SERIALIZABLE);
	

	static public RdEventId _prepareStorageCall;
	static public RdEventId _postProcessStorageCall;
	static public RdEventId _incrementTransactionCounter;
	static public RdEventId _lock;
	static public RdEventId _unlock;
	static public RdEventId _getFileList;
	static public RdEventId _readData;
	static public RdEventId _writeData;
	static public RdEventId _getFileInfo;
	static public RdEventId _openFileInputStream;
	static public RdEventId _openFileOutputStream;
	static public RdEventId _afterCloseInputStream;
	static public RdEventId _getFileChangesList;
	
	static public void init(RdContext cxt)
	{
		FAST_SYSTEM_CONNECTION_LOOKUP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(SYSTEM_CONNECTION_DATA_KEY);
		
		_prepareStorageCall = RdEventUtils.registerOrCreateEventId(
			"prepareStorageCall", "storage", RdEventId.F_IS_INTERNAL);
		_postProcessStorageCall = RdEventUtils.registerOrCreateEventId(
			"prepareStorageCall", "storage", RdEventId.F_IS_INTERNAL);
		_incrementTransactionCounter = RdEventUtils.registerOrCreateEventId(
			"incrementTransactionCounter", "storage", RdEventId.F_IS_INTERNAL);
		_lock = RdEventUtils.registerOrCreateEventId(
			"lockStorage", "storage", RdEventId.F_IS_INTERNAL);
		_unlock = RdEventUtils.registerOrCreateEventId("unlockStorage",
			"storage", RdEventId.F_IS_INTERNAL);
		_readData = RdEventUtils.registerOrCreateEventId("readStorageData", 
			"storage", RdEventId.F_IS_INTERNAL);
		_writeData = RdEventUtils.registerOrCreateEventId("writeStorageData", 
			"storage", RdEventId.F_IS_INTERNAL);
		
		_getFileInfo = RdEventUtils.registerOrCreateEventId("getStorageFileInfo", "storage", 
			RdEventId.F_IS_INTERNAL);
		_openFileInputStream = RdEventUtils.registerOrCreateEventId("openStorageFileInputStream", 
			"storage", RdEventId.F_IS_INTERNAL);
		_openFileOutputStream = RdEventUtils.registerOrCreateEventId("openStorageFileOutputStream", 
			"storage", RdEventId.F_IS_INTERNAL);
		_afterCloseInputStream = RdEventUtils.registerOrCreateEventId("afterCloseStorageInputStream", 
			"storage", RdEventId.F_IS_INTERNAL);
		_getFileChangesList = RdEventUtils.registerOrCreateEventId("getStorageFileChangesList", 
			"storage", RdEventId.F_IS_INTERNAL);
		
		// Initialize other utility methods.
		RdFileListUtils.init(cxt);
	}
	
	/**
	 * Gives the event list as a comma separated string for ease of use in persisting registration
	 * for events done by storage methods.
	 * @return A comma separated list of the events that are invoked by the storage methods.
	 */
	static public String getEventListAsString()
	{
		return "prepareStorageCall,incrementTransactionCounter,lockStorage,unlockStorage," +
			"readStorageData,writeStorageData," +
			"getStorageFileInfo,openStorageFileOutputStream,afterCloseStorageInputStream,getStorageFileChangesList";		
	}
	
	static public String getStorageTypeAsString(int type)
	{
		if (type < 0 || type >= STORAGE_TYPE_IDS.length)
		{
			return null;
		}
		return STORAGE_TYPE_IDS[type];
	}
	
	static public int parseStorageType(CharSequence typeStr)
	{
		int index = -1;
		for (int i = 0; i < STORAGE_TYPE_IDS.length; i++)
		{
			if (StrUtils.isMatchingStrings(typeStr, STORAGE_TYPE_IDS[i]))
			{
				index = i;
				break;
			}
		}
		return index;
	}
	
	static public int getSystemStorageType(RdContext cxt) throws RdException
	{
		RdConnectionData sysConnectionData = (RdConnectionData)RdContextUtils.getFastCachedObject(
			FAST_SYSTEM_CONNECTION_LOOKUP_INDEX, cxt);
		if (sysConnectionData != null)
		{
			return sysConnectionData._type;
		}
		CharSequence typeStr = cxt.getS(SYSTEM_CONNECTION_TYPE);
		return parseStorageType(typeStr);
 
	}
	
	static public boolean isModifyEvent(RdEventId storageEvent)
	{
		return (storageEvent == _writeData || storageEvent == _openFileOutputStream);
	}

	/**
	 * Uses fast lookup mechanics to get the default system connection data for this application.
	 * @param cxt The current context.
	 * @return The string data for this application.
	 */
	static public RdConnectionData getSystemConnectionData(RdContext cxt)
	{
		return (RdConnectionData)RdContextUtils.getFastCachedObject(
			FAST_SYSTEM_CONNECTION_LOOKUP_INDEX, cxt);
	}

	static public final void lock(RdStorageParameters params, RdContext cxt) 
		throws RdException
	{
		if (params._isLocked)
		{
			params._lockCount++;
			return;
		}
		// All retrieved results are no longer valid at the time transaction is started.
		params.resetForTransactionStart();
		params.prepareForWrite();
		
		callStorageEvent(_lock, params, cxt);
		params._isLocked = true;
	}
	
	static public final void unlock(RdStorageParameters params, RdContext cxt)
		throws RdException
	{
		if (!params._isLocked)
		{
			RP.trace("storage", "Release called without a lock", new Throwable(), cxt);
			return;
		}
		if (--params._lockCount > 0)
		{
			return;
		}
		callStorageEvent(_unlock, params, cxt);
		params._isLocked = false;
	}

	/**
	 * Reads the data from a standard resource file.
	 * If file is not present, that is not an error. Instead the params parameter
	 * will not have _targetedResourceExits set.
	 */
	static public final void readData(RdStorageParameters params, RdContext cxt)
		throws RdException
	{
		params.checkResetForNextFile();
		params.prepareForRead();
		
		callStorageEvent(_readData, params, cxt);
		
		if (params._targetedResourceExits)
		{
			cxt.put(DATA_FROM_STORAGE_KEY, Boolean.TRUE);
		}
	}

	/**
	 * Writes out data in resource format. The data written is the local
	 * data in the "cxt" parameter. If the data was read in from a
	 * resource file then the RdStorage.DATA_FROM_STORAGE_KEY boolean
	 * will have been set which will allow the current resource file
	 * to be replaced. If it is not set, then the _inFlags attribute
	 * of the "params" parameter will have to be set with the flag
	 * RdStorageParameters.F_ALWAYS_ALLOW_REPLACE in order to replace
	 * an existing resource file. This provides protection from
	 * files that falsely claimed they were missing when read in
	 * but were actually present and then get replaced with initialization
	 * data the next time they are written.
	 * @param params The current storage parameters
	 * @param cxt The current context
	 * @throws RdException
	 */
	static public final void writeData(RdStorageParameters params, RdContext cxt)
		throws RdException
	{
		params.checkResetForNextFile();
		params.prepareForWrite();
		boolean allowReplace = (params._inFlags & 
			RdStorageParameters.F_ALWAYS_ALLOW_REPLACE) != 0;
		if (!allowReplace)
		{
			// This offers some protection against a bad storage system that temporarily
			// loses files (or denies that they are present without a clear error).
			// If we believe we read this in from a file then we should be able
			// to write it back out to the same file.
			allowReplace = cxt.getB(RdStorage.DATA_FROM_STORAGE_KEY);
		}
		if (!allowReplace)
		{
			params._formattingAndStorageOptionsFlags |= RdContext.F_CREATE_STORAGE_ENTRY_ONLY;
		}
		callStorageEvent(_writeData, params, cxt);
	}

	/**
	 * Gets information about the file from a file listing (and not directly
	 * from the file itself).
	 * If file is not present, that is not an error. Instead the params parameter
	 * will not have _targetedResourceExits set.
	 */
	static public final void getFileInfo(RdStorageParameters params, RdContext cxt)
		throws RdException
	{
		params.checkResetForNextFile();
		params.prepareForRead();
		
		callStorageEvent(_getFileInfo, params, cxt);
	}
	
	static public final void notifyCloseInputStream(RdStorageInputStream inputStream) 
		throws RdException
	{
		RdEventParams eventParams = new RdEventParams(inputStream._params);
		eventParams._tempInternalParam = inputStream;
		
		// This event does not have to be handled.
		RdEventUtils.callEvent(_afterCloseInputStream, eventParams, inputStream._cxt);
	}
	
	static public void fillInDefaultData(RdStorageParameters params, RdContext cxt)
	{
		if (params._component == null)
		{
			RdComponentData componentData = RdComponentUtils.getApplicationComponentData(cxt);
			params._component = ((params._inFlags & RdStorageParameters.F_IS_DB_TABLE) != 0) ?
				componentData._dbstorageComponent : componentData._systemComponent;
		}
		if (params._connectionData == null)
		{
			params._connectionData = params._component._connectionData;
		}
		if (params._connectionData == null)
		{
			params._connectionData = RdStorage.getSystemConnectionData(cxt);
		}
	}
	
	static public final void callStorageEvent(RdEventId event, RdStorageParameters params,
		RdContext cxt) throws RdException
	{
		params._mainTopLevelEvent = event;
		params._handledMainEvent = false;
		params._storageEventPrepared = false;
		
		fillInDefaultData(params, cxt);
		if (params._connectionData == null)
		{
			throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR,
					"rdceNoSystemStorageImplemented");
		}
		
		RdEventParams eventParams = new RdEventParams(params, 
			RdEventParams.F_THROW_EXCEPTION_IF_ABORT_OR_FAIL);
		
		// If the file is being tracked by a database row in a table
		// this is the event that retrieves or stores that row.
		RdEventUtils.callEvent(_prepareStorageCall, eventParams, cxt);
		
		if (params._isReadOnlyData)
		{
			if (isModifyEvent(event))
			{
				throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR,
					"rdceEditActionPerformedOnReadOnlyData", params._componentPath,
					params._relativePath);
				
			}
		}
		
		boolean needToUnlock = false;
		try
		{
			if (event != _unlock && event != _afterCloseInputStream &&
				(params._inFlags & RdStorageParameters.F_IS_READ_ONLY_ACTION) == 0 && 
				!params._lockAcquired && !params._handledMainEvent)
			{
				if (event != _lock)
				{
					RdEventUtils.callEvent(_lock, eventParams, cxt);
					params._lockAcquired = true;
					params._lockCount = 1;
					needToUnlock = true;
					retrieveTransactionCounter(params, cxt);
					if (!params._transactionCounterRetrieved)
					{
						throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR,
							"rdceTransactionCounterNotCalculated");
					}
				}
			}
			RdEventUtils.callEvent(event, eventParams, cxt);
			if (eventParams._handledEvent)
			{
				params._handledMainEvent = true;
			}
			if (!params._handledMainEvent)
			{
				throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR, "rdceStorageEventNotHandled", 
					event._name); 
			}
			if (event == _lock)
			{
				retrieveTransactionCounter(params, cxt);
				if (!params._transactionCounterRetrieved)
				{
					throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR,
						"rdceTransactionCounterNotCalculated");
				}
			}
			
			// Let auditors and caching logic do their work.
			RdEventUtils.callEvent(_postProcessStorageCall, eventParams, cxt);
		}
		finally
		{
			if (needToUnlock)
			{
				RdEventUtils.callEvent(_unlock, eventParams, cxt);
				params._lockCount = 0;
				params._lockAcquired = false;
			}
		}
	}
	
	static public void callNotifyStorageEvent(RdEventId event, RdStorageParameters params,
		RdContext cxt) throws RdException
	{
		RdEventParams eventParams = new RdEventParams(params);
		RdEventUtils.callEvent(event, eventParams, cxt);
	}
	
	static public void retrieveTransactionCounter(RdStorageParameters storageParams,
		RdContext cxt) throws RdException
	{
		RdConnectionData systemConnectionData = getSystemConnectionData(cxt);
		RdCounterWrapper result = new RdCounterWrapper();
		synchronized (systemConnectionData)
		{
			if (systemConnectionData._registeredIncrementers == null)
			{
				systemConnectionData._registeredIncrementers = new ArrayList<RdCounterWrapper>();
			}
			systemConnectionData._registeredIncrementers.add(result);
			if (systemConnectionData._registeredIncrementers.size() > 1)
			{
				// Another thread is ahead of us, it will do the real work.
				result._waitForAnotherThread = true;
			}
		}
		if (result._waitForAnotherThread)
		{
			synchronized(result)
			{
				try
				{
					if (result._waitForAnotherThread)
					{
						result.wait();
					}
				}
				catch(Exception ignore)
				{
					// Ignore for now, maybe test later for global shutdown.
				}
			}
		}
		
		if (!result._isCounterSet && result._exception == null)
		{
			synchronized (systemConnectionData)
			{
				if (!result._isCounterSet && result._exception == null)
				{
					List<RdCounterWrapper> registeredConnections = systemConnectionData._registeredIncrementers;
					int numRegistered = (registeredConnections != null) ?
						registeredConnections.size() : 0;
					RdStorageParameters emptySystemStorageParams = new RdStorageParameters();
					emptySystemStorageParams._connectionData = systemConnectionData;
					emptySystemStorageParams._extraIncrementCount = numRegistered - 1;
					RdEventParams incrementParams = new RdEventParams(emptySystemStorageParams);
					boolean isFailed = false;
					RdException exception = null;
					try
					{
						RdEventUtils.callEvent(_incrementTransactionCounter, incrementParams, cxt);
					}
					catch (RdException e)
					{
						isFailed = true;
						exception = e;
					}
					long startCounter = emptySystemStorageParams._transactionCounter;
					long nextCounter = emptySystemStorageParams._nextTransactionCounter;
					if (!isFailed && (startCounter <= 0 || startCounter + numRegistered > nextCounter))
					{
						exception = new RdException("rdceStorageInvalidTransactionCounter", "" + startCounter,
							"" + numRegistered, "" + nextCounter);
						isFailed = true;
					}
					for (int i = 0; i < numRegistered; i++)
					{
						RdCounterWrapper w = registeredConnections.get(i);
						synchronized (w)
						{
							if (!isFailed)
							{
								w._isCounterSet = true;
								w._counter = startCounter + i;
								w._nextCounter = nextCounter;
							}
							else
							{
								w._exception = exception;
							}
							if (w._waitForAnotherThread)
							{
								w._waitForAnotherThread = false;
								w.notify();
							}
						}
					}
				}
			}
		}
		if (!result._isCounterSet)
		{
			throw new RdException(result._exception, "rdceStorageCouldNotGetCounter");
		}
		storageParams._transactionCounter = result._counter;
		storageParams._nextTransactionCounter = result._nextCounter;
		storageParams._transactionCounterRetrieved = true;
	}
}
