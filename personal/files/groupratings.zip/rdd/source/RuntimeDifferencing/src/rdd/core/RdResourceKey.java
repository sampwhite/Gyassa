package rdd.core;

/**
 * Globally unique key for a particular resource. Note that if two resources have the same
 * name but are of different type, then they will have a different RdResourceKey object
 * associated with them. Many times resource keys are promoted into being true RdKey
 * objects. If that happens, then that RdKey can reference only one type of resource.
 */
public class RdResourceKey
{
	public int _resourceType;
	public String _resourceName;
	
	public RdResourceKey(int resourceType, String resourceName)
	{
		_resourceType = resourceType;
		_resourceName = resourceName;
	}
	
	@Override
	public String toString()
	{
		return _resourceName + "{" + 
			((_resourceType >= 0 && _resourceType < RdResourceTypes.RESOURCE_TYPE_LABELS.length) ? 
				RdResourceTypes.RESOURCE_TYPE_LABELS[_resourceType] : "") + "}";
	}
}
