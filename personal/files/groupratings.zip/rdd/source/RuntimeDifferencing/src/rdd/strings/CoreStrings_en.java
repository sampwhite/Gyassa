package rdd.strings;

import rdd.core.strings.RdStringList;
/**
 * The algorithm for string names is as follows:
 * 
 * First two letters are the project ("rd" for the RDD project). The next letter indicates the
 * part of the project ("c" = "core") and the fourth letter indicates the type of message. The
 * types are:
 * 
 * 
 * e = error message
 * i = general system information message
 * w = shown to user on web page
 * 
 * This string set should be as inclusive as possible (it should aggregate from multiple
 * RDD packages).
 *
 */
public class CoreStrings_en implements RdStringList
{
	public String[][] _strings = new String[][]
	{
		{"rdciRddVersion", "Runtime Differencing Data (RDD) Version {1}"},
		{"rdceSystemFailure", "An unexpected system failure occurred"},
		{"rdceNodeManagerAlreadyPreInit", "The local node manager class has already been initalized, it does not support repeat initializations."},
		{"rdceNoNodeConfigFile", "No local node configuration file (see NodeConfigFile) was specified. It is required for this application."},
		{"rdceUnableToCreateDirectory", "Failed to create the subdirectory with the full path {1}."},
		{"rdceTargetFileForRenameExists", "Failed to rename because target file {1} exists and caller does not allow deletions of existing files"},
		{"rdceFileCouldNotBeDeleted", "The  file {1} could not be deleted."},
		{"rdceFileRenameFailed", "Failed to rename file from {1} to {2}"},
		{"rdceFailedToParseFile", "Failed to parse the file {1}."},
		{"rdceLogRotatingLoggerNotInit", "The rotating log requires initial configuration before it can be used."},
		{"rdceParsingInvalidResourceTypeCharacter", "The character '{3}' is invalid as part of a variable or parameter name."},
		{"rdceUnterminatedResource", "The resource {1} has no properly formed end termination."},
		{"rdceParsingInvalidResourceNameCharacter", "The character '{3}' is invalid as part of a resource name."},
		{"rdceParseUnclosedKeyParameters", "The parameter specification for the resource has no closing right bracked (])."},
		{"rdceParseResourceHasNoName", "The resource construction does not specify a name for the resource."},
		{"rdceParseMapInvalidCharacter", "The text for the Map resource has the invalid character '{1}'"},
		{"rdceParseErrorLocation", "The parsing error occurred at line {1} and column {2}."},
		{"rdceParseFailureForDate", "Failed to parse date from string {1}."},
		{"rdceStringResourceFailedToLoad", "The string resource {1} with language choide {2} failed to load."},
		{"rdceEventAborted", "The event {1} was aborted by handler with ID {2}."},
		{"rdceEventNoRegisteredHandlers", "There are no registered handlers for the event {1}."},
		{"rdceFilePathHasNoProperParentDirectory", "The file path {1} does not have a usable parent directory"},
		{"rdceNoSystemStorageImplemented", "No system storage solution is configured. The application cannot retrieve its configuration data."},
		{"rdceStorageEventNotHandled", "Storage event '{1}' was not handled by any implementor"},
		{"rdceSharedFileSystemNotConfigured", "The shared file system requires SharedFileSystemDirectory to be set"},
		{"rdceFileIsLockedFromAccess", "The file {1} could not be accessed even though it exists. THis is likely a permissions issue."},
		{"rdceCouldNotCreateFile", "Unable to create file at path {1}."},
		{"rdceParentDirectoryForFileDoesNotExist", "The parent directory for the file at path {1} does not exist"},
		{"rdceEditActionPerformedOnReadOnlyData", "The directory {1} is marked as read only and does not allow an edit action on {2}"},
		{"rdceTransactionCounterNotCalculated", "Transaction counter for storage operation was not calculated successfully"},
		{"rdceCouldNotWriteToFile", "Unable to write to the file {1} after successfully opening it."},
		{"rdceFailedToCreateLockOnLockFile", "Failed to create lock on lock file {1}"},
		{"rdceReplacingFileThatIsNotSupposedToExist", "The component {1} and relative path {2} were found unexpectedly to already exist."},
		{"rdceReservingLockFileThatIsAlreadyLocked", "The file {1} has two lock owners, lock system has failed."},
		{"rdceReleasingLockOnUnlockedDirectory", "Releasing a lock on a directory {1} that is not locked"},
		{"rdceLockKeyForDirectoryWasNotFound", "Lock entry for file {1} was not found"},
		{"rdceFailedToReadFileList", "The file {1} containing the file list for the directory could not be read in."},
		{"rdceFailedToReadFile", "Failed to read file {1}."},
		{"rdcePathFailureInRecursiveSubstitution", "Error in doing recursive path substitution value retrieved by key {1}."},
		{"rdcePathNoClosingBrace", "No closing brace was found for opening brace in path substitution syntax."},
		{"rdcePathSubstitutionError", "Path substitution error at recursive level {1} on string {2}."},
		{"rdcePathVariableNotFound", "Path variable not found for lookup key {1}."},
	};

	@Override
	public String[][] getStringList()
	{
		// TODO Auto-generated method stub
		return _strings;
	}

}
