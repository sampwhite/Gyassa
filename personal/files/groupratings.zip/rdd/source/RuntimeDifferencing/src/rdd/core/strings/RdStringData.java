package rdd.core.strings;

import java.io.IOException;

import rdd.core.RdAppendDebug;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;
import rdd.core.RdResourceKey;

public class RdStringData implements RdAppendDebug
{
	public RdResourceKey _stringId;
	public String[] _localizedStrings;
	public int _flags; // See RdDataFlags.
	
	public RdStringData(RdResourceKey stringId)
	{
		_stringId = stringId;
	}

	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		appendable.append(_stringId._resourceName);
		if (_localizedStrings != null)
		{
			appendable.append("=(");
			RdDataUtils.appendDebugObject(appendable, _localizedStrings, cxt, flags);
			appendable.append(')');
		}
	}

	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
