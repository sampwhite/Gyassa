package rdd.core;

public class RdEventParams
{
	//+section Flags
	static public int F_THROW_EXCEPTION_IF_ABORT_OR_FAIL = 1;
	//+endsection Flags
	
	public RdEventId _event;
	public boolean _handledEvent;
	public Object _param;
	public Object _retVal;
	public Object _tempInternalParam;
	public RdEventRegistration[] _registeredHandlers;
	public int _handlerIndex;
	public int _flags;

	public RdEventParams(Object param)
	{
		_param = param;
	}

	public RdEventParams(Object param, int flags)
	{
		_param = param;
		_flags = flags;
	}
}
