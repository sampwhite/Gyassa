package rdd.core.primitives;

import java.util.ArrayList;
import java.util.List;

public class ArrayUtils
{
	/**
	 * Swaps in a new value for the current value of a list. If the list
	 * is not big enough, then the list is expanded and null is returned.
	 * @param <T> The value to be stored in the array.
	 * @param array The array being acted on.
	 * @param index The index in the array where the old value will be retrieved
	 * and the new value put.
	 * @param element The value to put at the index.
	 * @return The old value at the index.
	 */
	static public <T> T setAllowGrowth(List<T> array, int index, T element)
	{
		int l = array.size();
		T currentValue = null;
		if (index >= l)
		{
			for (int i = l; i < index; i++)
			{
				array.add(null);
			}
			array.add(element);
		}
		else
		{
			currentValue = array.get(index);
			array.set(index, element);
		}
		return currentValue;
	}
	
	/**
	 * Sets a new value for the current value of an array. If the array
	 * is not big enough, then the array is expanded. The current
	 * array (after being reallocated if necessary) is returned.
	 * @param <T> The value to be stored in the array.
	 * @param array The array being acted on.
	 * @param index The index in the array where the old value will be retrieved
	 * and the new value put.
	 * @param element The value to put at the index.
	 * @return The passed in array or a new array if it needed to grow in size.
	 */
	static public <T> T[] setAllowGrowthArray(T[] array, int index, T element)
	{
		int l = (array != null) ? array.length : 0;
		T[] retArray = array;
		if (index >= l)
		{
			int minNewSize = 2 * (l + 1);
			int growSize = (index > minNewSize) ? index : minNewSize;
			Class arrayType = (array != null) ? array.getClass().getComponentType() :
				element.getClass();
			retArray = (T[])java.lang.reflect.Array.newInstance(
				arrayType, growSize + 1);			
			if (l > 0)
			{
				System.arraycopy(array, 0, retArray, 0, l);
			}
		}
		retArray[index] = element;
		return retArray;
	}
	
	/**
	 * Clones an array preserving they array type.
	 * @param array The array to clone.
	 * @return An array of objects of the same type.
	 */
	static public <T> T[] cloneArray(T[] array)
	{
		if (array == null)
		{
			return null;
		}
		Class arrayType = array.getClass().getComponentType();
		T[] retArray = (T[])java.lang.reflect.Array.newInstance(
			arrayType, array.length);			
		if (array.length > 0)
		{
			System.arraycopy(array, 0, retArray, 0, array.length);
		}
		return retArray;
	}
	
	/**
	 * Clones a List.
	 */
	static public <T> List<T> cloneList(List<T> list)
	{
		Class listType = list.getClass();
		List<T> retVal = list;
		try
		{
			retVal = (List<T>)listType.newInstance();
		}
		catch (Exception ignore)
		{
			// Create our own array object.
			retVal = new ArrayList<T>();
		}
		retVal.addAll(list);
		return retVal;
	}
}
