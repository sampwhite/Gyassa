package rdd.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class RdEventHandlers
{
	public Map<String,RdEventInterface> _handlerObjects;
	public Map<String,RdEventRegistration> _registeredEvents;
	public Map<RdEventId,List<RdEventRegistration>> _registeredEventLists;
	public Map<RdEventId,RdEventRegistration[]> _fastRegisteredEvents;
	
	public RdEventHandlers()
	{
		_handlerObjects = new HashMap<String,RdEventInterface>();
		_registeredEvents = new HashMap<String,RdEventRegistration>();
		_registeredEventLists = new HashMap<RdEventId,List<RdEventRegistration>>();
		_fastRegisteredEvents = new ConcurrentHashMap<RdEventId,RdEventRegistration[]>();
	}
	
	/**
	 * Gets existing or creates the handler object for the filter being registered.
	 * This method can only be called if this object has been synchronized.
	 * @param registration The filter which needs its Java handler retrieved or instantiated.
	 * @throws RdException
	 */
	protected void associateHandler(RdEventRegistration registration, RdContext cxt)
		throws RdException
	{
		String className = registration._className;
		RdEventInterface handler = _handlerObjects.get(className);
		if (handler == null)
		{
			try
			{
				if (registration._classLoader == null)
				{
					registration._classLoader = cxt.getClassLoader();
				}
				Class filterHandler = registration._classLoader.loadClass(className);
				handler = (RdEventInterface)filterHandler.newInstance();
				handler.init(cxt);
				_handlerObjects.put(className, handler);
			}
			catch (Exception e)
			{
				RdException err = new RdException("rdcsEventCannotInstantiateClass");
				err.initCause(e);
				throw err;
			}
		}
		registration._eventHandler = handler;
	}
	
	public synchronized void updateRegisteredEvents(List<RdEventRegistration> addOrUpdateEvents,
		List<RdEventRegistration> registeredEventsToDelete, RdContext cxt) throws RdException
	{
		if (registeredEventsToDelete != null)
		{
			for (RdEventRegistration deletedReg : registeredEventsToDelete)
			{
				RdEventRegistration existingReg = _registeredEvents.get(deletedReg._id);
				if (existingReg != null)
				{
					RdEventId eventId = existingReg._event;
					_fastRegisteredEvents.remove(eventId);
					List<RdEventRegistration> regs = _registeredEventLists.get(eventId);
					if (regs != null)
					{
						for (int i = 0; i < regs.size(); i++)
						{
							RdEventRegistration curReg = regs.get(i);
						
							if (curReg._id.equals(existingReg._id))
							{
								regs.remove(i);
								if (regs.size() == 0)
								{
									_registeredEventLists.remove(eventId);
								}
								break;
							}
						}
					}
				}
			}
		}
		
		if (addOrUpdateEvents != null)
		{
			for (RdEventRegistration updateReg : addOrUpdateEvents)
			{
				RdEventRegistration existingReg = _registeredEvents.get(updateReg._id);
				if (existingReg != null)
				{
					RdEventId existingEventId = existingReg._event;
					_fastRegisteredEvents.remove(existingEventId);
					List<RdEventRegistration> regsToCheck = _registeredEventLists.get(existingEventId);
					if (regsToCheck != null)
					{
						for (int i = 0; i < regsToCheck.size(); i++)
						{
							RdEventRegistration curReg = regsToCheck.get(i);
						
							if (curReg._id.equals(existingReg._id))
							{
								regsToCheck.remove(i);
								break;
							}
						}
					}
				}
				RdEventId updatingEventId = updateReg._event;
				_fastRegisteredEvents.remove(updatingEventId);
				List<RdEventRegistration> regs = _registeredEventLists.get(updatingEventId);
				if (regs == null)
				{
					regs = new ArrayList<RdEventRegistration>(1);
					_registeredEventLists.put(updatingEventId, regs);
				}
				associateHandler(updateReg, cxt);
				regs.add(updateReg);
			}
		}
	}
	
	public RdEventRegistration[] getRegisteredFilters(RdEventId event)
	{
		RdEventRegistration[] eventFilters = _fastRegisteredEvents.get(event);
		if (eventFilters == null)
		{
			eventFilters = computeAndGetEventFilters(event);
		}
		return eventFilters;
	}
	
	/**
	 * Gets this order array of registered events for a particular event ID.
	 * @param event The event ID to retrieve
	 * @return
	 */
	public synchronized RdEventRegistration[] computeAndGetEventFilters(RdEventId event)
	{
		List<RdEventRegistration> regs = _registeredEventLists.get(event);
		RdEventRegistration[] retRegs;
		if (regs == null)
		{
			retRegs = new RdEventRegistration[0];
		}
		else
		{
			retRegs = new RdEventRegistration[regs.size()];
			for (int i = 0; i < regs.size(); i++)
			{
				retRegs[i] = regs.get(i);
			}
			Arrays.sort(retRegs);
		}
		_fastRegisteredEvents.put(event, retRegs);
		return retRegs;
	}
	
}
