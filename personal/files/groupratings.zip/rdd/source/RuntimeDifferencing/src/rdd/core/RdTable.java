package rdd.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import rdd.core.primitives.ArrayUtils;
import rdd.core.primitives.StrUtils;

/**
 * A flexible table implementation. Rows and row values will appear on demand and are not created
 * in anticipation of usage.
 */
public class RdTable implements RdAppender, Map<RdKey,Object>, Cloneable, RdCloneable
{
	/**
	 * Flags from RdDataFlags.
	 */
	public int _flags;
	
	/**
	 * The fields in the table. Note, the order that they occur in this array
	 * is not necessarily the formatting order (see the _index attribute
	 * of the RdTableField class).
	 */
	public List<RdTableField> _fields;
	
	/**
	 * Fast lookup from field name to definition information.
	 */
	public Map<RdKey,RdTableField> _keysToFieldsMap;
	
	/**
	 * The rows of data.
	 */
	public List<List<Object>> _rows;
	
	/**
	 * Single field indexes on the rows. The _index attribute of the RdTableField
	 * object is used to look up into this array. It is permissible for entries
	 * in this array to be null.
	 */
	public RdTableIndex[] _simpleFieldIndexes;
	
	/**
	 * Multi-column field indexes. The array is expanded as needed and the
	 * multi-column indexes are added as created. The presumption is that
	 * at most one of these will ever be created.
	 */
	public List<RdTableIndex> _multiColumnIndexes;
	
	/**
	 * One column is selected as the primary key. If the primary key covers
	 * multiple columns, then an artificial column (see RdTableUtils.TABLE_COMPUTED_PK_KEY)
	 * is added and the value for it is created by joining the values from the columns
	 * making up the primary key. This new column is then specified as the primary key.
	 * If no column is specified, then the first column is assumed to be the primary key.
	 * The primary key is used to do merging of resource tables that have the same name
	 * but are in different components. If the table is given different primary keys in
	 * different components, that is considered to be an error. Generally the
	 * primary key is assumed to be case sensitive. If it is case insensitive, then
	 * the computed column is always created and the value is the lower case version
	 * of the original specified primary key(s).
	 */
	public int _primaryKeyIndex;
	
	/**
	 * If the table is to be applied as a "diff" then it may do deletes. An artificial
	 * column is added to indicate whether the row is actually to be deleted in the target.
	 * This is the index of that column. The value has to greater than zero to be used.
	 */
	public int _deleteColumnIndex;
	
	/**
	 * This object remembers the current row it is on, this means the object
	 * has to be shallow cloned any time another thread of execution needs to
	 * iterate through the object. This approach caters to "hunting" algorithms
	 * for finding the lookup value for a key. The current row of the table
	 * is one of the places that is "hunted". Using "hunting" algorithms means
	 * that script can be written that is simple looking and is reusable in many
	 * different contexts (makes round trip handling of HTML forms simpler).
	 */
	public int _currentRow;
	
	/**
	 * Extra information about the table.
	 */
	public RdResourceDefinition _extraDefinition;

	
	public RdTable()
	{
		init();
	}
	
	public RdTable(RdKey[] keys)
	{
		init();
		addFields(keys);
	}
	
	public RdTable(List<RdKey> keys)
	{
		init();
		addFields(keys);
	}
	
	public RdTable(RdKey[] keys, Object[][] rows)
	{
		init();
		addFields(keys);
		for (Object[] row : rows)
		{
			if (row != null)
			{
				List<Object> tableRow = new ArrayList<Object>(row.length);
				for (Object elt : row)
				{
					tableRow.add(elt);
				}
				addRow(tableRow);
			}
		}
	}
	
	/**
	 * Used to create "index tables" that are shallow wrappers for rows retrieved
	 * when using the RdTableIndex object to lookup of rows matching a field index.
	 * @param fields Fields to share with another table.
	 * @param keysToFieldsMap Lookup map to share with another table.
	 */
	public RdTable(List<RdTableField> fields, Map<RdKey,RdTableField> keysToFieldsMap)
	{
		_fields = fields;
		_keysToFieldsMap = keysToFieldsMap;
		_rows = new ArrayList<List<Object>>();
	}
	
	public void init()
	{
		_fields = new ArrayList<RdTableField>();
		_keysToFieldsMap = new HashMap<RdKey,RdTableField>();
		_rows = new ArrayList<List<Object>>();
	}
	
	public void addFields(RdKey[] keys)
	{
		int counter = _fields.size();
		for (RdKey key : keys)
		{
			if (!_fields.contains(key))
			{
				RdTableField field = new RdTableField(key, counter);
				counter++;
				_fields.add(field);
				_keysToFieldsMap.put(key, field);
			}
		}
		
	}
	
	public void addField(RdKey key)
	{
		addField(key, 0);
	}

	public void addFields(List<RdKey> keys)
	{
		int counter = _fields.size();
		for (RdKey key : keys)
		{
			if (!_fields.contains(key))
			{
				RdTableField field = new RdTableField(key, counter);
				counter++;
				_fields.add(field);
				_keysToFieldsMap.put(key, field);
			}
		}
	}

	public void addTableFields(List<RdTableField> fields)
	{
		int counter = _fields.size();
		for (RdTableField field : fields)
		{
			if (!_fields.contains(field._key))
			{
				RdTableField newField = new RdTableField(field._key, counter);
				counter++;
				_fields.add(newField);
				_keysToFieldsMap.put(field._key, newField);
			}
		}
	}

	public void addField(RdKey key, int fieldFlags)
	{
		int counter = _fields.size();
		if (!_fields.contains(key))
		{
			RdTableField field = new RdTableField(key, counter);
			field._flags = fieldFlags;
			_fields.add(field);
			_keysToFieldsMap.put(key, field);
		}
	}

	/**
	 * Typically access to a shared copy of a RdTable starts with this method call.
	 */
	public RdTable shallowClone()
	{
		RdTable newTable = new RdTable();
		newTable.shallowCopy(this);
		return newTable;
	}
	
	public void shallowCopy(RdTable copyFrom)
	{
		_flags = copyFrom._flags;
		_fields = copyFrom._fields;
		_keysToFieldsMap = copyFrom._keysToFieldsMap;
		_rows = copyFrom._rows;
	}
	
	/**
	 * Used to build tables with subsets of rows from
	 * this table.
	 * @return A table with the same attributes for
	 * fields but an empty list of rows. Mutating
	 * field design in this table will mutate
	 * the design in the returned table.
	 */
	public RdTable shallowDesignClone()
	{
		return new RdTable(_fields, _keysToFieldsMap);
	}
	
	public void copyFullDataInPlace()
	{
		_fields = RdDataUtils.cloneList(_fields);
		_keysToFieldsMap = RdDataUtils.cloneRdMap(_keysToFieldsMap);
		_rows = RdDataUtils.cloneList(_rows);
		for (int i = 0; i < _rows.size(); i++)
		{
			List<Object> row = _rows.get(i);
			List<Object>rowClone = RdDataUtils.cloneList(row);
			_rows.set(0, rowClone);
		}
		_flags &= ~RdDataFlags.F_READ_ONLY;
	}
	
	//+section RdCloneable interface
	@Override
	public Object clone(int depth, RdContext cxt)
	{
		// Note, this version of clone is the only one that preserves the current row. The
		// other clone methods assume you are starting over for iterating on the new
		// table. This method assumes that the table is interior to another object
		// and makes no such presumption.
		RdTable newTable = shallowClone();
		newTable._currentRow = _currentRow;
		if (depth > 0)
		{
			_fields = RdDataUtils.cloneList(_fields);
			_keysToFieldsMap = RdDataUtils.cloneRdMap(_keysToFieldsMap);
			newTable._rows = (List)RdCloner.cloneObject(_rows, 
				depth - 1, cxt);
			newTable._flags &= ~RdDataFlags.F_READ_ONLY;
		}
		return newTable;
	}
	//+endsection RdCloneable interface 

	
	public boolean hasCorrectRowTrackingCounters()
	{
		return (_flags & RdDataFlags.F_HAS_ROW_TRACKING_COUNTERS) != 0;
 	}
	
	public void markHasRowTrackingCounters()
	{
		_flags |= RdDataFlags.F_HAS_ROW_TRACKING_COUNTERS;
	}
	
	public void clearMarkForRowTrackingCounters()
	{
		_flags &= ~RdDataFlags.F_HAS_ROW_TRACKING_COUNTERS;
	}
		
	public Map<RdKey,Object> createMapFromCurrentRow()
	{
		Map<RdKey,Object> map = new HashMap<RdKey,Object>();
		if (_currentRow >= 0 && _currentRow < _rows.size())
		{
			List<Object> row = _rows.get(_currentRow);
			int rowSize = row.size();
			for (RdTableField field : _fields)
			{
				int index = field._index;
				if (index >= 0 && index < rowSize)
				{
					Object val = row.get(index);
					if (val != null)
					{
						map.put(field._key, val);
					}
				}
			}
		}
		
		return map;
	}
	
	public int getNumRows()
	{
		return _rows.size();
	}
	
	public boolean isEmptyTable()
	{
		return (_rows.isEmpty());
	}
	
	public boolean isRowPresent()
	{
		return (_currentRow >= 0 && _currentRow < _rows.size());		
	}
	
	public void setCurrentRowIndex(int rowIndex)
	{
		_currentRow = rowIndex;
	}
	
	public List<Object> getCurrentRow()
	{
		return isEmpty() ?
			null :
				_rows.get(_currentRow);
	}
	
	public RdKey getTableFieldKey(int index)
	{
		return _fields.get(index)._key;
	}
	
	public int getTableFieldIndex(RdKey key)
	{
		RdTableField field = _keysToFieldsMap.get(key);
		return (field != null) ? field._index : -1;
	}
	
	/**
	 * Method requires that _currentRow not be negative. This method
	 * will create missing rows until _currentRow points at a valid row.
	 */
	public List<Object> getOrInstantiateCurrentRow()
	{
		for (int i = _rows.size(); i <= _currentRow; i++)
		{
			_rows.add(new ArrayList<Object>());
		}
		
		// Allow bad lookups to propagate upwards.
		List<Object> row = _rows.get(_currentRow);

		return row;
	}
	
	public List<Object> createCompatibleEmptyRow()
	{
		return new ArrayList<Object>();
	}
	
	public void createAndSetToNewEndRow()
	{
		_rows.add(new ArrayList<Object>());
		_currentRow = _rows.size() - 1;
	}
	
	public void addRow(List<Object> row)
	{
		_rows.add(row);
	}
	
	public Object replaceCompatibleListRowValue(List<Object> row, RdKey key, Object value,
		RdContext cxt)
	{
		value = RdDataUtils.cooerceToSettableValue(key, value, _flags);

		RdTableField field = _keysToFieldsMap.get(key);
		if (field == null || field._index < 0)
		{
			int index = _fields.size();
			if (field == null)
			{
				field = new RdTableField(key, index);
				_fields.add(field);
				_keysToFieldsMap.put(key, field);
			}
			else
			{
				field._index = index;
			}
		}
		int index = field._index;
		return ArrayUtils.setAllowGrowth(row, index, value);
	}
	
	public RdValue getV(RdKey key)
	{
		RdTableField field = _keysToFieldsMap.get(key);
		RdValue val = null;
		if (field != null)
		{
			List<Object> curRow = getCurrentRow();
			int index = field._index;
			if (index >= 0 && index < curRow.size())
			{
				Object oVal = curRow.get(index);
				if (!(oVal instanceof RdValue) && oVal != null)
				{
					val = new RdValue(key, oVal);
					val._flags = RdDataFlags.setIsSharedFlag(_flags, val._flags);
					
					// Since we are replacing object with an equivalent one, we
					// are going to assume that this can be done without synchronization
					// or thread safety issues (since only a simple pointer of a
					// newly created object is being set).
					curRow.set(index, val);
				}
			}
		}
		if (val == null)
		{
			val = RdGlobalValues.ORIGINALLY_NULL_VALUE;
		}
		return val;
	}

	public void putDirectByIndex(int fieldIndex, Object value)
	{
		List<Object> row = getOrInstantiateCurrentRow();
		ArrayUtils.setAllowGrowth(row, fieldIndex, value);
	}

	//+ section Implementation of Map interface
	@Override
	public int size()
	{
		if (_currentRow < 0 || _currentRow >= _rows.size())
		{
			return 0;
		}
		return _fields.size();
	}
	/**
	 * This method may not function as expected. It asks if there is no valid CURRENT row. This method
	 * may be called by somebody who thinks they only have a Map object and expect it to have consistent behavior.
	 */
	@Override
	public boolean isEmpty()
	{
		return !isRowPresent();
	}
	@Override
	public boolean containsKey(Object key)
	{
		return _keysToFieldsMap.containsKey(key);
	}
	@Override
	public boolean containsValue(Object value)
	{
		List<Object> curRow = getCurrentRow();
		if (curRow != null)
		{
			return curRow.contains(value);
		}
		return false;
	}
	/**
	 * This method will behave inconsistently with containsKey
	 * if the current row marker is on an invalid row
	 * or if the table is empty.
	 */
	@Override
	public Object get(Object key)
	{
		RdTableField field = _keysToFieldsMap.get(key);
		if (field != null)
		{
			List<Object> curRow = getCurrentRow();
			int index = field._index;
			if (curRow != null && index >= 0 && index < curRow.size())
			{
				return curRow.get(index);
			}
		}
		return null;
	}
	@Override
	public Object put(RdKey key, Object value)
	{
		List<Object> row = getOrInstantiateCurrentRow();
		return replaceCompatibleListRowValue(row, key, value, null);
	}
	
	@Override
	public Object remove(Object key)
	{
		List<Object> curRow = getCurrentRow();
		Object retVal = null;
		if (curRow != null)
		{
			RdTableField field = _keysToFieldsMap.get(key);
			if (field != null && field._index >= 0)
			{
				if (field._index < curRow.size())
				{
					retVal = curRow.get(field._index);
					curRow.set(field._index, null);
				}
			}
		}
		return retVal;
	}
	@Override
	public void putAll(Map<? extends RdKey, ? extends Object> m)
	{
		List<Object> row = getOrInstantiateCurrentRow();
		Set<? extends RdKey> keySet = m.keySet();
		for (RdKey key : keySet)
		{
			Object value = m.get(key);
			replaceCompatibleListRowValue(row, key, value, null);
		}
	}
	
	@Override
	public void clear()
	{
		List<Object> curRow = getCurrentRow();
		if (curRow != null)
		{
			for (int i = 0; i < curRow.size(); i++)
			{
				curRow.set(i, null);
			}
		}
	}
	
	/**
	 * This key set is read only.
	 */
	@Override
	public Set<RdKey> keySet()
	{
		if (isRowPresent())
		{
			return _keysToFieldsMap.keySet();
		}
		return new HashSet<RdKey>();
	}
	@Override
	public Collection<Object> values()
	{
		if (!isRowPresent())
		{
			return new ArrayList<Object>();
		}
		return getCurrentRow();
	}
	@Override
	public Set<java.util.Map.Entry<RdKey, Object>> entrySet()
	{
		if (!isRowPresent())
		{
			return new HashSet<java.util.Map.Entry<RdKey, Object>>();
		}
		return createMapFromCurrentRow().entrySet();
	}
//+endsection Implementation of Map interface

//+section Implementation of RdAppender interface
	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags) throws IOException
	{
		// We create a pretty format, but with some overhead to do it.
		int nRows = _rows.size();
		int startNumFields = _fields.size();
		
		// Calculate the number of fields we actually will output.
		int nFields = 0;
		RdTableField usedFields[] = new RdTableField[startNumFields];
		for (int i = 0; i < startNumFields; i++)
		{
			RdTableField rtf = _fields.get(i);
			if (rtf.isSerializable() || 
				(flags & RdContext.F_DEBUG_FORMAT) != 0)
			{
				if (rtf._index >= 0)
				{
					usedFields[i] = rtf;
					nFields++;
				}
			}
		}
		
		CharSequence[][] tableValues = new CharSequence[nRows + 1][];
		int[] fieldMap = new int[nFields];
		CharSequence[] fields = new CharSequence[nFields];
		
		int fieldIndex = 0;
		for (int i = 0; i < usedFields.length; i++)
		{
			RdTableField rtf = usedFields[i];
			if (rtf != null)
			{
				fieldMap[fieldIndex] = rtf._index;
				fields[fieldIndex] = rtf._key._name;
				fieldIndex++;
			}
		}
		tableValues[0] = fields;
		RdCharArray temp = null;
		
		for (int i = 0; i < nRows; i++)
		{
			List<Object> curRow = _rows.get(i);
			CharSequence[] cRow = new CharSequence[nFields];
			tableValues[i + 1] = cRow;
			int curRowLen = (curRow != null) ? curRow.size() : 0;
			for (int j = 0; j < nFields; j++)
			{
				int index = fieldMap[j];
				CharSequence cVal = null;
				if (index < curRowLen)
				{
					Object value = curRow.get(index);
					if (value != null)
					{
						if (value instanceof CharSequence)
						{
							cVal = (CharSequence)value;
						}
						else if (value instanceof RdValue)
						{
							RdValue rVal = (RdValue)value;
							if (rVal._sVal != null)
							{
								cVal = rVal._sVal;
							}
						}
						if (cVal == null)
						{
							if (temp == null)
							{
								temp = cxt.temporaryAllocateCharArray();
							}
							else
							{
								temp.reset();
							}
							RdDataUtils.appendTo(temp, value, key, depth + 1, cxt, flags);
							cVal = temp;
						}
					}
				}
				if (cVal == null)
				{
					cVal = "";
				}
				if (cVal.length() == 0)
				{
					cRow[j] = "";
				}
				else
				{
					RdCharArray encodedVal = cxt.temporaryAllocateCharArray();
					StrUtils.appendEncodedStr(encodedVal, cVal, key, cxt, 
						StrUtils.F_ENCODE_ARRAY_CHARS | StrUtils.F_ENCODE_LF);
					cRow[j] = encodedVal;
				}
			}
		}

		if (temp != null)
		{
			cxt.releaseTemporaryAllocatedCharArray(temp);
		}

		// We look for maximum lengths in each column.
		int[] maxLen = new int[nFields];
		int[] proposedMaxLen = new int[nFields];
		
		for (int i = 0; i < tableValues.length; i++)
		{
			CharSequence[] row = tableValues[i];
			for (int j = 0; j < row.length; j++)
			{
				int l = row[j].length();
				int curProposedLen = proposedMaxLen[j];
				int curMaxLen = maxLen[j];
				boolean useItForMax = false;
				if (curMaxLen == 0)
				{
					useItForMax = true;
				}
				else if (curProposedLen == 0 || l < 2 * curProposedLen)
				{
					proposedMaxLen[j] = l;
					useItForMax = true;
				}
				else
				{
					// We don't let one out of wack row change our formatting for all the others.
					proposedMaxLen[j] =  2 * curProposedLen;
				}
				if (useItForMax && l > curMaxLen)
				{
					maxLen[j] = l;
				}
			}
		}
		
		// Output the table in pretty CSV format.
		for (int i = 0; i < tableValues.length; i++)
		{
			CharSequence[] row = tableValues[i];
			for (int j = 0; j < row.length; j++)
			{
				int l = row[j].length();
				int curMaxLen = maxLen[j];
				int extraSpaces = (l < curMaxLen) ? curMaxLen - l : 0;
				extraSpaces++; // Force a space between values.
				CharSequence cVal = row[j];
				appendable.append(cVal);
				if (j < row.length - 1)
				{
					appendable.append(',');
					if (extraSpaces > 10)
					{
						int loopCount = extraSpaces/10;
						extraSpaces = extraSpaces % 10;
						for (int k = 0; k < loopCount; k++)
						{
							appendable.append(StrUtils.SPACE_10_CHARS);
						}
					}

					if (extraSpaces > 0)
					{
						if (extraSpaces == 1)
						{
							appendable.append(' ');
						}
						else
						{
							appendable.append(StrUtils.SPACE_10_CHARS, 0, extraSpaces);
						}
					}
				}
				if (i > 0 && cVal != "")
				{
					cxt.releaseTemporaryAllocatedCharArray((RdCharArray)cVal);
				}
			}
			if (i < tableValues.length - 1)
			{
				appendable.append('\n');
			}
		}
	}
//+endsection Implementation of RdAppender interface

	@Override
	public Object clone()
	{
		RdTable dt = shallowClone();
		dt.copyFullDataInPlace();
		return dt;
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
