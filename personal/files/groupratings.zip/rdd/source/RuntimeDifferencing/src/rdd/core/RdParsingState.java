package rdd.core;

public class RdParsingState
{
	public RdResourceLocator _locator;
	public String _resName;
	public RdKey _key;
	public int _resType;
	public int _depth;
	public int _line;
	public int _col;
	public RdCharArray _inChars;
	public int _inCharsPos;
	public RdCharArray _copyBuffer;
	public RdContext _cxt;
	public RdResourceDefinition _resourceDef;
	public RdParsingState _parent;
	
	// What we are parsing flags.
	public boolean _failed;
	public boolean _needsEndTag;
	public int _failureFlags;
	public RdException _error;
	
	public RdParsingState(RdContext cxt)
	{
		_cxt = cxt;
	}
	public RdParsingState(CharSequence path, RdContext cxt)
	{
		_locator = new RdResourceLocator(path);
		_locator._hasLineOffsetAndCharInfo = true;
		_cxt = cxt;
		init();
	}
	
	public RdParsingState createChild(int line, int col, int depth, 
		RdCharArray inChars, int inCharsPos)
	{
		RdParsingState child = new RdParsingState(_cxt);
		child._locator = _locator;
		child._parent = this;
		child._line = line;
		child._col = col;
		child._depth = depth;
		child._inChars = inChars;
		child._inCharsPos = inCharsPos;
		child._copyBuffer = _cxt.temporaryAllocateCharArray();
		return child;
	}
	
	public void init()
	{
		if (_inChars == null)
		{
			_inChars = _cxt.temporaryAllocateCharArray();
		}
		if (_copyBuffer == null)
		{
			_copyBuffer = _cxt.temporaryAllocateCharArray();
		}
	}
	
	public void release()
	{
		if (_cxt != null && _inChars != null)
		{
			_cxt.releaseTemporaryAllocatedCharArray(_inChars);
		}
		if (_cxt != null && _copyBuffer != null)
		{
			_cxt.releaseTemporaryAllocatedCharArray(_copyBuffer);
		}
		_inChars = null;
		_copyBuffer = null;
	}
}
