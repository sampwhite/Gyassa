package rdd.strings;

import rdd.core.strings.RdStringPackage;

public class RdCorePackage implements RdStringPackage
{

	@Override
	public String[] getStringListClasses()
	{
		return new String[]{"rdd.strings.CoreStrings"};
	}

	@Override
	public String[] getLanguageList()
	{
		// Only English is versioned controlled in normal fashion.
		return new String[]{"en"};
	}
}
