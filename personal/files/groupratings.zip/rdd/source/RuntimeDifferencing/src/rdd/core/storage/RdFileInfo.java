package rdd.core.storage;

import java.io.IOException;
import java.util.Date;

import rdd.core.RdAppender;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;
import rdd.core.RdKey;
import rdd.core.component.RdComponentDefinition;

public class RdFileInfo implements RdAppender
{
	//+section Flags
	static public int F_IS_DIRECTORY = 1;
	static public int F_IS_DEVELOPMENT_CONTROLLED_PATH = 2;
	static public int F_HAS_TRANSACTION_COUNTER = 4;
	static public int F_HAS_LAST_MODIFIED = 8;
	static public int F_HAS_LAST_CHANGE_USER = 16;
	static public int F_HAS_LOCAL_CACHE_FILE_PATH = 32;
	//+endsection Flags
	
	/**
	 * The connection data used to access the file. This is the actual connection data
	 * used to get the information, not necessarily the connection information to use
	 * when updating the data.
	 */
	public RdConnectionData _connectionData;
	
	/**
	 * Component the file (or directory) was found in. This is definition at the time
	 * the file was loaded, not necessarily the current definition. Also, if there is more
	 * than one source for the same component, this attribute will reflect the true source.
	 */
	public RdComponentDefinition _component;
	
	/**
	 * Relative path to file.
	 */
	public String _relativePath;
	
	/**
	 * The usage type. See RdFileListUtils.FILE_USAGE_TYPE for more. The default is
	 * "data".
	 */
	public String _usageType;
	
	/**
	 * Whether there is a transaction counter and other issues about
	 * the file.
	 */
	public long _flags;
	
	/**
	 * The transaction counter at the time the file was last edited. This can be
	 */
	public long _transactionCounter;
	
	/**
	 * The last modified time stamp for the file.
	 */
	public long _lastModified;
	
	/**
	 * Last change user.
	 */
	public String _lastModifiedUser;
	
	/**
	 * The file path where a local cache copy of the file can be found. Used
	 * for publishing solutions driven by the transaction counter looking
	 * more "most recent changes". This value is not persisted into storage. Also,
	 * it is ignored if a transactional update is being performed or if caching
	 * is not being used for a particular directory in a component.
	 */
	public String _cachePath;

	public RdFileInfo(RdConnectionData connectionData, RdComponentDefinition component, 
		String relativePath)
	{
		_connectionData = connectionData;
		_component = component;
		_relativePath = relativePath;
	}

	@Override
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags)
		throws IOException
	{
		appendable.append("" + _component);
		if (_relativePath != null && _relativePath.length() > 0)
		{
			appendable.append('/');
			appendable.append(_relativePath);
		}
		boolean appendedLeftParen = false;
		if ((_flags & F_IS_DEVELOPMENT_CONTROLLED_PATH) != 0)
		{
			RdDataUtils.appendDebugNameValue(appendable, "developer", 
				null, key, depth, cxt, appendedLeftParen, flags);
			appendedLeftParen = true;
		}
		if ((_flags & F_HAS_TRANSACTION_COUNTER) != 0)
		{
			RdDataUtils.appendDebugNameValue(appendable, "trancounter", 
				""+_transactionCounter, key, depth, cxt, appendedLeftParen, flags);
			appendedLeftParen = true;
		}
		if ((_flags & F_HAS_LAST_MODIFIED) != 0)
		{
			RdDataUtils.appendDebugNameValue(appendable, "lastmodified", 
				new Date(_lastModified), key, depth, cxt, appendedLeftParen, flags);
			appendedLeftParen = true;
		}
		if ((_flags & F_HAS_LAST_CHANGE_USER) != 0)
		{
			RdDataUtils.appendDebugNameValue(appendable, "lastAuthor", 
				_lastModifiedUser, key, depth, cxt, appendedLeftParen, flags);
			appendedLeftParen = true;
		}
		if ((_flags & F_HAS_LOCAL_CACHE_FILE_PATH) != 0)
		{
			RdDataUtils.appendDebugNameValue(appendable, "cachePath", 
				_cachePath, key, depth, cxt, appendedLeftParen, flags);
			appendedLeftParen = true;
		}
		if (appendedLeftParen)
		{
			appendable.append(')');
		}
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
