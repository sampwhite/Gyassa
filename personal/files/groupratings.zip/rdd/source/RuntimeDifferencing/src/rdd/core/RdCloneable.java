package rdd.core;

public interface RdCloneable
{
	/**
	 * Clones object. The depth indicates how deep recursively the clone will go.
	 * At depth of 1, the object will clone direct references to generic objects,
	 * at depth 2, it will go inside container objects to clone objects instead
	 * of just cloning the containers.
	 * @param depth How deeply the cloning will go. It will not detect loops in
	 * object pointers, so it will undo loops.
	 * @param cxt The current context.
	 * @return A cloned copy of this object.
	 */
	public Object clone(int depth, RdContext cxt);
}
