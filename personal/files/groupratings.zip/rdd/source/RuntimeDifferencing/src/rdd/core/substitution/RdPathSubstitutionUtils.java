package rdd.core.substitution;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.RdException;
import rdd.core.RdKey;
import rdd.core.primitives.StrUtils;

public class RdPathSubstitutionUtils
{
	//+section Flags for variable substitution
	static public final int F_USE_CONTEXT = 1;
	static public final int F_THROW_ERRORS = 2;
	static public final int F_SUPRESS_MISSING_VAR_ERRORS = 4;
	//+endsection Flags for variable substitution
	
	/**
	 * Looks up a variable value using objKey from 'values', and if it is missing there
	 * it looks it up from 'cxt'. If the value is found, then path substitution
	 * is performed on it. See substitutePathVariablesSimple for the method that
	 * is used to to the path substitution.
	 * @param values - The primary place where objKey is used to find a value.
	 * @param objKey - A lookup key that should either be an RdKey or a CharSequence.
	 * @param deflt - The value to return if no path value could be found.
	 * @param cxt - The current context that is available as a last resort to find values.
	 */
	static public String getAndSubstitutePathVariables(Map<RdKey,Object> values, Object objKey, 
		String deflt, RdContext cxt) throws RdException
	{
		if (objKey == null)
		{
			return null;
		}
		RdKey key;
		if (objKey instanceof RdKey)
		{
			key = (RdKey)objKey;
		}
		else
		{
			String keyStr = objKey.toString();
			key = cxt.getEquivalentKeyObject(keyStr, 0);
		}
		Object value = null;
		if (key != null)
		{
			value = values.get(key);
			if (value == null && cxt != values)
			{
				value = cxt.get(key);
			}
		}
		if (value == null)
		{
			value = deflt;
		}
		if (value != null)
		{
			value = substitutePathVariablesSimple(values, value, cxt);
		}
		return (value != null) ? value.toString() : null;
	}
	
	/**
	 * Convenience function for doing simple path substitution using $VAR or ${VAR} type syntax.
	 * See substitutePathVariables for more on syntax. This method will throw an exception
	 * if a path variable is not found and it will search the 'cxt' parameter if a variable
	 * is not found in the 'values' parameter.
	 * @param values - The primary source for substitution variables. Any values found here
	 * or in the 'cxt' parameter will be recursively processed for path script.
	 * @param str - The string with the path script syntax in it.
	 * @param cxt - The current context which will be accessed for lookup if a value is not found
	 * in 'values'.
	 * @return The result of the 'str' parameter after all substitution is performed.
	 * @throws RdException
	 */
	static public String substitutePathVariablesSimple(Map<RdKey,Object> values, Object str,
		RdContext cxt) throws RdException
	{
		RdCharArray tempOut = cxt.temporaryAllocateCharArray();
		
		substitutePathVariablesInObject(values, str, tempOut, 0, null, F_USE_CONTEXT | F_THROW_ERRORS, cxt);
		String retVal = tempOut.toString();
		cxt.releaseTemporaryAllocatedCharArray(tempOut);
		return retVal;
	}
	
	/**
	 * A method that turns the 'str' parameter into character array to be processed by the
	 * substitutePathVariables method. See substitutePathVariables for description of
	 * functionality and parameters. 
	 * @throws RdException
	 */
	static public void substitutePathVariablesInObject(Map<RdKey,Object> values, Object str, Appendable output,
		int depth, RdSubstitutionErrors errors, int flags, RdContext cxt) throws RdException
	{
		if (str == null)
		{
			return;
		}
		
		char[] arr;
		int len;
		if (str instanceof char[])
		{
			arr = (char[])str;
			len = arr.length;
		}
		else if (str instanceof RdCharArray)
		{
			RdCharArray temp = (RdCharArray)str;
			arr = temp._chars;
			len = temp._len;
		}
		else
		{
			// Non optimized case. But first
			// see if we can skip looking inside the
			// string.
			String sVal = str.toString();
			if (sVal.indexOf('$') < 0)
			{
				try
				{
					output.append(sVal);
				}
				catch (IOException e)
				{
					throw new RdException(e, null);
				}
				
				// Do no additional work.
				arr = null;
				len = 0;
			}
			else
			{
				arr = sVal.toCharArray();
				len = arr.length;
			}
		}
		if (arr != null && len > 0)
		{
			substitutePathVariables(values, arr, 0, len, output, depth, errors, flags, cxt);
		}
	}
	
	/**
	 * A function that does simple path substitution in a string. A typical case might be
	 * where AppDir is set to <location_of_app> in a Map object and you then refer to the data
	 * subdirectory with the syntax $AppDir/data. This method is used to substitute $AppDir
	 * with the appropriate value.
	 * There are quite a few subtleties. The first is that the substitution is recursive.
	 * Example:
	 * Assume A=X$B, B=Y$C, and C=ZD, then applying this method to $A will give you XYZD.
	 * 
	 * Variables are terminated by non variable characters such as / or <sp>. If you want more
	 * precise control over the span of the variable name, then use the syntax ${myvar}.
	 * Example:
	 * Assume A=X${B}Z and B=Y, then applying this method will give XYZ. But if A=X$BZ then
	 * the substitution method will report an exception that the variable BZ has no value.
	 * 
	 * The syntax also supports a default value for the expression following a colon.
	 * Example:
	 * Assume A=$XX:YY/ZZ and XX is not defined, then the result of the substitution is YY/ZZ.
	 * 
	 * The default value is also processed for script. The first $ after the colon will be
	 * interpreted as a start of a variable if no braces are being used to define the scope,
	 * otherwise braces should be used to define the part of the path that is the default value if
	 * you want recursive evaluation.
	 * Example:
	 * Assume A=$XX:$BB/ZZ and BB=YY then the result of substitution is YY/ZZ. But if you
	 * assign A=$BB:DD$CC/ZZ and BB=XX and CC=YY, then you will get the string XXYY/ZZ. To
	 * get the desired effect you need to use A=${BB:DD$CC}/ZZ which will give the result XX/ZZ.
	 * 
	 * If the outer substitution if enclosed in braces then the default can have its own default.
	 * This does not work if there are no braces to define the extent of the default value's script.
	 * Example: Assuming nothing is set, evaluating $A:$B:C will cause an error reporting that
	 * B is missing but ${A:$B:C} will evaluate to C.
	 * 
	 * @param values The primary source for substituting variables.
	 * @param arr The array to parse and do substitutions on.
	 * @param start The start position in the array to start the parsing.
	 * @param end The end position of the parsing, parsing stops one before this index.
	 * @param output The evaluated script is output here.
	 * @param depth The current recursive depth of the evaluation. Starts at zero.
	 * @param errors If not null, then errors will be captured here if F_THROW_ERRORS
	 * is not set.
	 * @param flags The flags that control execution, see flags above.
	 * @param cxt The current context. If the flag F_USE_CONTEXT is set, then if a value
	 * is not found in the 'values' parameter, then it will be searched for in this parameter.
	 * @throws RdException
	 */
	static public void substitutePathVariables(Map<RdKey,Object> values, char[] arr, int start, int end, Appendable output, 
		int depth, RdSubstitutionErrors errors, int flags, RdContext cxt) throws RdException
	{
		try
		{
			if (!hasDollarInIt(arr, start, end) || depth >= 10)
			{
				if (output instanceof Writer)
				{
					((Writer)output).write(arr, start, end - start);
				}
				else
				{
					RdCharArray tempOut = cxt.temporaryAllocateCharArray();
					tempOut.write(arr, start, end - start);
					output.append(tempOut);
					cxt.releaseTemporaryAllocatedCharArray(tempOut);
				}
				return;
			}
			
			int startVarIndex = -1;
			boolean insideVar = false;
			boolean foundDollar = false;
			boolean foundBrace = false;
			RdCharArray deflt = null;
			
			for (int i = start; i < end; i++)
			{
				boolean doVarSubstitution = false;
				boolean startVar = false;
				boolean appendChar = false;
				char ch = arr[i];
				if (ch == '$')
				{
					if (foundDollar)
					{
						if (insideVar)
						{
							if (!foundBrace)
							{
								startVar = true;
								doVarSubstitution = true;
							}
						}
						else if (!foundBrace)
						{
							// $$ becomes $ in output.
							foundDollar = false;
							appendChar = true;
						}
						else
						{
							insideVar = true;
							startVarIndex = i;
						}
					}
					else
					{
						// Set foundDollar to true after having dealt with current
						// substitution.
						startVar = true;
					}
				}
				else if (ch == '{')
				{
					if (foundDollar)
					{
						if (!insideVar)
						{
							foundBrace = true;
						}
						else
						{
							doVarSubstitution = true;
							appendChar = true;
						}
					}
				}
				else if (ch == '}')
				{
					if (foundBrace || insideVar)
					{
						doVarSubstitution = true;
						if (!foundBrace)
						{
							appendChar = true;
						}
					}
					
				}
				else
				{
					if (foundDollar)
					{
						if (ch != '_' && !Character.isLetterOrDigit(ch))
						{
							if (insideVar || foundBrace)
							{
								if (!foundBrace || ch == ':')
								{
									doVarSubstitution = true;
									if (ch != ':')
									{
										appendChar = true;
									}
								}
							}
							else
							{
								// Improper construct, just output it.
								output.append('$');
								foundDollar = false;
								appendChar = true;
							}
						}
						else
						{
							if (!insideVar)
							{
								startVarIndex = i;
								insideVar = true;
							}
						}
					}
					else
					{
						appendChar = true;
					}
				}
				if (doVarSubstitution)
				{
					boolean reportIfMissing = (ch != ':');
					int endVarIndex = i;
					Object result = lookupKey(arr, start, end, startVarIndex, endVarIndex, values, flags, 
							reportIfMissing, depth, errors, cxt);
					// See if there is a default.
					if (ch == ':')
					{
						// There is a default value, figure out its extent and
						// process it.
						int startExpressionIndex = i + 1;
						int endExpressionIndex = determineEndIndexOfExpression(arr, i + 1, end, foundBrace);
						if (result == null)
						{
							if (deflt == null)
							{
								deflt = cxt.temporaryAllocateCharArray();
							}
							deflt.reset();
							
							substitutePathVariables(values, arr, startExpressionIndex, endExpressionIndex,
								deflt, depth + 1, errors, flags, cxt);
							if (!StrUtils.isMatchingStrings(deflt, "-"))
							{
								output.append(deflt);
							}
						}
						i = endExpressionIndex;
						if (endExpressionIndex < end && !foundBrace)
						{
							// Redo last character.
							i--; 
						}
					}
					else
					{
						if (foundBrace)
						{
							// Increment past closing brace.
							i++;
						}
					}
					// Recursively process result of lookup.
					if (result != null)
					{
						try
						{
							substitutePathVariablesInObject(values, result, output, depth + 1, errors, flags, cxt);
						}
						catch (Throwable t)
						{
							String key = new String(arr, startVarIndex, endVarIndex - startVarIndex);
							throw new RdException(t, "rdcePathFailureInRecursiveSubstitution", key);
						}
					}
					foundDollar = false;
					foundBrace = false;
					insideVar = false;
				}
				if (appendChar)
				{
					output.append(ch);
				}
				if (startVar)
				{
					foundDollar = true;
				}
			}
			
			// Clean up.
			if (foundDollar)
			{
				if (foundBrace)
				{
					RdException e = new RdException("rdcePathNoClosingBrace");
					processException(null, depth, arr, start, end, errors, flags, e);
				}
				else if (insideVar)
				{
					// Last variable to substitute.
					Object result = lookupKey(arr, start, end, startVarIndex, end, values, flags, 
						true, depth, errors, cxt);
					if (result != null)
					{
						try
						{
							substitutePathVariablesInObject(values, result, output, depth + 1, errors, flags, cxt);
						}
						catch (Throwable t)
						{
							String key = new String(arr, startVarIndex, end - startVarIndex);
							throw new RdException(t, "rdcePathFailureInRecursiveSubstitution", key);
						}
					}
				}
				else
				{
					// A dollar with nothing following it.
					output.append('$');
				}
			}
			
			if (deflt != null)
			{
				cxt.releaseTemporaryAllocatedCharArray(deflt);
			}
		}
		catch (Throwable t)
		{
			String pathScript = new String(arr, start, end - start);
			RdException reportErr = new RdException(t, "rdcePathSubstitutionError", "" + depth, pathScript);
			throw reportErr;
		}
	}
	
	/**
	 * Sees if an array has a $ in it. Used to skip path substitution when
	 * no $ is found.
	 * @param arr The array to scan.
	 * @param start Where to start.
	 * @param end Where to end, scan stops one before this value.
	 * @return Whether a $ was found.
	 */
	static public boolean hasDollarInIt(char[] arr, int start, int end)
	{
		boolean foundDollar = false;
		for (int i = start; i < end; i++)
		{
			if (arr[i] == '$')
			{
				foundDollar = true;
				break;
			}
		}
		return foundDollar;
	}
	
	/**
	 * Process an exception and store it in the 'errors' parameter or throw it as appropriate.
	 * @param key The key that is being used as a lookup key. Can be null.
	 * @param depth The current recursive depth. The error is only captured if depth is
	 * zero, otherwise it is thrown so that it will eventually be reported again by
	 * this method where it can be captured with a full stack trace (or thrown
	 * if that is the designated preference).
	 * @param arr The array that was being parsed and search for variables to substitute.
	 * @param start The start offset in the array.
	 * @param end The end position in the array, parsing stops one before this index.
	 * @param errors If not null, then errors will be captured if F_THROW_ERRORS
	 * is not set in the 'flags' parameter.
	 * @param flags The current flags, see flags at top of class.
	 * @param t The exception that caused this error to be reported.
	 * @throws IOException If t is an IOException, then it will be thrown again untouched,
	 * if that is the preference.
	 * @throws RdException If t is an RdException, then it will be thrown again untouched, if
	 * that is the preference. If t is another type of exception, then the thrown RdException
	 * will be new and have t as a cause.
	 */
	static public void processException(String key, int depth, char[] arr, int start, int end, 
		RdSubstitutionErrors errors, int flags, Throwable t) throws IOException, RdException
	{
		if ((flags & F_THROW_ERRORS) != 0 || depth > 0)
		{
			if (t instanceof RdException)
			{
				throw (RdException)t;
			}
			else if (t instanceof IOException)
			{
				throw (IOException)t;
			}
			throw new RdException(t, null);
		}
		if (errors != null)
		{
			String pathScript = new String(arr, start, end - start);
			errors._substitutionErrors.add(new RdSubstitutionError(key, pathScript, t));
		}
	}
	
	/**
	 * Support method for substitutePathVariables with complicated interior logic.
	 */
	static public int determineEndIndexOfExpression(char[] arr, int start, int end, boolean insideBrace)
	{
		int braceNesting = 0;
		int endIndex = end;
		for (int i = start; i < end; i++)
		{
			char ch = arr[i];
			if (insideBrace)
			{
				if (ch == '{')
				{
					braceNesting++;
				}
				else if (ch == '}')
				{
					braceNesting--;
					if (braceNesting < 0)
					{
						endIndex = i;
						break;
					}
				}
			}
			else if (ch != '_' && !Character.isLetterOrDigit(ch))
			{
				if (i != start || ch != '$')
				{
					endIndex = i;
					break;
				}
			}
		}
		return endIndex;
	}
	
	/**
	 * Support method for substitutePathVariables with complicated interior logic.
	 */
	static public Object lookupKey(char[] arr, int start, int end, int varStart, int varEnd, Map<RdKey,Object> map, int flags, 
		boolean reportIfMissing, int depth, RdSubstitutionErrors errors, RdContext cxt) throws IOException, RdException
	{
		String keyStr = new String(arr, varStart, varEnd - varStart);
		Object retVal = null;
		RdKey key = cxt.getEquivalentKeyObject(keyStr, 0);
		if (key != null)
		{
			retVal = map.get(key);
			if (retVal == null && (flags & F_USE_CONTEXT) != 0 && map != cxt)
			{
				retVal = cxt.get(key);
			}
		}
		if (reportIfMissing && retVal == null && (flags & F_SUPRESS_MISSING_VAR_ERRORS) == 0)
		{
			RdException e = new RdException("rdcePathVariableNotFound", keyStr);
			processException(keyStr, depth, arr, start, end, errors, flags, e);
		}		
		return retVal;
	}
}
