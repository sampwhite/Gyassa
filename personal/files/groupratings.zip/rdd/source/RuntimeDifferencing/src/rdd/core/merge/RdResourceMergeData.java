package rdd.core.merge;

import java.util.List;
import java.util.Map;

import rdd.core.RdLocation;
import rdd.core.RdResourceKey;

/**
 * Holds a body of loaded data from many sources. Used to calculate "diff packages" to
 * apply to the actual location where the data is retrieved.
 */
public class RdResourceMergeData
{
	public List<RdMergeableData> _dataList;
	public Map<RdLocation,RdMergeableData> _dataMap;
	
	public Map<RdResourceKey,RdMergeStack> _overlayedData;
}
