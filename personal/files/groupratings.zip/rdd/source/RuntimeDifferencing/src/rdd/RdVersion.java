/** Copyright for this file is in NOTICE.txt at root directory of the rdd Java package */
package rdd;

/**
 * This is information only about version for the RD package. It has no implications for the
 * versions of the applications built with the RD package. Also, individual components can
 * advertise versioned "abilities", bundles of components can be versioned and large packaging
 * for a specific product can be versioned.
 */
public class RdVersion
{
	static public final int RD_VERSION_ARRAY[] = new int[]{0,0,0,1};
	static public String RD_VERSION = "0.0.0.1";
}
