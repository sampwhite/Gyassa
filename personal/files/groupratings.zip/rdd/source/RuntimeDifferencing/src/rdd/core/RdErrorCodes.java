package rdd.core;

/**
 * General error codes. Instead of each API layer having its own error codes, we capture common error causes into a single
 * list.
 */
public class RdErrorCodes
{
	static public final int NO_ERROR = 0;
	static public final int GENERAL_ERROR = 1;
	
	//+section Resource errors
	static public final int RESOURCE_NOT_FOUND = -0x10; // The most common error. HTTP 404
	static public final int RESOURCE_FAILED_ACCESS = -0x11;
	static public final int RESOURCE_LOCKED = -0x12;
	static public final int RESOURCE_ALREADY_EXISTS  = -0x13;
	static public final int RESOURCE_NOT_WRITABLE = -0x14;
	static public final int RESOURCE_IMPROPER_PATH = -0x15;
	//+endsection Resource errors
	
	//+section Permission errors for end user to receive
	static public final int INSUFFICIENT_PRIVILEGE = -0x20; // Maybe after authentication, can access. HTTP 401
	static public final int ACCESS_DENIED = -0x21; // Need to logout, login as more privileged user. HTTP 403
	//+endsection Permission errors
	
	//+section IO errors
	static public final int FAILED_CONNECTION = -0x30; // Ex: could not connect to database
	static public final int FAILED_AUTH_CONNECTION = -0x31; // Ex: authentication failed to database
	static public final int FAILED_ADDRESS_RESOLUTION = -0x32; // Ex: host not found in DNS lookup, or bad IPv6 address
	static public final int FAILED_READ = -0x33;
	static public final int FAILED_WRITE = -0x34;
	//+endsection IO errors
	
	//+section System errors
	static public final int GENERAL_SYSTEM_ERROR = -0x40; // General very bad error not covered by other codes.
	static public final int RUNTIME_SYSTEM_ERROR = -0x41; // Null pointer, array access out of bounds, etc.
	//+endsection System errors
}
