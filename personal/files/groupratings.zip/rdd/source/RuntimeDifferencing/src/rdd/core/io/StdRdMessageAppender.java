package rdd.core.io;

import java.io.IOException;
import java.io.PrintStream;

import rdd.core.RdContext;
import rdd.core.RdException;

/**
 * A simple message appender that just appends message to an appendable. The idea
 * is that in more complex applications, this object can be replaced with a more
 * sophisticated solution.
 */
public class StdRdMessageAppender implements RdMessageAppender
{
	public Appendable _appendable;
	
	public StdRdMessageAppender(Appendable appendable)
	{
		_appendable = appendable;
	}

	@Override
	public void appendMessage(CharSequence msg, int flags, RdContext cxt) throws RdException
	{
		boolean addLf = (flags & RdMessageAppender.F_APPEND_LF) != 0;
		if (addLf && _appendable instanceof PrintStream)
		{
			// Use the more efficient PrintStream.
			((PrintStream)_appendable).println(msg);
		}
		else
		{
			try
			{
				_appendable.append(msg);
				if (addLf)
				{
					_appendable.append('\n');
				}
			}
			catch (IOException e)
			{
				throw new RdException(e, null);
			}
		}
	}
}
