package rdd.core;

public class RdTableField
{
	//+section Flags
	static public int F_SUPPLEMENTARY_DATA = 1;
	//+endsection
	
	public RdKey _key;
	public int _index;
	public int _flags;
	
	public RdTableField(RdKey key, int index)
	{
		_key = key;
		_index = index;
	}
	
	@Override
	public String toString()
	{
		return _key + "(" + _index + ")";
	}
	
	public boolean isSerializable()
	{
		return _key.isSerializableValue() && (_flags & F_SUPPLEMENTARY_DATA) == 0;
	}
}
