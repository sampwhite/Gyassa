package rdd.core.resource;

import java.util.Map;


import rdd.core.RdContext;
import rdd.core.RdKey;
import rdd.core.RdParseMapCallback;
import rdd.core.RdParsingState;

public class RdParseMapWrapper implements RdParseMapCallback
{
	static public final int F_LOWER_CASE_KEYS = 1;
	static public final int F_USE_RD_KEYS = 2;
	public int _mapFlags;
	public Map _map;
	
	public RdParseMapWrapper(Map map, int flags)
	{
		_map = map;
		_mapFlags = flags;
	}

	//+section Interface RdParseMapCallback
	@Override
	public void onParseNameValue(char[] keyArray, int keyStart, int keyEnd, char[] valArray, int valStart, int valEnd, 
		RdParsingState state, int flags)
	{
		char firstCh = keyArray[keyStart];
		boolean removingKey = false;
		if (firstCh == '~')
		{
			removingKey = (firstCh == '~');
			keyStart++;
		}
		
		if ((_mapFlags & F_LOWER_CASE_KEYS) != 0)
		{
			for (int i = keyStart; i < keyEnd; i++)
			{
				char ch = keyArray[i];
				if (ch >= 'A' && ch <= 'Z')
				{
					ch = (char)('a' + (ch - 'A'));
					keyArray[i] = ch;
				}
			}
		}
		String sKey = new String(keyArray, keyStart, keyEnd - keyStart);
		Object oKey = sKey;
		if ((_mapFlags & F_USE_RD_KEYS) != 0)
		{
			RdKey rKey = state._cxt.getEquivalentKeyObject(sKey, RdContext.F_CREATE_IF_MISSING);
			oKey = rKey;
		}
		if (!removingKey)
		{
			String val = (valStart < valEnd) ? new String(valArray, valStart, valEnd - valStart) : "1";
			_map.put(oKey, val);
		}
		else
		{
			_map.remove(oKey);
		}
	}
	//+endsection Interface RdParseMapCallback
}
