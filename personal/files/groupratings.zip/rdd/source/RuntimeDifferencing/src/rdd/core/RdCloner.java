package rdd.core;

import java.util.List;
import java.util.Map;
import java.util.Set;

import rdd.core.primitives.ArrayUtils;
import rdd.core.primitives.MapUtils;

public class RdCloner
{
	/**
	 * This method clones an object recursively. Note, certain attributes of objects will
	 * not necessarily get cloned with the object. This is because the cloned object is likely
	 * to be modified and the other attributes in the original object presume that the main interior 
	 * data object (which is true of the original object) is read only. Even though a generic
	 * depth attribute is supported, it is expected that the only values ever used for depth
	 * are 0 and 1.
	 * @param obj The object to clone following RDD project rules.
	 * @param depth The recursive depth to do cloning.
	 * @param cxt The current context.
	 * @return A cloned object that is designed to be modifiable.
	 */
	static public Object cloneObject(Object obj, int depth, RdContext cxt)
	{
		// CharSequence are treated as unmodifiable objects (even if they are not really, but
		// once inside of a standard RDD container object they are treated as if they
		// are unmodifiable).
		if (obj instanceof CharSequence || obj == null)
		{
			return obj;
		}
		
		Object retVal = obj;
		if (obj instanceof RdCloneable)
		{
			retVal = ((RdCloneable)obj).clone(depth, cxt);
		}
		else if (obj instanceof Object[])
		{
			Object[] array = (Object[])obj;
			Object[] clonedArray = ArrayUtils.cloneArray(array);
			if (depth > 0)
			{
				for (int i = 0; i < clonedArray.length; i++)
				{
					clonedArray[i] = cloneObject(clonedArray[i], depth - 1, cxt);
				}
			}
			retVal = clonedArray;
		}
		else if (obj instanceof List)
		{
			List l = ArrayUtils.cloneList((List)obj);
			if (depth > 0)
			{
				int size = l.size();
				for (int i = 0; i < size; i++)
				{
					Object co = l.get(i);
					co = cloneObject(co, depth - 1, cxt);
					l.set(i, co);
				}
			}
		}
		else if (obj instanceof Map)
		{
			Map m = MapUtils.cloneMap((Map)obj);
			if (depth > 0)
			{
				Set keys = m.keySet();
				for (Object key : keys)
				{
					Object val = m.get(key);
					val = cloneObject(val, depth - 1, cxt);
					m.put(key, val);
				}
			}
		}
		return retVal;
	}
}
