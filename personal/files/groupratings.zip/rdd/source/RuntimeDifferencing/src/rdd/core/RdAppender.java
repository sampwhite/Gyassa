package rdd.core;

import java.io.IOException;

public interface RdAppender
{
	/**
	 * Generic interface for appending a Rdd core object. Generally what is appended can be used to rebuild the object if
	 * read back in (but not always).
	 * @param appendable The object that implements that Appendable interface that will get the data appended to it.
	 * @param key The associated with the current object being appended.
	 * @param depth The recursive depth of the method call. Used to detect pointer loops.
	 * @param cxt The context.
	 * @param flags Flags to control how the value should be appended. See RdContext.F_DEBUG_FORMAT and others.
	 * @throws IOException
	 */
	public void appendTo(Appendable appendable, RdKey key, int depth, RdContext cxt, int flags) throws IOException;
}
