package rdd.core.primitives;

import java.util.Random;

import rdd.core.RdContext;
import rdd.core.RdObjectLifeCycleOptimizer;

public class RandomUtils
{
	/**
	 * Returns the next random long calculated by using the current Random object assigned to
	 * the RdContext object. This method does not guarantee initialization that meets the
	 * needs of cryptography.
	 * @param cxt The current context.
	 * @return A random long value.
	 */
	static public long randomLong(RdContext cxt)
	{
		Random random = getCurrentRandom(cxt);
		return random.nextLong();
	}
	
	/**
	 * Gets the current Random object associated with the context. It will create a Random
	 * object if necessary but it will not be a cryptographically strong Random object.
	 * @param cxt
	 * @return
	 */
	static public Random getCurrentRandom(RdContext cxt)
	{
		RdObjectLifeCycleOptimizer optimizer = cxt.getWrapperContext()._objectOptimizer;
		if (optimizer._random == null)
		{
			optimizer._random = new Random();
		}
		return optimizer._random;
	}
	
}
