package rdd.sharedfilestorage;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import rdd.core.logger.RP;

public class ActiveLock
{
	FileLock _lock;
	String _path;
	RandomAccessFile _file;
	FileChannel _channel;
	
	public ActiveLock(String path)
	{
		_path = path;
	}
	
	public void lock() throws IOException
	{
		_file = new RandomAccessFile(_path, "rw");
		_channel = _file.getChannel();
		_lock = _channel.lock();
	}
	
	public void release()
	{
		try
		{
			_lock.release();
			_file.close();
		}
		catch (Exception e)
		{
			RP.errT(e);
		}
	}
}
