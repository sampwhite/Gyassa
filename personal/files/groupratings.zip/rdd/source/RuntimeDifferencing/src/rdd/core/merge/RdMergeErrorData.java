package rdd.core.merge;

import rdd.core.RdResourceDefinition;
import rdd.core.RdResourceKey;

public class RdMergeErrorData
{
	public RdResourceDefinition _current;
	public RdResourceDefinition _overlay;
	public RdResourceKey _key;
	public int _errType;
}
