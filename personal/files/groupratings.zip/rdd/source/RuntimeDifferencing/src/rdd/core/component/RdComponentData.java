package rdd.core.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RdComponentData
{
	public RdComponentDefinition _systemComponent;
	public RdComponentDefinition _dbstorageComponent;
	public List<RdComponentDefinition> _components;
	public Map<String,RdComponentDefinition> _componentsMap;
	
	public RdComponentData()
	{
		_components = new ArrayList<RdComponentDefinition>();
		_componentsMap = new HashMap<String,RdComponentDefinition>();
		setComponentDefinition(RdComponentUtils._globalSystemComponent);
		setComponentDefinition(RdComponentUtils._globalDbstorageComponent);
	}
	
	synchronized public List<RdComponentDefinition> getCloneOfComponentList()
	{
		return (List<RdComponentDefinition>)((ArrayList<RdComponentDefinition>)_components).clone();
	}
	
	synchronized RdComponentDefinition getComponentDefinition(String key)
	{
		return _componentsMap.get(key);
	}
	
	synchronized RdComponentDefinition getOrCreateComponentDefinition(String key, int componentFlags)
	{
		RdComponentDefinition def = _componentsMap.get(key);
		if (def == null)
		{
			def = new RdComponentDefinition(key, componentFlags);
			setComponentDefinition(def);
		}
		return def;
	}
	
	synchronized void setComponentDefinition(RdComponentDefinition def)
	{
		String key = def._name;
		if (key.equals(RdComponentUtils._globalSystemComponent._name))
		{
			_systemComponent = def;
		}
		else if (key.equals(RdComponentUtils._globalDbstorageComponent._name))
		{
			_dbstorageComponent = def;
		}
		RdComponentDefinition existingDef = _componentsMap.put(key, def);
		if (existingDef != null)
		{
			_components.remove(existingDef);
		}
		_components.add(def);
	}
	
	synchronized void setComponentList(List<RdComponentDefinition> list)
	{
		_components.clear();
		_componentsMap.clear();
		for (RdComponentDefinition def : list)
		{
			setComponentDefinition(def);
		}
	}
}
