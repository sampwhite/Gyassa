package rdd.security;

import java.util.List;
import java.util.Locale;

import rdd.core.RdData;

public class RdUser
{
	/**
	 * The organization path for the user. The organization path will determine where
	 * to lookup information about the user. The appropriate construction and relevant
	 * portions of this path are ambiguous. Usually it is sufficient to capture just
	 * one element (called the "domain").
	 */
	public String _orgPath;
	
	/**
	 * The name of the user. The name must be globally unique (or conflicts must be
	 * tolerated). This is a highly ambiguous area in most security solutions. There is
	 * a tension between those that want nice short easy to type and remember names
	 * for users appearing in the user interface and those who worry about the uniqueness
	 * of usernames over the potentially long lifetime of an application. In many cases
	 * the user name must incorporate parts of the _orgPath, but which part and how to encode
	 * that construction are still very much in debate. The two most common are:
	 * 
	 * <username>@domain.com (works well if this is a valid email address for the user)
	 * 
	 * or
	 * 
	 * domain/username
	 * 
	 * which is more typical in cross domain trust relationships (such as ADSI).
	 * 
	 * One rule that sometimes works is to show only the "username" portion of the _name
	 * attribute if the current acting user and the user being referenced share the same
	 * domain. Another is to say that one domain is the "home" domain and show the username
	 * without the domain for users in the "home" domain.
	 */
	public String _name;
	
	/**
	 * The current preferred language of the user. This again is an ambiguous attribute
	 * to compute. In some cases, the preferred language may come from an external repository
	 * so that language choice can cross easily from application to application, in other
	 * cases the user must express a preference each time they log in. This attribute
	 * is used with the method RdLocalizedStringUtils.getLocalizedString.
	 * @see RdLocalizedStringUtils.getLocalizedString
	 */
	public int _langIndex;
	
	/**
	 * The preferred locale for the user. This includes preferred timezone, date format, and
	 * currency format.
	 */
	public Locale _locale;
	
	/**
	 * Additional properties about the user including such things as full name, email address,
	 * organizational location in the company, etc.
	 */
	public RdData _properties;
	
	/**
	 * The privileges granted to the user after all group membership and rules are computed
	 * (including nesting of groups).
	 */
	public List<RdPrivilege> _privileges;
	
	@Override
	public String toString()
	{
		return _name;
	}
}
