package rdd.sharedfilestorage;

import rdd.core.RdContext;
import rdd.core.RdEventUtils;
import rdd.core.RdGlobalKeys;
import rdd.core.RdKey;
import rdd.core.RdLoadOrder;
import rdd.core.RdTable;
import rdd.core.storage.RdStorage;

public class RdSharedFileStorageUtils
{
	static public RdKey SHARED_FILES_DIRECTORY_KEY =  RdGlobalKeys.registerGlobalKey(
		"SharedFilesDirectory", RdKey.STRING, 0);

	static public RdTable createEventRegistrationTable(RdContext cxt)
	{
		return new RdTable(
			new RdKey[]{
				RdEventUtils.EVENT_REGISTRATION_ID, 
				RdEventUtils.EVENT_IDS,
				RdEventUtils.EVENT_HANDLER_CLASSS,
				RdLoadOrder.ORDER_KEY},
			new Object[][]{{
			"sharedstorage",
			RdStorage.getEventListAsString(),
			"rdd.sharedfilestorage.RdSharedFileStorage",
			RdLoadOrder.AFTER_STANDARD}});
	}
}
