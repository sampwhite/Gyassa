package rdd.core.io;

import rdd.core.RdContext;
import rdd.core.RdException;

/** Callback interface for appending messages to a text console or log */
public interface RdMessageAppender
{
	/** Flags **/
	static public final int F_APPEND_LF = 1;
	
	public void appendMessage(CharSequence msg, int flags, RdContext cxt) throws RdException;
}
