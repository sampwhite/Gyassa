package rdd.core.storage;

/**
 * Used to track information about media components.
 */
public class RdMediaStorageInfo
{
	public boolean _isDev;
	public boolean _isMedia;
	public String _mediaDir;
	public String _parentToMediaDir;
	public RdConnectionData _connectionData;
	
	public RdMediaStorageInfo()
	{
	}
}
