package rdd.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class RdResourceUtils
{
	/**
	 * Key identifying this as a resource without a specific key to lookup.
	 */
	static public RdKey RESOURCE_KEY = new RdKey("resource_without_key");
	
	/**
	 * Key identifying object that accumulates parsing errors that are not significant
	 * enough to abort the processing of the resources.
	 */
	static public RdKey RESOURCE_FORMAT_STATE_KEY = RdGlobalKeys.registerGlobalKey(
		"ResourceFormatState", RdKey.COMPLEX);
	
	//+section Resource format errors
	static public int RESOURCE_DEFINITION_CHANGED_TYPE = 1;
	static public int RESOURCE_DEFINITION_INCOMPATIBLE_TYPE = 2;
	//+endsection Resource format errors
	
	/**
	 * Text is unidentified and shares the same resource key.
	 */
	static public RdResourceKey TEXT_RESOURCE_KEY = new RdResourceKey(RdResourceTypes.TEXT, "<unknown>");
	
	static public Map<String,RdResourceKey>[] _resourceKeyMap;
	
	static
	{
		_resourceKeyMap = new Map[RdResourceTypes.BEGIN_SECTION];
		for (int i = 0; i < _resourceKeyMap.length; i++)
		{
			_resourceKeyMap[i] = new ConcurrentHashMap<String,RdResourceKey>();
		}
	}

	static public RdResourceKey getOrCreateResourceKey(int resType, String resource)
	{
		if (resType == RdResourceTypes.TEXT)
		{
			return TEXT_RESOURCE_KEY;
		}
		if (resource == null)
		{
			resource = "<unknown>";
		}
		Map<String,RdResourceKey> map = _resourceKeyMap[resType];
		RdResourceKey key = map.get(resource);
		if (key == null)
		{
			synchronized (map)
			{
				key = map.get(resource);
				if (key == null)
				{
					key = new RdResourceKey(resType, resource);
					map.put(resource, key);
				}
			}
		}
		return key;
	}
	
	static public RdResourceFormatState getOrCreateFormatState(RdContext cxt)
	{
		RdResourceFormatState formatState = (RdResourceFormatState)cxt.get(RESOURCE_FORMAT_STATE_KEY);
		if (formatState == null)
		{
			RdContext requestContext = cxt.getRequestContext();
			formatState = new RdResourceFormatState();
			requestContext.put(RESOURCE_FORMAT_STATE_KEY, formatState);
		}
		return formatState;
	}
	
	static public void addFormatErrorToAudit(RdContext cxt, RdResourceFormatError formatErr)
	{
		RdResourceFormatState formatState = getOrCreateFormatState(cxt);
		formatState._formatErrors.add(formatErr);
	}
}
