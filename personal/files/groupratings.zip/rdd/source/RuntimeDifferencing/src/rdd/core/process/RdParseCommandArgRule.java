package rdd.core.process;

public class RdParseCommandArgRule
{
	static final int F_HAS_VALUE = 1;
	static final int F_IS_PATH = 2;
	
	public String _key;
	public String _argPattern;
	public int _flags;
	public String _description;
	
	public RdParseCommandArgRule(String[] ruleDef)
	{
		_argPattern = ruleDef[0];
		_key = ruleDef[1];
		if (ruleDef.length > 2)
		{
			String flagStr = ruleDef[2];
			flagStr = flagStr.toLowerCase();
			if (flagStr.contains("path"))
			{
				_flags |= (F_HAS_VALUE | F_IS_PATH);
			}
			if (flagStr.contains("value"))
			{
				_flags |= F_HAS_VALUE;
			}
		}
		if (ruleDef.length > 3)
		{
			_description = ruleDef[3];
		}
	}
}
