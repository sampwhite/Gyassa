package rdd.core;

import java.io.IOException;
import java.io.Writer;

/**
 * A character array that can be used in many different ways and optimize page building. This class is NOT
 * thread safe.
 */
public class RdCharArray extends Writer implements CharSequence
{
	public char[] _chars;
	public int _len;
	public String _toStringCache;
	
	public RdCharArray()
	{
		// Do nothing. Let attributes initialize themselves.
	}
	
	public RdCharArray(CharSequence str)
	{
		_len = str.length();
		if (str.length() > 0)
		{
			if (str instanceof RdCharArray)
			{
				char[] curArray = ((RdCharArray)str)._chars;
				_chars = new char[_len];
				System.arraycopy(curArray, 0, _chars, 0, _len);
				_toStringCache = ((RdCharArray)str)._toStringCache;
			}
			else if (str instanceof String)
			{
				_chars = ((String)str).toCharArray();
				_toStringCache = (String)str;
			}
			else
			{
				_chars = new char[_len];
				for (int i = 0; i < _len; i++)
				{
					_chars[i] = str.charAt(i);
				}
			}
		}
	}
	
	public RdCharArray(char[] array, int offset, int len)
	{
		if (len > 0)
		{
			_chars = new char[len];
			System.arraycopy(array, offset, _chars, 0, len);
			_len = len;
		}
	}
	
	//+section Interface CharSequence
	@Override
	public int length()
	{
		return _len;
	}

	@Override
	public char charAt(int index)
	{
		if (index >= _len)
		{
			throw new ArrayIndexOutOfBoundsException(index);
		}
		return _chars[index];
	}

	@Override
	public CharSequence subSequence(int start, int end)
	{
		if (start >= end)
		{
			return new RdCharArray();
		}
		RdCharArray subArray = new RdCharArray(_chars, start, end - start);
		
		return subArray;
	}
	//+endsection Interface CharSeqeunce
	
	//+section Extend Writer
	@Override
   public void write(int c) throws IOException
   {
		_toStringCache = null;
		if (_chars == null)
		{
			_chars = new char[10];
			_chars[0] = (char)c;
			_len = 1;
		}
		else
		{
			 if (_len >= _chars.length)
			 {
				 realloc(_len + 1);
			 }
			 _chars[_len++] = (char)c;
		}
	}


	@Override
	public void write(char[] cbuf, int off, int len) throws IOException
	{
		_toStringCache = null;
		if (len <= 0)
		{
			return;
		}
		if (_chars == null)
		{
			_chars = new char[len];
			if (len < 8)
			{
				for (int i = 0; i < len; i++)
				{
					_chars[i] = cbuf[off++];
				}
			}
			else
			{
				System.arraycopy(cbuf, off, _chars, 0, len);
			}
			_len = len;
		}
		else
		{
			if (_len + len > _chars.length)
			{
				realloc(_len + len);
			}
			if (len < 8)
			{
				// Native methods have overhead for the call. Not a good choice
				// for copying over small amounts of data.
				for (int i = 0; i < len; i++)
				{
					_chars[_len++] = cbuf[off++];
				}
			}
			else
			{
				System.arraycopy(cbuf, off, _chars, _len, len);
				_len += len;
			}
		}
		
	}

	@Override
	public void flush() throws IOException
	{
		// Do nothing.
	}

	@Override
	public void close() throws IOException
	{
		// Do nothing.
	}
	//+endsection Extend Writer
	
	//+section Interface Appendable
	@Override
	public Writer append(CharSequence csq) throws IOException
	{
		_toStringCache = null;
		if (csq instanceof RdCharArray)
		{
			RdCharArray dca = (RdCharArray)csq;
			if (dca._len > 0)
			{
				write(dca._chars, 0, dca._len);
			}
		}
		else
		{
			super.append(csq);
		}
		return this;
	}

	@Override
    public Writer append(CharSequence csq, int start, int end) throws IOException
    {
		_toStringCache = null;
		if (csq instanceof RdCharArray)
		{
			RdCharArray dca = (RdCharArray)csq;
			if (end > start)
			{
				write(dca._chars, start, end - start);
			}
		}
		else
		{
			super.append(csq, start, end);
		}
		return this;
    }
	//+endsection Interface Appendable
	

	/**
	 * A fast but not NLS (Native Language Support) compliant lower casing of the array of characters. 
	 * An NLS compliant approach requires additional Oracle libraries and very slow method
	 * calls that look at combinations of characters as well as single characters.
	 */
	public void fastLowerCase()
	{
		boolean changed = false;
		for (int i = 0; i < _len; i++)
		{
			char ch = _chars[i];
			if (ch < 0x80)
			{
				if (ch >= 'A' && ch <= 'Z')
				{
					ch = (char)(ch - 'A' + 'a');
				}
			}
			else
			{
				// Slow method call. If this becomes an issue
				// can create a large array lookup. Note, this
				// approach is completely inappropriate for certain
				// code point ranges in the Unicode spec.
				ch = Character.toLowerCase(ch);
			}
			if (ch != _chars[i])
			{
				_chars[i] = ch;
				changed = true;
			}
		}
		if (changed)
		{
			_toStringCache = null;
		}
	}
	
	/**
	 * Same as fastLowerCase but lower cases the characters being appended instead.
	 */
	public void appendFastLowerCase(CharSequence csq, int start, int end)
	{
		int nChars = end - start;
		if (nChars <= 0)
		{
			return;
		}
		prepareForAppend(nChars);
		
		for (int i = start; i < end; i++)
		{
			char ch = csq.charAt(i);
			if (ch < 0x80)
			{
				if (ch >= 'A' && ch <= 'Z')
				{
					ch = (char)(ch - 'A' + 'a');
				}
			}
			else
			{
				// Slow method call. If this becomes an issue
				// can create a large array lookup.
				ch = Character.toLowerCase(ch);
			}
			_chars[_len++] = ch;
		}
	}
	

	public void realloc(int minalloc)
	{
		if (_len > minalloc)
		{
			minalloc = _len;
		}
		char[] newArray = new char[minalloc * 3 + 10];
		if (_len > 0)
		{
			System.arraycopy(_chars, 0, newArray, 0, _len);
		}
		_chars = newArray;
	}
	
	public void prepareForAppend(int nChars)
	{
		_toStringCache = null;
		if (_chars == null || (nChars + _len > _chars.length))
		{
			realloc(_len + nChars);
		}
	}
	
	/**
	 * Useful during buffer reading and parsing.
	 * @param len Number of characters to shift to the left (those characters are lost).
	 */
	public void leftShift(int len)
	{
		_toStringCache = null;
		if (len < _len)
		{
			System.arraycopy(_chars, len, _chars, 0, _len - len);
			_len -= len;
		}
		else
		{
			_len = 0;
		}
	}
	
	/**
	 * Allows reuse of this object in a loop with _chars already allocated.
	 */
	public void reset()
	{
		_toStringCache = null;
		_len = 0;
	}
	
	@Override
	public String toString()
	{
		if (_len == 0)
		{
			return "";
		}
		if (_toStringCache == null)
		{
			_toStringCache = new String(_chars, 0, _len);
		}
		return _toStringCache;
	}
}
