package rdd.core.substitution;

public class RdSubstitutionError
{
	public String _varName;
	public Throwable _exception;
	public String _pathScript;
	
	public RdSubstitutionError(String varName, Throwable exception)
	{
		_varName = varName;
		_exception = exception;
	}
	
	public RdSubstitutionError(String varName, String pathScript, Throwable exception)
	{
		_varName = varName;
		_exception = exception;
		_pathScript = pathScript;
	}
}
