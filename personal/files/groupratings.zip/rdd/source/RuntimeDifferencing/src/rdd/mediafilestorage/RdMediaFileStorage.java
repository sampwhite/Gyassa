package rdd.mediafilestorage;

import java.util.HashMap;
import java.util.Map;

import rdd.core.RdContext;
import rdd.core.RdEventInterface;
import rdd.core.RdEventParams;
import rdd.core.RdEventRegistration;
import rdd.core.RdException;
import rdd.core.component.RdComponentDefinition;
import rdd.core.io.FilePathUtils;
import rdd.core.io.IoUtils;
import rdd.core.primitives.StrUtils;
import rdd.core.storage.RdConnectionData;
import rdd.core.storage.RdMediaStorageInfo;
import rdd.core.storage.RdStorage;
import rdd.core.storage.RdStorageParameters;

public class RdMediaFileStorage implements RdEventInterface
{
	public boolean _hasMediaStorage;
	public String[] _mediaDirs;
	public boolean _hasDevStorage;
	public String[] _devDirs;
	public Map<String,RdMediaStorageInfo> _mediaComponents;
	
	//+section RdEventInterface
	@Override
	public void init(RdContext cxt) throws RdException
	{
		CharSequence mediaDirs = cxt.getS(RdMediaFileStorageUtils.MEDIA_DIRECTORIES);
		if (mediaDirs.length() > 0)
		{
			_mediaDirs = StrUtils.parseArray(mediaDirs, cxt);
			prepareAbsolutePathDirs(_mediaDirs, cxt);
			_hasMediaStorage = true;
		}
		_hasDevStorage = cxt.getB(RdMediaFileStorageUtils.HAS_DEVELOPER_DIRECTORIES);
		if (_hasDevStorage)
		{
			CharSequence devDirs = cxt.getS(RdMediaFileStorageUtils.DEVELOPER_DIRECTORIES);
			_devDirs = StrUtils.parseArray(devDirs, cxt);
			prepareAbsolutePathDirs(_devDirs, cxt);
		}
		_mediaComponents = new HashMap<String,RdMediaStorageInfo>();
	}

	@Override
	public int handleEvent(RdEventRegistration eventRegistration, RdEventParams params,
		RdContext cxt) throws RdException
	{
		// TODO Auto-generated method stub
		RdStorageParameters storageParams = (RdStorageParameters)params._param;
		
		// We don't audit or cache, so we don't do anything for events that were handled.
		if (params._handledEvent)
		{
			return CONTINUE;
		}
		
		// Use _prepareStorageCall to integrate with RdSharedFileStorage to do actual
		// work of reading and writing files.
		if (params._event == RdStorage._prepareStorageCall)
		{
			if (!storageParams._storageEventPrepared)
			{
				// See if component is controlled by media directories.
				checkIsMediaComponent(storageParams, cxt);
			}
			return CONTINUE;
		}
		
		return CONTINUE;
	}

	@Override
	public void applicationRelease(RdContext cxt)
	{
		// Nothing to do
	}
	//+endsection RdEventInterface
	
	
	public void prepareAbsolutePathDirs(String[] dirs, RdContext cxt)
	{
		for (int i = 0; i < dirs.length; i++)
		{
			dirs[i] = FilePathUtils.normalizeFilePath(dirs[i], cxt, FilePathUtils.F_IS_DIR);
		}
	}
	
	public void checkIsMediaComponent(RdStorageParameters storageParams, RdContext cxt)
	{
		RdComponentDefinition componentDef = storageParams._component;
		boolean isMedia = false;
		boolean isDev = false;
		String mediaDir = null;
		synchronized (_mediaComponents)
		{
			RdMediaStorageInfo mediaInfo = componentDef._mediaInfo;
			if (mediaInfo == null)
			{
				String componentName = componentDef._name;
				mediaInfo =  _mediaComponents.get(componentName);
				if (mediaInfo == null)
				{
					// Need to scan directories to see if it is a developer or media component.
					mediaInfo = new RdMediaStorageInfo();
					if (_hasDevStorage)
					{
						if (scanDirectoriesForComponent(_devDirs, componentDef, mediaInfo))
						{
							mediaInfo._isDev = true;
						}
					}
					if (_hasMediaStorage)
					{
						if (scanDirectoriesForComponent(_mediaDirs, componentDef, mediaInfo))
						{
							mediaInfo._isMedia = true;
						}
					}
					_mediaComponents.put(componentName, mediaInfo);
				}
				if ((mediaInfo._isDev || mediaInfo._isMedia))
				{
					componentDef._mediaInfo = mediaInfo;
					componentDef._flags |= RdComponentDefinition.F_IS_MEDIA;
					componentDef._hasMediaLocation = true;
					componentDef._mediaComponentPath = mediaInfo._mediaDir + componentName;
				}
			}
			
			isMedia = (componentDef._flags & 
				RdComponentDefinition.F_IS_MEDIA) != 0;
			isDev = mediaInfo._isDev;
			storageParams._isReadOnlyData = isMedia && !isDev;
			if (isMedia)
			{
				mediaDir = mediaInfo._mediaDir;
			}
		}
		storageParams._isMediaComponent = isMedia; 
		if (componentDef._hasMediaLocation && isMedia)
		{
			// Override any computations of connection data to use file system.
			String dataConnType = (isDev) ? "developer" : "media";
			storageParams._connectionData = new RdConnectionData(dataConnType, mediaDir);
		}
	}
	
	public boolean scanDirectoriesForComponent(String[] dirs, RdComponentDefinition def, 
		RdMediaStorageInfo info)
	{
		boolean retVal = false;
		for (String dir : dirs)
		{
			String path = dir + def._name + "/" + "filelist.rdd";
			if (IoUtils.fileExists(path))
			{
				// Found it
				info._mediaDir = dir;
				info._connectionData = new RdConnectionData(dir, dir);
				retVal = true;
			}
		}
		return retVal;
	}

}
