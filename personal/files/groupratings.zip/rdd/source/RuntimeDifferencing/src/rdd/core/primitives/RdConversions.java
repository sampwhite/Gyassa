package rdd.core.primitives;

public class RdConversions
{
	/**
	 * Looks for a standard boolean value encoded as as string in one of its many variant potential formats.
	 * This method does NOT treat non zero numerical values as "true". It assumes that the value
	 * is intended a clear indicator of true or false using typical English language choices that
	 * would be put into a configuration file.
	 * 
	 * @param arr The character array to be examined.
	 * @param start Where to start in the array.
	 * @param end Where to end in the array.
	 * @param defVal The default value to return if no clear value can be parsed.
	 * @return Return the parsed boolean value if found, otherwise returns defVal.
	 */
	static public boolean convertToBool(char[] arr, int start, int end, boolean defVal)
	{
		if (start >= end)
		{
			return defVal;
		}
		char ch = arr[start];
		if (ch == '-' || ch == ':' || ch == '(')
		{
			// Skip to next character.
			start++;
			if (start >= end)
			{
				return defVal;
			}
			ch = arr[start];
		}
		if (ch == 't' || ch == 'T' || ch == 'y' || ch == 'Y' || ch == '1')
		{
			return true;
		}
		if (ch == 'f' || ch == 'F' || ch == 'n' || ch == 'N' || ch == '0')
		{
			return false;
		}
		return defVal;
	}
	
	/**
	 * @see convertToBool(char[] arr, int start, int end, boolean defVal)
	 */
	static public boolean convertToBool(String str, boolean defVal)
	{
		if (str == null || str.length() == 0)
		{
			return defVal;
		}
		int start = 0;
		char ch = str.charAt(start);
		if (ch == '-' || ch == ':' || ch == '(')
		{
			// Skip to next character.
			start++;
			if (start >= str.length())
			{
				return defVal;
			}
			ch = str.charAt(start);
		}
		if (ch == 't' || ch == 'T' || ch == 'y' || ch == 'Y' || ch == '1')
		{
			return true;
		}
		if (ch == 'f' || ch == 'F' || ch == 'n' || ch == 'N' || ch == '0')
		{
			return false;
		}
		return defVal;
	}
	
	/**
	 * Convert to integer in very forgiving way
	 */
	static public int convertToInteger(CharSequence str, int start, int end, int defVal)
	{
		boolean isNeg = false;
		if (end <= start)
		{
			return defVal;
		}
		boolean foundDigit = false;
		int val = 0;
		for (int i = start; i < end; i++)
		{
			char ch = str.charAt(i);
			if (ch <= ' ')
			{
				if (!foundDigit)
				{
					continue;
				}
				break;
			}
			if (ch >= '0' && ch <= '9')
			{
				foundDigit = true;
				val = 10 * val  + (ch - '0');
			}
			else
			{
				if (ch == '-' && !foundDigit)
				{
					isNeg = true;
				}
				else
				{
					break;
				}
			}
			
		}
		return (foundDigit) ? ((isNeg) ? -val : val) : defVal;
	}
}
