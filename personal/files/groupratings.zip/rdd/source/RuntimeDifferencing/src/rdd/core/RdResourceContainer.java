package rdd.core;

import rdd.core.merge.RdResourceMergeData;

public class RdResourceContainer
{
	public RdResourceMergeData _mergeData;
}
