package rdd.core;

public class RdCommonKeys
{
	/**
	 * The key that holds the value for the transaction counter. This key is
	 * used aggressively in all data processing when edits are being made. It is
	 * also used during session management (if session management is being used, which 
	 * is not recommended for simple web sites).
	 * 
	 * The important thing about this value is that it increments globally across all
	 * nodes in a cluster so that every transaction performed will get a unique forward
	 * going transaction ID. Its primary use is to allow queries for changes in data
	 * that have happened recently so they can be published to local disk to optimize
	 * performance. It can also be used to differential migration of data from one
	 * server instance to another. Generally, all potentially large editable tables 
	 * (database or otherwise) must incorporate a transaction counter column.
	 */
	static public RdKey TRANSACTION_COUNTER = RdGlobalKeys.registerGlobalKey(
		"rdTransactionCounter", RdKey.INTEGER);
	
	/**
	 * This attribute is similar to the TRANSACTION_COUNTER, except it applies to
	 * a larger set of data that has transaction numbers recorded for smaller edits (usually
	 * in one or more contained tables or edits of any type in referenced data objects).
	 * It is used to allow a consumer to quickly determine if anything has recently
	 * changed in a larger body of data. As an example, a "parent folder" object
	 * would change its TRANSACTION_COUNTER when properties about the folder changed,
	 * but would change its LAST_EDIT_TRANSACTION_COUNTER whenever any children changed.
	 */
	static public RdKey LAST_EDIT_TRANSACTION_COUNTER = RdGlobalKeys.registerGlobalKey(
		"rdLastEditReferenceCounter", RdKey.INTEGER);
	
	/**
	 * The last modified date for an item. This is primarily used just for auditing
	 * and troubleshooting. A typical usage is for an administrator to use date
	 * based queries for recent changes.
	 */
	static public RdKey LAST_MODIFIED = RdGlobalKeys.registerGlobalKey(
		"rdLastModified", RdKey.DATE);
	
	/**
	 * The acting user who did the last modification. This is for auditing and
	 * troubleshooting. It can be used by an administrator to determine who
	 * is responsible for the current state of an item.
	 */
	static public RdKey LAST_MODIFIED_USER = RdGlobalKeys.registerGlobalKey(
		"rdLastModifiedUser", RdKey.STRING);
	
	/**
	 * Marks whether a row in a table is disabled. Disabled rows should be treated as if they
	 * were deleted when it comes to functional aspects of the application. When doing table
	 * overlays, it is sometimes difficult for an overlay to delete an existing row, but it
	 * is fairly straightforward to force a row to become disabled. Disabling rows also creates
	 * more efficient table processing because the disabled rows can be removed at the very end
	 * instead of removing rows as desired. This gives order N instead of order N squared in
	 * some cases where there are 10s of thousands of rows and thousands of disables.
	 */
	static public RdKey IS_DISABLED = RdGlobalKeys.registerGlobalKey("rdIsDisabled", RdKey.BOOLEAN);
	
	/**
	 * Marks whether a row is deleted. This is used when doing differencing calculations to create
	 * a table that when applied to one table as an overlay will reliably product the newer version
	 * of the table. Differencing can accumulate and then be published to allow other consumers
	 * to apply the differencing. This key can be used in other circumstances to indicate that
	 * a data value has been marked as deleted (for example in cache).
	 */
	static public RdKey IS_DELETED = RdGlobalKeys.registerGlobalKey("rdIsDeleted", RdKey.BOOLEAN);


}
