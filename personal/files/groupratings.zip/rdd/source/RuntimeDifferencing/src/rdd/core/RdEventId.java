package rdd.core;

/**
 * This class is the unique global identifier for events that occur in the application.
 * The RDD project is built around the idea of event handling instead of using
 * the more standard approach of classes extending classes and implementing interfaces
 * and then having object managers (example would be the JDBC DriverManager) help choose
 * which object to instantiate.
  */
public class RdEventId
{
	//+section Event flags
	// Event should not be traced in the normal fashion, would create too much noise in output
	// even for debug level output.
	static public final int F_IS_CALLED_FREQUENTLY = 1;
	
	static public final int F_IS_INTERNAL = 2; // Event handling needs to be fast (< .1 millisecond)
	static public final int F_IS_INIT = 4; // Event is part of initialization sequence.
	static public final int F_IS_APP = 8; // Event presumes that application specific code will be called.
	//+endsection Event flags
	
	/**
	 * The name of the event.
	 */
	public String _name;
	
	/**
	 * The category of the event. Used to help in auditing so that logging
	 * can focus on a particular category of events.
	 */
	public String _category;
	
	/**
	 * Flags that control special behaviors for this event.
	 */
	public int _flags;
	
	/**
	 * Category specific flags, custom per event category.
	 */
	public int _categoryFlags;
	
	/**
	 * Optimized array of handlers (computed on demand).
	 */
	public RdEventInterface[] _handlers;
	
	/**
	 * Constructs an RdEvent object.
	 */
	public RdEventId(String name, String category, int flags)
	{
		_name = name;
		_category = category;
		_flags = flags;
	}
}
