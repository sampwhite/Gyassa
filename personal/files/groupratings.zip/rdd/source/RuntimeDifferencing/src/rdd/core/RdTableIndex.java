package rdd.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import rdd.core.primitives.StrUtils;

public class RdTableIndex
{
	//+section Index flags
	static public int F_IS_PRIMARY_KEY = 1;
	static public int F_CASE_INSENSITIVE = 2;
	static public int F_INDEX_IS_VALID = 64;
	//+endsection Index flags
	
	//+section Compute key flags
	static public int F_USE_FASTKEY_LOOKUP = 1;
	//+endsection Compute key flags
	
	public RdTableField[] _fieldsInIndex;
	public RdTable _table;
	public Map<String,RdTable> _rowIndex;
	public int _flags;
	public Map<Object,String> _fastKeyLookup;
	
	public RdTableIndex(RdTableField[] fieldsInIndex, RdTable table, int flags)
	{
		_fieldsInIndex = fieldsInIndex;
		_table = table;
		_flags = flags;
	}
	
	public void buildIndex(RdContext cxt)
	{
		List<List<Object>> rows = _table._rows;
		boolean isLowerCase = ((_flags & F_CASE_INSENSITIVE) != 0);
		boolean isSimpleIndex = (_fieldsInIndex.length == 1 && 
			((_flags & F_CASE_INSENSITIVE) == 0));
		int simpleIndex = -1;
		RdCharArray array = null;
		if (_rowIndex == null)
		{
			_rowIndex= new HashMap<String,RdTable>();
		}
		else
		{
			_rowIndex.clear();
		}
		
		if (isSimpleIndex)
		{
			simpleIndex = _fieldsInIndex[0]._index;
		}
		else
		{
			array = new RdCharArray();
			_fastKeyLookup = new HashMap<Object,String>();
		}
		for (List<Object> row : rows)
		{
			String key = null;
			if (_fastKeyLookup != null)
			{
				// This will be faster then computing the key and then having to produce
				// the hashcode for the key when it is used to do an index lookup.
				key = _fastKeyLookup.get(row);
			}
			if (key == null)
			{
				key = getKeyImplement(row, array, isLowerCase, isSimpleIndex, simpleIndex, cxt);
				if (_fastKeyLookup != null)
				{
					_fastKeyLookup.put(row, key);
				}
			}
			RdTable indexTable = _rowIndex.get(key);
			if (indexTable == null)
			{
				indexTable = _table.shallowDesignClone();
				_rowIndex.put(key, indexTable);
			}
			indexTable.addRow(row);
		}
		markValid();
	}
	
	public String getKey(List<Object> row, RdContext cxt, int computeFlags)
	{
		boolean isLowerCase = ((_flags & F_CASE_INSENSITIVE) != 0);
		boolean isSimpleIndex = (_fieldsInIndex.length == 1 && 
			((_flags & F_CASE_INSENSITIVE) == 0));
		boolean useFastKeyLookup = (computeFlags & F_USE_FASTKEY_LOOKUP) != 0;
		int simpleIndex = -1;
		if (useFastKeyLookup && _fastKeyLookup != null)
		{
			// This will be faster then computing the key and then having to produce
			// the hashcode for the key when it is used to do an index lookup.
			String key = _fastKeyLookup.get(row);
			if (key != null)
			{
				return key;
			}
		}
		RdCharArray array = null;
		if (isSimpleIndex)
		{
			simpleIndex = _fieldsInIndex[0]._index;
		}
		else
		{
			if (cxt == null)
			{
				cxt = RdAppRegistry.getThreadWrapperContext();
			}
			array = cxt.temporaryAllocateCharArray();
		}
		String retKey = getKeyImplement(row, array, isLowerCase, isSimpleIndex, simpleIndex, cxt);
		if (array != null)
		{
			cxt.releaseTemporaryAllocatedCharArray(array);
			if (useFastKeyLookup && _fastKeyLookup != null)
			{
				_fastKeyLookup.put(row, retKey);
			}
		}
		return retKey;
	}
	
	public String getKeyImplement(List<Object> row, RdCharArray array, boolean isLowerCase, 
		boolean isSimpleIndex, int simpleIndex, RdContext cxt)
	{
		String key = "";
		if (isSimpleIndex)
		{
			Object val = row.get(simpleIndex);
			if (!(val instanceof CharSequence))
			{
				val =  RdDataUtils.coerceToString(val, _fieldsInIndex[0]._key, cxt, 0);
			}
			if (val != null)
			{
				key = val.toString();
			}
		}
		else
		{
			array.reset();
			for (int i = 0; i < _fieldsInIndex.length; i++)
			{
				try
				{
					RdTableField field = _fieldsInIndex[i];
					if (i > 0)
					{
						// Append illegal Unicode character.
						array.append((char)1);
					}
					Object val = row.get(field._index);
					RdDataUtils.appendTo(array, val, field._key, 0, cxt, 0);
				}
				catch (Throwable t)
				{
					// Ignore completely
				}
			}
			key = array.toString();
			if (isLowerCase)
			{
				// This could be a potential performance bottleneck. Not only
				// is this method fairly slow, the Java APIs force us back
				// into using strings instead of char arrays. This is why
				// getKeyImplement returns a string and not a char array.
				key = StrUtils.convertToGlobalLowerCase(key, cxt);
			}
		}
		return key;
	}
	
	public RdTable getIndexedTable(String key)
	{
		return _rowIndex.get(key);
	}
	
	public boolean isIndexValid()
	{
		return (_flags & F_INDEX_IS_VALID) != 0;
	}
	
	public boolean isCaseInsensitive()
	{
		return (_flags & F_CASE_INSENSITIVE) != 0;
	}
	
	public void markInvalid()
	{
		_flags &= ~F_INDEX_IS_VALID;
	}
	
	public void markValid()
	{
		_flags |= F_INDEX_IS_VALID;
	}
}
