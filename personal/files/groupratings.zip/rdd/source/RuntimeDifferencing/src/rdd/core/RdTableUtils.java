package rdd.core;

import java.util.ArrayList;
import java.util.List;

import rdd.core.primitives.ArrayUtils;
import rdd.core.primitives.StrUtils;

public class RdTableUtils
{
	//+section Merge flags
	static public int F_MERGE_BLANKS = 1;
	static public int F_REPLACE_ONLY = 2;
	static public int F_MAINTAIN_MERGE_COUNTERS = 4;
	//+endsection
	
	static public boolean _maintainMergeCounters = false;
	
	static public RdKey TABLE_COUNTER_KEY = RdGlobalKeys.registerGlobalKey(
		"rdRowCounter", RdKey.INTEGER, RdKey.F_IS_NOT_SERIALIZABLE);
	static public RdKey TABLE_COMPUTED_PK_KEY = RdGlobalKeys.registerGlobalKey("rdComputedPk",
		RdKey.STRING, RdKey.F_IS_NOT_SERIALIZABLE);
	
	/**
	 * Fast way to create a table from some string arrays.
	 * @param cols Columns of table
	 * @param rows Rows of table
	 * @param cxt The current context
	 * @return The table created
	 */
	static public RdTable createTable(String[] cols, Object[][] rows, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdKey[] keys = new RdKey[cols.length];
		for (int i = 0; i < cols.length; i++)
		{
			keys[i] = RdContextUtils.getKeyForString(cols[i], cxt);
		}
		return new RdTable(keys, rows);
	}
	
	/**
	 * Checks to see if a row is disabled. Marking a row disabled is preferable to
	 * actually deleting it in many cases.
	 * @param table Table on its current row that needs to be tested.
	 * @param cxt The current context.
	 * @return Returns true if the current row in the table is disabled.
	 */
	static public boolean isRowDisabled(RdTable table, RdContext cxt)
	{
		return RdDataUtils.getBoolean(table, RdCommonKeys.IS_DISABLED, false, cxt);
	}
	
	/**
	 * Marks the current row as disabled (essentially deleting it).
	 * @param table The table on its current row.
	 * @param cxt The current context.
	 */
	static public void setRowDisabled(RdTable table, RdContext cxt)
	{
		table.put(RdCommonKeys.IS_DISABLED, Boolean.TRUE);
	}
	
	static public void createTrackingCountersForMergeUsingIndex(RdTable table, RdContext cxt)
	{
		table.addField(TABLE_COUNTER_KEY);
		RdTableField counterField = table._keysToFieldsMap.get(TABLE_COUNTER_KEY);
		counterField._flags |= RdTableField.F_SUPPLEMENTARY_DATA;
		int fieldIndex = counterField._index;
		int counter = 0;
		for (List<Object> row : table._rows)
		{
			ArrayUtils.setAllowGrowth(row, fieldIndex, new Integer(counter));
			counter++;
		}
		table.markHasRowTrackingCounters();
	}
	
	static public void createSimpleFieldIndex(RdTable table, RdKey key, RdContext cxt, int flags)
	{
		RdTableField tableField = table._keysToFieldsMap.get(key);
		if (tableField == null)
		{
			table.addField(key);
			tableField = table._keysToFieldsMap.get(key);
		}
		int index = tableField._index;
		RdTableIndex tableIndex = new RdTableIndex(new RdTableField[]{tableField}, table, flags);
		tableIndex.buildIndex(cxt);
		if ((flags & RdTableIndex.F_IS_PRIMARY_KEY) != 0)
		{
			table._primaryKeyIndex = index;
		}
		table._simpleFieldIndexes = ArrayUtils.setAllowGrowthArray(table._simpleFieldIndexes, 
			index, tableIndex);
	}
	
	/**
	 * Gets the current primary key for the table. This method will throw an array out bounds
	 * exception if the table has no columns or has an improperly defined primary key.
	 * @param table The table whose primary key is to be returned.
	 * @return The column that is the current primary key.
	 */
	static public RdKey getPrimaryKey(RdTable table)
	{
		int primaryKeyIndex = (table._primaryKeyIndex >= 0) ? table._primaryKeyIndex : 0;
		return table.getTableFieldKey(primaryKeyIndex);
	}

	/**
	 * Merges two tables that share the same primary key column. Typically this happens during
	 * overlays and table edits.
	 * @param curTable The current table that receives the rows from the new table.
	 * @param newTable The new table whose rows will be merged in using the primary key.
	 * @param flags Flags that control how the merge is done.
	 * @param cxt The current context.
	 * @throws RdException
	 */
	static public void mergeTablesByPrimaryKey(RdTable curTable, RdTable newTable, 
		int flags, RdContext cxt) throws RdException
	{
		// Validate they have compatible primary keys.
		RdKey curTablePrimaryKey = RdTableUtils.getPrimaryKey(curTable);
		RdKey newTablePrimaryKey = RdTableUtils.getPrimaryKey(newTable);
		
		if (curTablePrimaryKey != newTablePrimaryKey)
		{
			throw new RdException("rdceIncompatiblePrimaryKeys", 
				curTablePrimaryKey, newTablePrimaryKey);
		}
		mergeTablesOnKey(curTablePrimaryKey, curTable, newTable, flags, cxt);
	}

	/**
	 * Merges two tables based on a shared column. The two tables do not (and generally don't)
	 * have to have compatible designs.
	 * @param key The key to merge on.
	 * @param baseTable The base table that will have new rows merged in.
	 * @param newRows The new rows to merge in.
	 * @param flags The flags that control how the merge should be done.
	 * @param cxt
	 * @throws RdException
	 */
	static public void mergeTablesOnKey(RdKey key, RdTable baseTable, RdTable newRows, int flags,
		RdContext cxt) throws RdException
	{
		// First check that both tables have the key that they are merging on.
		int existingIndex = baseTable.getTableFieldIndex(key);
		if (existingIndex < 0)
		{
			throw new RdException("rdceBaseTableDoesNotHaveKey", key);
		}
		int newRowsIndex = newRows.getTableFieldIndex(key);
		if (newRowsIndex < 0)
		{
			throw new RdException("rdceNewRowsForMergeDoesNotHaveKey", key);
		}
		
		RdTable newRowsMergeable = createCompatibleTable(baseTable, newRows, cxt);
		
		mergeCompatibleTablesOnKey(key, baseTable, newRowsMergeable, flags, cxt);
	}
	
	/**
	 * This method creates a new version of the parameter 'newTable' that is compatible with
	 * the baseTable. It will also add any missing columns to baseTable that are present
	 * in newTable.
	 * @param baseTable The baseTable whose design the returned compatible table will share. This
	 * baseTable may have additional columns added to it by this method call.
	 * @param newTable The newTable that needs to be altered into a compatible table.
	 * @param cxt The current request context.
	 * @return A new version of 'newTable' that is merge compatible with 'baseTable'.
	 */
	static public RdTable createCompatibleTable(RdTable baseTable, RdTable newTable, RdContext cxt)
	{
		// Merge new field columns from newRows into baseTable.
		baseTable.addTableFields(newTable._fields);
		
		// Create a map from base table to new rows.
		int rowMap[] = new int[newTable.size()];
		for (int i = 0; i < rowMap.length; i++)
		{
			RdKey newRowsKey = newTable.getTableFieldKey(i);
			int baseTableIndex = baseTable.getTableFieldIndex(newRowsKey);
			rowMap[i] = baseTableIndex;
		}
		
		// Create a new table that is better for merging with baseTable.
		RdTable compatibleTable = baseTable.shallowDesignClone();
		for (List row : newTable._rows)
		{
			int lastNotNullIndex = -1;
			Object[] compatibleRawRow = new Object[rowMap.length];
			for (int i = 0; i < row.size(); i++)
			{
				Object val = row.get(i);
				if (val != null)
				{
					int baseMapIndex = rowMap[i];
					if (baseMapIndex > lastNotNullIndex)
					{
						lastNotNullIndex = baseMapIndex;
					}
					
					// Column may be mentioned more than once in newRows, if so the first
					// mention is the one to use.
					if (compatibleRawRow[baseMapIndex] == null)
					{
						compatibleRawRow[baseMapIndex] = val;
					}
				}
			}
			List compatibleRow = new ArrayList(lastNotNullIndex + 1);
			for (int i = 0; i <= lastNotNullIndex; i++)
			{
				Object val = compatibleRawRow[i];
				compatibleRow.add(val);
			}
			compatibleTable.addRow(compatibleRow);
		}
		return compatibleTable;
	}
	
	/**
	 * Does a merge based on a single field with the same name from each table. The
	 * tables are assumed to have identical designs (in fact, they should be sharing
	 * the actual design attributes). The merge is case sensitive by default.
	 * If a case insensitive merge is desired, then an index on the appropriate
	 * key should be built and the index should be made case insensitive. This
	 * should be done before making this method call.
	 * @param key The key to merge on.
	 * @param existingTable The target of the merge.
	 * @param newRows The new rows to merge in.
	 * @param flags Flags that control how fields from one row are replaced into an existing row.
	 * @param cxt The current context.
	 */
	static public void mergeCompatibleTablesOnKey(RdKey key, RdTable existingTable, 
		RdTable newRows, int flags, RdContext cxt)
	{
		// The big question is whether we should use an index.
		boolean doAppend = false;
		boolean replaceOnly = (flags & F_REPLACE_ONLY) != 0;
		if (key == null || key._type == RdKey.NULL)
		{
			doAppend = true;
		}
		int index = -1;
		int existingNumRows = existingTable.getNumRows();
		int newRowsNumRows = newRows.getNumRows();
		if (!doAppend)
		{
			index = existingTable.getTableFieldIndex(key);
		}
		if (index < 0)
		{
			doAppend = true;
		}
		if (doAppend)
		{
			if (!replaceOnly)
			{
				existingTable._rows.addAll(newRows._rows);
				invalidateTableIndexes(existingTable);
			}
		}
		else
		{
			RdTableIndex fieldIndex = existingTable._simpleFieldIndexes[index];
			if (fieldIndex == null)
			{
				// See if we should create an index.
				if (existingTable.getNumRows() + newRows.getNumRows() > 15)
				{
					// If caller wants special rules for the index, they
					// need to create it themselves.
					createSimpleFieldIndex(existingTable, key, cxt, 0);
					fieldIndex = existingTable._simpleFieldIndexes[index];
				}
			}
			if (fieldIndex == null)
			{
				// Brute force N squared performance time merge.
				for (int i = 0; i < newRowsNumRows; i++)
				{
					newRows.setCurrentRowIndex(i);
					List<Object> newRow = newRows.getCurrentRow();
				
					// Refresh, may have changed.
					existingNumRows = existingTable.getNumRows();
					
					boolean foundIt = false;
					for (int j = 0; j < existingNumRows; j++)
					{
						newRows.setCurrentRowIndex(j);
						CharSequence existingVal = RdDataUtils.getString(existingTable, key, cxt);
						CharSequence newVal = RdDataUtils.getString(newRows, key, cxt);
						if (StrUtils.isMatchingStrings(existingVal, newVal))
						{
							List<Object> existingRow = existingTable.getCurrentRow();
							mergeCompatibleRows(existingRow, newRow, -1, flags);
							foundIt = true;
						}
					}
					if (!foundIt && !replaceOnly)
					{
						newRow = RdDataUtils.cloneList(newRow);
						existingTable._rows.add(newRow);
					}
				}
			}
			else
			{
				mergeCompatibleTablesUsingIndex(fieldIndex, cxt, newRows, flags);
			}
		}
	}
	
	static public void mergeCompatibleTablesUsingIndex(RdTableIndex index, RdContext cxt,
		RdTable newRows, int flags)
	{
		if (!index.isIndexValid())
		{
			index.buildIndex(cxt);
		}
		RdTable table = index._table;
		boolean maintainMergeCounters = _maintainMergeCounters || 
			 (flags & F_MAINTAIN_MERGE_COUNTERS) != 0;
		if (maintainMergeCounters && !table.hasCorrectRowTrackingCounters())
		{
			createTrackingCountersForMergeUsingIndex(table, cxt);
		}
		int rowCountIndex = -1;
		if (maintainMergeCounters)
		{
			RdTableField rowCountField = table._keysToFieldsMap.get(TABLE_COUNTER_KEY);
			rowCountIndex = rowCountField._index;
		}
		boolean replaceOnly = (flags & F_REPLACE_ONLY) != 0;
		
		for (List<Object> row : newRows._rows)
		{
			String key = index.getKey(row, cxt, 0);
			RdTable indexedRows = index.getIndexedTable(key);
			if (indexedRows == null)
			{
				if (!replaceOnly)
				{
					indexedRows = table.shallowDesignClone();
					index._rowIndex.put(key, indexedRows);
					
					if (maintainMergeCounters)
					{
						int nrows = table._rows.size();
						ArrayUtils.setAllowGrowth(row, rowCountIndex, new Integer(nrows));
					}
					row = RdDataUtils.cloneList(row);
					table.addRow(row);
					indexedRows.addRow(row);
				}
			}
			else
			{
				// Replace all the rows with compatible row data (1 -> n merge).
				for (List<Object> existingRow : indexedRows._rows)
				{
					mergeCompatibleRows(existingRow, row, rowCountIndex, flags);
				}
			}
		}
		
		// All other indexes are now suspect.
		invalidateTableIndexes(table);
		
		// The index we merged on is OK.
		index.markValid();
	}
	
	static public void mergeCompatibleRows(List<Object> existing, List<Object> newRow, 
		int skipIndex, int flags)
	{
		boolean mergeBlanks = (flags & F_MERGE_BLANKS) != 0;
		int existingSize = existing.size();
		for (int i = 0; i < newRow.size(); i++)
		{
			if (i == skipIndex)
			{
				continue;
			}
			Object val = newRow.get(i);
			Object testVal = val;
			if (testVal == null)
			{
				continue;
			}
			if (testVal instanceof RdValue)
			{
				RdValue rdVal = (RdValue)testVal;
				if (rdVal.isNull())
				{
					continue;
				}
				if (rdVal._type == RdKey.STRING)
				{
					testVal = rdVal._sVal;
				}
			}
			if (!mergeBlanks && testVal instanceof CharSequence && 
				((CharSequence)testVal).length() == 0)
			{
				continue;
			}
			if (i >= existingSize)
			{
				for (int j = existingSize; j < i; j++)
				{
					existing.add(null);
				}
				existing.add(val);
			}
			else
			{
				existing.set(i, val);
			}
		}
	}
	
	/**
	 * This method edits a table by enumerating through the entries in the 'values' parameter
	 * and looking for rows whose value in the 'key' column match the entry in the 'values' parameter
	 * and removing them.
	 * @param table Table which will have rows removed from it.
	 * @param key The column in the table to test against for removal.
	 * @param values The values to match against the column in the 'table'.
	 * @param cxt The current context.
	 */
	static public void removeRowsMatchingValues(RdTable table, RdKey key, List values, RdContext cxt)
	{
		int index = table.getTableFieldIndex(key);
		if (index < 0)
		{
			return;
		}
		
		RdTableIndex fieldIndex = table._simpleFieldIndexes[index];
		if (fieldIndex == null)
		{
			// See if we should create an index.
			if (table.getNumRows() + values.size() > 15)
			{
				// If caller wants special rules for the index, they
				// need to create it themselves.
				createSimpleFieldIndex(table, key, cxt, 0);
				fieldIndex = table._simpleFieldIndexes[index];
			}
		}
		/* TODO SPW
		if (fieldIndex == null)
		{
			// Brute force N squared performance time merge.
			for (int i = 0; i < newRowsNumRows; i++)
			{
				newRows.setCurrentRowIndex(i);
				List<Object> newRow = newRows.getCurrentRow();
			
				// Refresh, may have changed.
				existingNumRows = existingTable.getNumRows();
				
				boolean foundIt = false;
				for (int j = 0; j < existingNumRows; j++)
				{
					newRows.setCurrentRowIndex(j);
					CharSequence existingVal = RdDataUtils.getString(existingTable, key, cxt);
					CharSequence newVal = RdDataUtils.getString(newRows, key, cxt);
					if (StrUtils.isMatchingStrings(existingVal, newVal))
					{
						List<Object> existingRow = existingTable.getCurrentRow();
						mergeCompatibleRows(existingRow, newRow, -1, flags);
						foundIt = true;
					}
				}
				if (!foundIt && !replaceOnly)
				{
					newRow = RdDataUtils.cloneList(newRow);
					existingTable._rows.add(newRow);
				}
			}
		}
		else
		{
			mergeCompatibleTablesUsingIndex(fieldIndex, cxt, newRows, flags);
		}
		*/
		
	}
	
	static public void invalidateTableIndexes(RdTable table)
	{
		if (table._simpleFieldIndexes != null)
		{
			for (RdTableIndex index : table._simpleFieldIndexes)
			{
				if (index != null)
				{
					index.markInvalid();
				}
			}
		}
		if (table._multiColumnIndexes != null)
		{
			for (RdTableIndex index : table._multiColumnIndexes)
			{
				if (index != null)
				{
					index.markInvalid();
				}
			}
		}
	}
	
	/**
	 * Finds the "sub table" filtered out by rows that match the indexLookupVal 
	 * on the field "key" using the index created on that field.
	 * @param table The table to search.
	 * @param key The field being searched.
	 * @param indexLookupVal The value to match against for the field.
	 * @param flags Future parameter to optimize performance when
	 * some operations can be skipped.
	 * @param cxt The current context.
	 * @return A sub table containing rows that matched the passed in value
	 * for the field.
	 */
	static public RdTable getSimpleIndexedTableByKey(RdTable table, RdKey key, 
		String indexLookupVal, int flags, RdContext cxt)
	{
		int index = table.getTableFieldIndex(key);
		if (index < 0)
		{
			return null;
		}
		RdTableIndex fieldIndex = table._simpleFieldIndexes[index];
		if ((fieldIndex._flags & RdTableIndex.F_CASE_INSENSITIVE) != 0)
		{
			indexLookupVal = StrUtils.convertToGlobalLowerCase(indexLookupVal, cxt);
		}
		RdTable retVal = fieldIndex.getIndexedTable(indexLookupVal);
		if (retVal != null && (table._flags & RdDataFlags.F_SHARED_COPY) != 0)
		{
			// Make sure we have independent iterators.
			retVal = retVal.shallowClone();
		}
		
		return retVal;
	}
}
