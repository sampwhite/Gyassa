package rdd.core.storage;

public class RdChangedStorageItem
{
	//+section Flags
	static public final int F_IS_DIR = 1;
	//+endsection Flags
	
	public String _component;
	public String _path;
	public long _transactionCounter;
}
