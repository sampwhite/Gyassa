package rdd.core.logger;

import java.io.IOException;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.primitives.DateUtils;

public class RP
{
	static public final int ALERT = 1;
	static public final int FATAL = 2;
	static public final int ERROR = 3;
	static public final int WARNING = 4;
	static public final int INFO = 5;
	static public final int TRACE = 6;
	static public final int DEBUG = 7;
	static public final int DUMP = 8;
	
	/**
	 * If set to false, then DEBUG and DUMP messages are ignored and this variable can be tested
	 * to see if the messages should even be created.
	 */
	static public boolean _isVerbose;
	
	/**
	 * Messages with levels higher than this variable will be ignored. This variable is
	 * a companion to _isVerbose.
	 */
	static public int _maxAcceptedMessages = TRACE;
	
	//+section Utility methods for writing to log output
	static public void debug(String section, CharSequence msg, RdContext cxt)
	{
		reportMessage(section, DEBUG, msg, null, cxt);
	}

	static public void traceException(String section, Throwable t, RdContext cxt)
	{
		reportMessage(section, TRACE, null, t, cxt);
	}
	
	static public void trace(String section, CharSequence msg, RdContext cxt)
	{
		reportMessage(section, TRACE, msg, null, cxt);
	}

	static public void trace(String section, CharSequence msg, Throwable t, RdContext cxt)
	{
		reportMessage(section, TRACE, msg, t, cxt);
	}

	static public void warning(String section, CharSequence msg, RdContext cxt)
	{
		reportMessage(section, WARNING, msg, null, cxt);
	}
	
	static public void error(String section, CharSequence msg, Throwable t, RdContext cxt)
	{
		reportMessage(section, ERROR, msg, t, cxt);
	}
	
	static public void reportMessage(String section, int level, CharSequence msg, Throwable t, RdContext cxt)
	{
		if (level > _maxAcceptedMessages)
		{
			return;
		}
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray reportArr = cxt.temporaryAllocateCharArray();
		if (section == null)
		{
			section = "%internal%";
		}
		
		try
		{
			appendStartMessage(section, level, reportArr, cxt);
			reportArr.append("<");
			if (msg != null)
			{
				LogIoUtils.encodeAndAppendLogOutput(reportArr, msg, 0, msg.length());
			}
			else if (t != null)
			{
				String tMsg = t.toString();
				LogIoUtils.encodeAndAppendLogOutput(reportArr, tMsg, 0, tMsg.length());
			}
			reportArr.append(">");
			if (t != null)
			{
				reportArr.append("<");
				RdCharArray stackDumpArr = cxt.temporaryAllocateCharArray();
				if (msg != null)
				{
					String tMsg = t.toString();
					stackDumpArr.append(tMsg, 0, tMsg.length());
					stackDumpArr.append("\n");
				}
				LogIoUtils.appendStackTrace(stackDumpArr, t);
				LogIoUtils.encodeAndAppendLogOutput(reportArr, stackDumpArr, 0, stackDumpArr.length());
				cxt.releaseTemporaryAllocatedCharArray(stackDumpArr);
				reportArr.append(">\n");
			}
			else
			{
				reportArr.append("<>\n");
			}
			LogStreams._lOut.append(reportArr);
			LogStreams._lOut.flush();
		}
		catch (Throwable badErr)
		{
			badErr.printStackTrace(System.err);
		}
		cxt.releaseTemporaryAllocatedCharArray(reportArr);
	}
	
	static public void reportBinary(String section, int level, byte[] buf, int start, int len, RdContext cxt)
	{
		if (cxt == null)
		{
			cxt = RdAppRegistry.getThreadWrapperContext();
		}
		RdCharArray reportArr = cxt.temporaryAllocateCharArray();
		if (section == null)
		{
			section = "%internal%";
		}
		try
		{
			appendStartMessage(section, level, reportArr, cxt);
			reportArr.append("<\n");
			LogStreams._lOut.append(reportArr);
			dumpRawBinary(buf, start, len);
			LogStreams._lOut.append("><>\n");
		}
		catch (Throwable badErr)
		{
			badErr.printStackTrace(System.err);
		}
		
	}
	
	/**
	 * Used when the normal reporting approach is suspect or the error is unexpected enough that it needs special highlighting.
	 * An example would be an IOException thrown when reading from a char array reader.
	 */
	static public void errT(Throwable t)
	{
		RdContext cxt = RdAppRegistry.getThreadWrapperContext();		
		RdCharArray reportArr = cxt.temporaryAllocateCharArray();
		try
		{
			reportArr.append("<!InternalErrorStackDump at ");
			DateUtils.appendInternalDateFormat(cxt, null, reportArr);
			reportArr.append(" on thread ");
			String threadName = Thread.currentThread().getName();
			reportArr.append(threadName);
			reportArr.append(":");
			
			RdCharArray stackDumpArr = cxt.temporaryAllocateCharArray();
			String tMsg = t.toString();
			stackDumpArr.append(tMsg, 0, tMsg.length());
			stackDumpArr.append("\n");
			LogIoUtils.appendStackTrace(stackDumpArr, t);
			LogIoUtils.encodeAndAppendLogOutput(reportArr, stackDumpArr, 0, stackDumpArr.length());
			cxt.releaseTemporaryAllocatedCharArray(stackDumpArr);
			reportArr.append(">\n");
			LogStreams._lErr.append(reportArr);
			LogStreams._lErr.flush();
		}
		catch (Exception ignore)
		{
			ignore.printStackTrace(System.err);
		}
		cxt.releaseTemporaryAllocatedCharArray(reportArr);
	}
	//+endsection Utility methods for writing to log output
	
	//+section Internal methods that help build up a log message
	/**
	 * Method to create the starting part of a log message.
	 * @param section The section being reported against.
	 * @param level The level of the error.
	 * @param reportArr The appendable that gets the result.
	 * @param cxt The context.
	 * @throws IOException
	 */
	static public void appendStartMessage(String section, int level, Appendable reportArr, RdContext cxt) throws IOException
	{
		reportArr.append("<");
		reportArr.append(section);
		reportArr.append("/" + level);
		reportArr.append("><");
		DateUtils.appendInternalDateFormat(cxt, null, reportArr);
		reportArr.append("><");
		String threadName = Thread.currentThread().getName();
		reportArr.append(threadName);
		reportArr.append(">");
	}
	
	static public void dumpRawBinary(byte buf[], int start, int len)
	{
		try
		{
			LogStreams._lOut.append("---Start Raw Binary---\n");
			LogStreams._lOut.write(buf, start, len);
			LogStreams._lOut.append("\n---End Raw Binary---\n");
			LogStreams._lOut.flush();
		}
		catch (Exception ignore)
		{
			ignore.printStackTrace(System.err);
		}
	}
	//+endsection Internal methods that help build up a log message
}
