package rdd.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import rdd.core.primitives.StrUtils;

public class RdEventUtils
{
	static public Map<String,RdEventId> _eventKeyMap =  new ConcurrentHashMap<String,RdEventId>();
	static public RdKey RD_EVENT_HANDLERS_KEY = RdGlobalKeys.registerGlobalKey("RdEventHandlers",
		RdKey.COMPLEX, RdKey.F_IS_NOT_SERIALIZABLE);
	
	/**
	 * The identifier for a specific registration of a particular event handler for a particular
	 * event ID. The ID is used to refer precisely to a particular handler of a particular
	 * event and is used when doing differential updates.
	 */
	static public RdKey EVENT_REGISTRATION_ID = 
		RdGlobalKeys.registerGlobalKey("rdEventRegId", RdKey.STRING);
	
	/**
	 * The name of the event. That name will be converted into an RdEventID object.
	 */
	static public RdKey EVENT_ID_TEMP_UNDO = RdGlobalKeys.registerGlobalKey("rdEventID", RdKey.STRING);
	
	static public RdKey EVENT_IDS = RdGlobalKeys.registerGlobalKey("rdEventIDs", RdKey.COLLECTION);
	
	/**
	 * The Java class that when instantiated using a "Class.forName(...)" construction will
	 * result in a Java class that implements the interface 
	 */
	static public RdKey EVENT_HANDLER_CLASSS = RdGlobalKeys.registerGlobalKey("rdEventHandlerClass",
		RdKey.STRING);
	
	/**
	 * A convenience parameter to allow generic handlers of events to discriminate behavior.
	 * For example, a handler that executes a Velocity script might have the name of the script
	 * as a parameter. A more complex usage might have the parameter be a look up key into
	 * a table that holds many parameters to the event registration.
	 */
	static public RdKey EVENT_REGISTRATION_PARAMETER = 
		RdGlobalKeys.registerGlobalKey("rdEventRegParam", RdKey.STRING);
	
	/**
	 * Flags that indicate how the event registration should be processed and what expectations there
	 * are for the way the event is handled.
	 */
	static public RdKey EVENT_REGISTRATION_FLAGS =
		RdGlobalKeys.registerGlobalKey("rdEventRegFlags", RdKey.INTEGER);
	

	static public int FAST_EVENT_HANDLERS_LOOKUP_INDEX = -1;
	
	static public void init(RdContext cxt)
	{
		FAST_EVENT_HANDLERS_LOOKUP_INDEX = 
			RdContextUtils.getOrRegisterFastContextLookupIndex(RD_EVENT_HANDLERS_KEY);
		RdContextUtils.setSharedCachedObject(RD_EVENT_HANDLERS_KEY, cxt, "eventhandlers", 
			new RdEventHandlers(), null);
	}

	static public RdEventId registerOrCreateEventId(String eventId, 
		String category, int flags)
	{
		RdEventId event;
		
		synchronized (_eventKeyMap)
		{
			event = _eventKeyMap.get(eventId);
			if (event == null)
			{
				event = new RdEventId(eventId, category, flags);
				_eventKeyMap.put(eventId, event);
			}
			else
			{
				if (category != null && category.length() > 0)
				{
					event._category = category;
				}
				if (flags != 0)
				{
					event._flags = flags;
				}
			}
		}
		return event;
	}
	
	static public RdEventId getEventId(String eventKey)
	{
		return _eventKeyMap.get(eventKey);
	}
	
	/**
	 * Uses fast lookup mechanics to get the RdEventHandlers objects for this application.
	 * @param cxt The current context.
	 * @return The string data for this application.
	 */
	static public RdEventHandlers getEventHandlers(RdContext cxt)
	{
		return (RdEventHandlers)RdContextUtils.getFastCachedObject(FAST_EVENT_HANDLERS_LOOKUP_INDEX, 
			cxt);
	}
	
	static public Object callEvent(RdEventId event, Object param, int flags, RdContext cxt)
		throws RdException
	{
		RdEventParams eventParams = new RdEventParams(param, flags);
		callEvent(event, eventParams, cxt);
		return eventParams._retVal;
	}
	
	static public boolean callEvent(RdEventId event, RdEventParams params, RdContext cxt)
		throws RdException
	{
		RdEventHandlers eventHandlers = getEventHandlers(cxt);
		if (eventHandlers == null)
		{
			return false;
		}
		RdEventRegistration[] regEvents = eventHandlers.getRegisteredFilters(event);
		if (regEvents == null || regEvents.length == 0)
		{
			return false;
		}
		params._registeredHandlers = regEvents;
		params._event = event;
		params._handledEvent = false;
		int retVal = RdEventInterface.ABORT;
		int lastIndex = -1;
		for (int i = 0; i < regEvents.length; i++)
		{
			params._handlerIndex = i;
			RdEventRegistration reg = regEvents[i];
			retVal = reg._eventHandler.handleEvent(reg, params, cxt);
			if (retVal != RdEventInterface.CONTINUE)
			{
				// This should be a rare situation that should be clearly documented
				// by event implementors.
				lastIndex = i;
				break;
			}
		}
		if (retVal == RdEventInterface.ABORT)
		{
			// Generally this is a controlled error where the implementor wants to
			// throw an exception that will be suppressed.
			if ((params._flags & RdEventParams.F_THROW_EXCEPTION_IF_ABORT_OR_FAIL) != 0)
			{
				if (lastIndex >= 0)
				{
					// Milder error. A programmatic abort is not intended to be an error.
					throw new RdException("rdceEventAborted", event._name, 
						regEvents[lastIndex]._id);
				}
				
				// Caller really expects this call to be handled by at least one
				// handler. Failure usually is bad.
				throw new RdException(RdErrorCodes.GENERAL_SYSTEM_ERROR,
					"rdceEventNoRegisteredHandlers", event._name);
			}
			return false;
		}
		return true;
	}
	
	static public void registerForEvents(RdTable table, RdContext cxt) throws RdException
	{
		int numRows = table.getNumRows();
		List<RdEventRegistration> addOrUpdateEvents = new ArrayList<RdEventRegistration>();
		List<RdEventRegistration> deleteEvents = new ArrayList<RdEventRegistration>();
		for (int i = 0; i < numRows; i++)
		{
			table.setCurrentRowIndex(i);
			RdEventRegistration[] regArr = createEventRegistrationsFromTableRow(table, cxt);
			
			for (RdEventRegistration reg : regArr)
			{
				if (reg._isRemove)
				{
					deleteEvents.add(reg);
				}
				else
				{
					addOrUpdateEvents.add(reg);
				}
			}
		}
		
		RdEventHandlers handlers = getEventHandlers(cxt);
		handlers.updateRegisteredEvents(addOrUpdateEvents, deleteEvents, cxt);
	}
	
	static public RdEventRegistration[] createEventRegistrationsFromTableRow(RdTable table, 
		RdContext cxt) throws RdException
	{
		String id = RdDataUtils.getS(table, EVENT_REGISTRATION_ID, cxt);
		String handlerClass = RdDataUtils.getS(table, EVENT_HANDLER_CLASSS, cxt);
		String parameter = RdDataUtils.getS(table, EVENT_REGISTRATION_PARAMETER, cxt);
		int order = RdLoadOrder.getLoadOrder(table, cxt);
		int flags = (int)RdDataUtils.getInteger(table, EVENT_REGISTRATION_FLAGS, 0, cxt);
		boolean isRemove = RdTableUtils.isRowDisabled(table, cxt) || 
			handlerClass.length() == 0;
		String events = RdDataUtils.getS(table, EVENT_IDS, cxt);
		List<String> eventsList = StrUtils.parseList(events, cxt);
		RdEventRegistration[] regList = new RdEventRegistration[eventsList.size()];
		int index = 0;

		for (String eventId : eventsList)
		{
			RdEventId event = registerOrCreateEventId(eventId, null, 0);
			RdEventRegistration reg = new RdEventRegistration(id, event, order, flags, 
				parameter, handlerClass);
			if (isRemove)
			{
				reg._isRemove = true;
			}
			regList[index++] = reg;
		}
		return regList;
	}
}
