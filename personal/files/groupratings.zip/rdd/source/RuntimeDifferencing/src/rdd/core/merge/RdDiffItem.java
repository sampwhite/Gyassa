package rdd.core.merge;

import java.util.List;
import java.util.Set;

import rdd.core.RdResourceKey;
import rdd.core.RdResourceProperties;

/**
 * A base RdDiffItem is created when a particular version of a data item at a particular load order
 * that came from a particular RdResourceKey from a specific RdLocation has changed. The RdDiffItem
 * is built up from computing the merge of prior versions (lower load orders) of the data item and
 * then seeing how the change in the current data item impacts the accumulated changes that have
 * occurred for a particular RdResourceKey "merged result".
 * 
 * The base RdDiffItem objects are overlaid to produce a final RdDiffItem that can be used
 * to apply a diff to the prior merged result to produce the current merged result.
  */
public class RdDiffItem
{
	/**
	 * How the diff should be applied. Contents can either be merged, replaced, or deleted.
	 * See RdMergeUtils for list of diff types,
	 */
	public int _diffType;
	
	/**
	 * The resource key used to retrieve this item. Also determines what type of object
	 * is being updated and how it may be updated.
	 */
	public RdResourceKey _resourceKey;
	
	/**
	 * Current resource properties at the time this diff was calculated. Some
	 * resource properties are merged as one resource overlays another.
	 */
	public RdResourceProperties _resourceProps;
	
	/**
	 * List of keys to remove when applying diff. If applied to a table the keys are
	 * values of the primary key column.
	 */
	public List _keysToRemove;
	
	/**
	 * Map that supports the attribute _keysToRemove to optimize adding entries.
	 */
	public Set _keysToRemoveMap;
	
	/**
	 * If a difference between two objects have been calculated, this will contain the data
	 * to be added or replaced when doing the diff.
	 */
	public Object _diffObject;
	
	/**
	 * The version of this object that includes all prior overlays and full application
	 * of the most current version from the data that created this diff object.
	 */
	public Object _curObject;
	
	/**
	 * Constructor that creates a diff item for a particular resource.
	 */
	public RdDiffItem(int diffType, RdResourceKey resourceKey, RdResourceProperties resourceProps)
	{
		_diffType = diffType;
		_resourceKey = resourceKey;
		_resourceProps = resourceProps;
	}
}
