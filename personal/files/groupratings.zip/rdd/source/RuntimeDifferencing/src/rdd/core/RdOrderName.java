package rdd.core;

public class RdOrderName
{
	/**
	 * Tag name for order so raw numbers can be avoided.
	 */
	public String _name;
	
	/**
	 * The associated actual numeric order.
	 */
	public int _order;
	
	public RdOrderName(String name, int order)
	{
		_name = name;
		_order = order;
	}
}
