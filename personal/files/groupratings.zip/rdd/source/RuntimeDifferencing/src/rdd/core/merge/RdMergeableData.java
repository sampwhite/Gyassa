package rdd.core.merge;

import java.util.Map;

import rdd.core.RdLocation;
import rdd.core.RdResourceKey;
import rdd.core.RdResourceValue;


/**
 * A class that represents either all the resource data read from a single file
 * or query key.
 */
public class RdMergeableData
{
	/**
	 * The aggregated last modified counters of all the sources that
	 * went into producing this object.
	 */
	volatile public long _lastModifiedCounter;
	
	/**
	 * Whether the data in this object is valid. If not valid then
	 * it needs to be reloaded (or loaded for the first time).
	 */
	public boolean _isValid;
	
	/**
	 * Whether the source data has been deleted since this data was last loaded.
	 */
	public boolean _isDeleted;
	
	/**
	 * The load order. Used to determine which order the data is overlaid.
	 */
	public int _loadOrder;
	
	/**
	 * A canonical protocol object that uniquely identifies where this data was retrieved. The
	 * object should be sufficient to find and load this data again in exactly the
	 * same way it was loaded before. Two different strings are assumed to refer to two
	 * different data sources.
	 */
	public RdLocation _loadLocation;
	
	/**
	 * Flags that describe where this data was loaded, expectations about how
	 * dirtiness states are detected.
	 */
	public int _flags;
	
	/**
	 * The mergeable resources that were loaded.
	 */
	public Map<RdResourceKey,RdResourceValue> _loadedResources;
	
	/**
	 * Set to true if this object holds a derived output.
	 */
	public boolean _isDerivedObject;
	
	/**
	 * If the mergeable data references a derived output of a merge, then this
	 * attribute holds that result.
	 */
	public Object _derivedObject;
	
	
	public RdMergeableData(RdLocation location, long lastModifiedCounter, int loadOrder)
	{
		_loadLocation = location;
		_lastModifiedCounter = lastModifiedCounter;
		_loadOrder = loadOrder;
	}
}
