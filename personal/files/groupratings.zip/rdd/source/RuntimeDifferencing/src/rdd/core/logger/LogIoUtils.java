package rdd.core.logger;

import java.io.IOException;

import rdd.core.RdCharArray;

public class LogIoUtils
{
	static public void appendStackTrace(Appendable appendable, Throwable t)
	{
		try
		{
	        StackTraceElement[] trace = t.getStackTrace();
	        for (int i=0; i < trace.length; i++)
	        {
	        	appendable.append("\tat ");
	        	appendable.append(trace[i].toString());
	        	appendable.append("\n");
	        }
	
	        Throwable ourCause = t.getCause();
	        if (ourCause != null)
	        {
	        	appendStackTraceAsCause(appendable, trace, ourCause);
	        }
		}
		catch (Exception ignore)
		{
			System.err.println(ignore);
		}
	}
	
	static public void appendStackTraceAsCause(Appendable appendable, StackTraceElement[] causedTrace, Throwable t)
	{
		try
		{
			StackTraceElement[] trace = t.getStackTrace();
	        int m = trace.length-1, n = causedTrace.length-1;
	        while (m >= 0 && n >=0 && trace[m].equals(causedTrace[n])) 
	        {
	            m--; n--;
	        }
	        int framesInCommon = trace.length - 1 - m;
	
	        appendable.append("Caused by: ");
	        appendable.append(t.toString());
	        appendable.append("\n");
	        for (int i=0; i <= m; i++)
	        {
	            appendable.append("\tat ");
	            appendable.append(trace[i].toString());
	            appendable.append("\n");
	        }
	        if (framesInCommon != 0)
	        {
	            appendable.append("\t... " + framesInCommon + " more\n");
	        }
	
	        // Recurse if we have a cause
	        Throwable ourCause = t.getCause();
	        if (ourCause != null)
	        {
	        	appendStackTraceAsCause(appendable, trace, ourCause);
	        }
		}
		catch (Exception ignore)
		{
			System.err.println(ignore);
		}
	}
	
	static public void encodeAndAppendLogOutput(Appendable appendable, CharSequence str, int start, int end) throws IOException
	{
		// Indent lines and encode some characters
		char[] buf = null;
		if (str instanceof RdCharArray)
		{
			buf = ((RdCharArray)str)._chars;
		}
		boolean addStartSpace = false;
		boolean doLineFeedSeparation = false;
		if (end - start > 256)
		{
			doLineFeedSeparation = true;
		}
		else
		{
			for (int i = start; i < end; i++)
			{
				char ch = (buf != null) ? buf[i] : str.charAt(i);
				if (ch == '\n')
				{
					doLineFeedSeparation = true;
					break;
				}
			}
		}
		if (doLineFeedSeparation)
		{
			appendable.append("\n ");
		}
		for (int i = start; i < end; i++)
		{
			char ch = (buf != null) ? buf[i] : str.charAt(i);
			if (ch == ' ' || ch == '\t')
			{
				addStartSpace = false;
			}
			if (addStartSpace)
			{
				appendable.append(' ');
				addStartSpace = false;
			}
			if (ch == '<')
			{
				appendable.append("*lt*");
			}
			else if (ch == '>')
			{
				appendable.append("*gt*");
			}
			else
			{
				appendable.append(ch);
			}
			if (ch == '\n')
			{
				addStartSpace = true;
			}
		}
		if (addStartSpace)
		{
			appendable.append(' ');
		}
		else if (doLineFeedSeparation)
		{
			appendable.append("\n ");
		}
	}
}
