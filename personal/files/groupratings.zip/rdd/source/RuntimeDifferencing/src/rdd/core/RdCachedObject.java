package rdd.core;

import java.util.Date;

/**
 * Wrapper for a cached object (allows data to be changed for somebody who holds
 * this object and to track when it has changed).
 */
public class RdCachedObject
{
	public RdKey _lookupKey;
	public String _type;
	public Object _obj;
	long _lastModified;
	
	public RdCachedObject(RdKey lookupKey, String type, Object obj, Date lastModified)
	{
		_type = type;
		setObject(obj, lastModified);
	}
	
	public void setObject(Object obj, Date lastModified)
	{
		_obj = obj;
		if (lastModified != null)
		{
			_lastModified = lastModified.getTime();
		}
		else
		{
			_lastModified = System.currentTimeMillis();
		}
	}

}
