package rdd.core;

public class RdResourceTypes
{
	//+section Resource Types
	static public final int TEXT = -1;
	static public final int NAMEVALUE = 0;
	static public final int STRING = 1; // A string that is a localized version of a string key.
	static public final int TABLE = 2;
	static public final int MAP = 3;
	static public final int DATA = 4;
	static public final int PAGE_SCRIPT = 5;
	static public final int EXECUTION_SCRIPT = 6;
	static public final int BEGIN_SECTION = 7;
	static public final int END_SECTION = 8;
	static public final int HIDDEN = 9;
	//+endsection Resource Types
	
	/**
	 * String versions of resource types.
	 */
	static public final String[] RESOURCE_TYPE_LABELS = {"namevalue", "string", "table", "map", 
		"data", "pagescript", "execscript", "section", "endsection", "hidden"};
	
	static public final RdCharArray END_RESOURCE_STRING = new RdCharArray("end");
	static public final RdCharArray END_HIDDEN_STRING = new RdCharArray("endhidden");
	
	static public boolean needsNormalEndTag(int type)
	{
		return (type >= NAMEVALUE && type < BEGIN_SECTION);
	}
	
	static public boolean canHaveBody(int type)
	{
		return needsNormalEndTag(type) || type == HIDDEN;
	}
	
	static public boolean resourceMustHaveName(int type)
	{
		return (type >= NAMEVALUE && type < BEGIN_SECTION);
	}
	
	static public String getResourceLabel(int type)
	{
		if (type < 0)
		{
			return null;
		}
		return RESOURCE_TYPE_LABELS[type];
	}
	
	static public boolean hasText(int type)
	{
		return (type != BEGIN_SECTION && type != END_SECTION);
	}
	
	static public boolean isDataValue(int type)
	{
		return type >= 0 && type <= DATA && type != STRING;
	}
	
	static public int determineResourceTypeFromValueType(int valType, int defaultResourceType)
	{
		// Do the cases where the data value clearly controls how it should be handled as a resource.
		int resType = defaultResourceType;
		if (valType == RdKey.TABLE)
		{
			resType = RdResourceTypes.TABLE;
		}
		else if (valType == RdKey.DATA)
		{
			resType = RdResourceTypes.DATA;
		}
		return resType;
	}
	
	static public int determineValueTypeFromResourceType(int resType, int defaultValType)
	{
		int valType = defaultValType;
		if (resType == RdResourceTypes.TABLE)
		{
			valType = RdKey.TABLE;
		}
		else if (resType == RdResourceTypes.MAP)
		{
			valType = RdKey.MAP;
		}
		else if (resType == RdResourceTypes.DATA)
		{
			valType = RdKey.DATA;
		}
		return valType;
	}
	
	static public int determineResourceTypeFromTypeName(String name)
	{
		name = name.intern();
		int retVal = -1;
		for (int i = 0; i < RESOURCE_TYPE_LABELS.length; i++)
		{
			String type = RESOURCE_TYPE_LABELS[i];
			if (type == name)
			{
				retVal = i;
				break;
			}
		}
		return retVal;
	}
	
	static public RdCharArray getTerminationSequence(int resType)
	{
		return (resType == HIDDEN) ? END_HIDDEN_STRING : END_RESOURCE_STRING;
	}
}
