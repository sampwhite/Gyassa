package groupratings;
import rdd.core.RdContext;


public class TraceUtils
{
	// General tracing attributes.
	static boolean _reportRounds = false;
	static boolean _reportPlayerList = false;
	static public boolean _traceBadMatches = false;
	static public boolean _traceBadRatingPredictions = false;
	
	// Tracing attributes focusing the weakest and strongest players.
	public static boolean _traceWeakPlayers = false;
	public static boolean _traceStrongPlayers = false;
	public static boolean _traceRatingRange = false;
	public static int[] _ratingRange = {2000, 2200};
	public static boolean _isInit = false;
	public static int[] _lowHighInitSkill;
	public static int[] _lowHighTrainSkill;
	public static int _tightnessOfRanges = 30;
	
	public static void checkInit(Players players, RdContext cxt)
	{
		if (!_isInit)
		{
			_lowHighInitSkill = createLowHighRangeFromRandom(players._matchCreationParameters._startSkillRange);
			_lowHighTrainSkill = createLowHighRangeFromRandom(players._matchCreationParameters._maxSkillImprovementRateRange);
			checkDoingDetailedRoundReporting(players);
		}
	}
	
	public static int[] createLowHighRangeFromRandom(RandomRange random)
	{
		int diff = random._high - random._low;
		int delta = diff/_tightnessOfRanges;
		int[] retVal;
		if (diff > 0)
		{
			retVal = new int[]{random._low + delta, random._high - delta};
		}
		else
		{
			retVal = new int[]{random._high - delta, random._low + delta};			
		}
		return retVal;
	}
	
	public static boolean checkTracePlayer(Players players, Player p, RdContext cxt, String method)
	{
		checkInit(players, cxt);;
		boolean retVal = false;
		if ((_traceWeakPlayers && checkInRange(p, true)) || 
			(_traceStrongPlayers && checkInRange(p, false)) || 
			(_traceRatingRange && p._rating >= _ratingRange[0] && p._rating <= _ratingRange[1]))
		{
			RP.detailln("-" + p+ "-" + method, cxt);
			retVal = true;
		}
		return retVal;
	}
	
	public static boolean checkInRange(Player p, boolean isLow)
	{
		int index = (isLow) ? 0 : 1;
		return checkInRange(p._startSkill, index, _lowHighInitSkill) &&
			checkInRange(p._maxTrainingImprovement, index, _lowHighTrainSkill);
		
	}
	
	public static boolean checkInRange(int val, int index, int[] range)
	{
		int testVal = range[index];
		return (index == 0) ? val < testVal : val > testVal;
	}
	
	public static void checkDoingDetailedRoundReporting(Players p)
	{
		// See if any of the "detail" reporting flags are enabled.
		_reportRounds = _traceBadMatches || _traceBadRatingPredictions ||
			_traceWeakPlayers || _traceStrongPlayers || _traceRatingRange || _reportRounds;
	}
}
