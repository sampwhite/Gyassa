package groupratings;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import rdd.core.RdContext;


public class MatchProcessUtils
{
	
	public static void init(int eloKfactor, float teamTotalRatingDivider,
		float teamSkillDivider, int numWinsRatingInflation, Players players, RdContext cxt)
	{
		MatchProcessingParameters mp = players._matchProcessingParameters;
		
		// Control how much we move rating up and down with each loss. The bigger the number
		// assigned here the faster the ratings move.
		mp._eloKfactor = eloKfactor;
		
		// The number of wins to do rating inflation.
		mp._numWinsRatingInflation = numWinsRatingInflation;
		mp._numFirstLongIntervalWinsRatingInflation = numWinsRatingInflation/4;
		
		// The expected randomized output of a team is the sum of the random variations of
		// the individual members. Generally the team's random output is significantly greater
		// than the randomization of each individual player. These attributes control how much greater.
		mp._teamTotalRatingDivider = teamTotalRatingDivider;
		mp._teamSkillDivider = teamSkillDivider;
		
		// Use values we might use for Chess augmented by increased variance of having more
		// players.
		mp._goodMatchRatingVariance = RatingConstants.RATING_LEVEL_INTERVAL;
		mp._goodMatchSkillVariance = RatingConstants.SKILL_LEVEL_INTERVAL;
		
		// Use a tight value, expect about teamSkillMultiplier times 8% failure rate based on randomization of
		// skill and randomization in forming teams. A ten man team simulation should
		// produce a failure rate under 24%.
		mp._goodSkillPredictionByRatingVariance = mp._goodMatchSkillVariance/2;
		
		// Sees if the prediction was quite poor. The rating system is failing the absolute value
		// of team_rating * 10 - team_skill is over this variance times the teamSkillMultiplier
		// more than 20% of the time. The failure rate should be below 5%.
		mp._badSkillPredictionByRatingVariance = 2 * mp._goodSkillPredictionByRatingVariance;
	}
	
	//+section resolveMatches
	public static void resolveMatches(int round, Players players, RdContext cxt)
	{
		Collection<Match> matches = players._currentMatches;
		List<Match> resolvedMatches = new ArrayList<Match>();
		for (Match m : matches)
		{
			m._numRoundsActive++;
			if (m._numRoundsActive >= m._endRoundCount)
			{
				resolveFinishedMatch(round, players, m, cxt);
				resolvedMatches.add(m);
			}
		}
		
		for (Match m : resolvedMatches)
		{
			matches.remove(m);
		}
	}
	
	/** Support method for resolveMatches */
	public static void resolveFinishedMatch(int round, Players players, Match match, RdContext cxt)
	{
		// Determine who won.
		PlayerGroup side1 = players._side1;
		PlayerGroup side2 = players._side2;
		MatchProcessingParameters mp = players._matchProcessingParameters;

		int minRating = (match._team1._minRating < match._team2._minRating) ?
			match._team1._minRating : match._team2._minRating;

		int team1Skill = computeTeamSkill(match._team1, players, cxt);
		int team2Skill = computeTeamSkill(match._team2, players, cxt);
		int team1SkillResult = addTeamSkillVariance(team1Skill, match._team1, players, cxt);
		int team2SkillResult = addTeamSkillVariance(team2Skill, match._team2, players, cxt);
		boolean team1Won = (team1SkillResult >= team2SkillResult); // Tie goes to team 1.
		PlayerGroup winnerSide = (team1Won) ? side1 : side2;
		PlayerGroup loserSide = (team1Won) ? side2 : side1;
		Team winner = (team1Won) ? match._team1 : match._team2;
		Team loser = (team1Won) ? match._team2 : match._team1;
		int winnersTeamSkill = (team1Won) ? team1Skill : team2Skill;
		int losersTeamSkill = (team1Won) ? team2Skill : team1Skill;
		int normalizedWinnerSkill = (int) (winnersTeamSkill / mp._teamSkillDivider);
		int averageWinnerSkill = winnersTeamSkill/winner._members.length;
		int normalizedLoserSkill = (int) (losersTeamSkill / mp._teamSkillDivider);
		int averageLoserSkill = losersTeamSkill/loser._members.length;
		int winnersRating = computeTotalRating(winner, players, cxt);
		int losersRating = computeTotalRating(loser, players, cxt);
		int normalizedWinnerRating = (int)(winnersRating / mp._teamTotalRatingDivider);
		int averageWinnerRating = winnersRating/winner._members.length;
		int normalizedLoserRating = (int)(losersRating / mp._teamTotalRatingDivider);
		int averageLoserRating = losersRating/loser._members.length;
		
		int minWinnerWinCount = (team1Won) ? players._numRewardsPerIntervalSide1 : 
			players._numRewardsPerIntervalSide2;
		int minLoserWinCount = (team1Won) ? players._numRewardsPerIntervalSide2 : 
			players._numRewardsPerIntervalSide1;
		
		// Compute equipment multiplier.
		int minRatingDiffExperienced = minRating - mp._experiencedPlayerRating;
		int equipRatingIndex = (minRatingDiffExperienced > 0) ? 
			minRatingDiffExperienced/players._rateEquipmentImprovementMultiplierInterval : 0;
		int equipmentWinningsMultiplier = 1 << equipRatingIndex;

		// Report on how well we did in making this match.
		winnerSide._totalWins++;
		players._randomBeatSkill.incrementCounter(normalizedWinnerSkill < normalizedLoserSkill);
		players._expertMatch.incrementCounter(minRating >= mp._expertPlayerRating);
		int ratingDiff = (team1Won) ? normalizedWinnerRating - normalizedLoserRating : 
			normalizedLoserRating - normalizedWinnerRating;
		players._resultsDistribution.reportResult(ratingDiff, team1Won);
		// Report on specific small rating intervals.
		int skillDiff= (team1Won) ? normalizedWinnerSkill - normalizedLoserSkill :
			normalizedLoserSkill - normalizedWinnerSkill;
		for (RatingDifferenceSkillVariance rdsv : players._ratingSkillVariances)
		{
			rdsv.reportMatchResult(ratingDiff, skillDiff, team1Won);
		}
		
		boolean goodRating = players._goodRatedMatches.testDifferenceAgainstBoundingThreshhold(
			normalizedWinnerRating, normalizedLoserRating, mp._goodMatchRatingVariance);
		boolean goodSkill = players._goodSkillMatches.testDifferenceAgainstBoundingThreshhold(
			normalizedWinnerSkill, normalizedLoserSkill, mp._goodMatchSkillVariance );
		int winnerSkillDiff = normalizedWinnerSkill - normalizedLoserSkill;
		int winnerRatingDiff = normalizedWinnerRating - normalizedLoserRating;
		int predictedWinnerSkillDiff = RatingConstants.convertFromRatingToSkill(winnerRatingDiff);
		
		// Bound how large we test against for predicting well. We are only expected to predict well
		// locally around win and loss, not over the entire range of rating and skill. In particular,
		// this does not do well even for single player against player rating systems.
		int rangeBound = 2 * mp._goodSkillPredictionByRatingVariance;
		int compareSkillDiff = RatingUtils.boundIntegerByAbsoluteValue(winnerSkillDiff, rangeBound);
		int comparePredictedDiff = RatingUtils.boundIntegerByAbsoluteValue(predictedWinnerSkillDiff, rangeBound);
		boolean atRangeBound = (compareSkillDiff == rangeBound || compareSkillDiff == -rangeBound);
		boolean wellPredictedMatch = true;
		boolean inBounds = false;
		if (!atRangeBound || compareSkillDiff != comparePredictedDiff)
		{
			inBounds = true;
			wellPredictedMatch = players._ratingsPredictedSkillWell.testDifferenceAgainstBoundingThreshhold(winnerSkillDiff, 
				predictedWinnerSkillDiff, mp._goodSkillPredictionByRatingVariance);
		}
		if (!inBounds)
		{
			players._ratingsPredictedSkillWell.incrementNonApplicableCounter();
		}
		if (inBounds && minRating >= mp._expertPlayerRating)
		{
			players._expertRatingsPredictedSkillWell.incrementCounter(wellPredictedMatch);
		}
		else
		{
			players._expertRatingsPredictedSkillWell.incrementNonApplicableCounter();
		}
		rangeBound = 2 * mp._badSkillPredictionByRatingVariance;
		compareSkillDiff = RatingUtils.boundIntegerByAbsoluteValue(winnerSkillDiff, rangeBound);
		comparePredictedDiff = RatingUtils.boundIntegerByAbsoluteValue(predictedWinnerSkillDiff, rangeBound);
		atRangeBound = (compareSkillDiff == rangeBound || compareSkillDiff == -rangeBound);
		boolean notBadlyPredictedMatch = true;
		inBounds = false;
		if (!atRangeBound || compareSkillDiff != comparePredictedDiff)
		{
			inBounds = true;
			notBadlyPredictedMatch = players._ratingsPredictedSkillNotBadly.testDifferenceAgainstBoundingThreshhold(compareSkillDiff, 
				comparePredictedDiff, mp._badSkillPredictionByRatingVariance);
		}
		if (!inBounds)
		{
			players._ratingsPredictedSkillNotBadly.incrementNonApplicableCounter();
		}
		if (TraceUtils._traceBadMatches && (!goodRating || !goodSkill || !notBadlyPredictedMatch) ||
			(TraceUtils._traceBadRatingPredictions && !notBadlyPredictedMatch))
		{
			RP.detailln(match._name + "(team1Won=" + team1Won + ",duration=" + 
				match._numRoundsActive + ",avgWinSkill=" + averageWinnerSkill + 
				",avgWinRating=" + averageWinnerRating + ",equipMult=" + equipmentWinningsMultiplier
				+ ",avgLoserSkill=" + averageLoserSkill + ",avgLoserRating=" + averageLoserRating +
					",goodRating=" + goodRating + ",goodSkill=" + goodSkill + 
					",wellPredicted=" + wellPredictedMatch + ")", cxt);
			
		}
		if (TraceUtils._traceBadRatingPredictions && !notBadlyPredictedMatch)
		{
			RP.detailln("**Failed to predict skill for match**", cxt);
			RP.detailln("Winning Team", cxt);
			RP.detailln(winner.toString(), cxt);
			RP.detailln("Losing Team", cxt);
			RP.detailln(loser.toString(), cxt);
		}
		
		
		// Rating adjustment, with losers having uneven distribution of results.
		int[] lossWeight = new int[loser._members.length];
		int totalLoserWeight = 0;
		int totalLoserPredictedStats = 0;
		int totalLoserActualStats = 0;
		if (mp._useStatsForLosingPlayers || mp._doBadSkillProductivityTesting)
		{
			int index = 0;
			for (Player p : loser._members)
			{
				int actualStats = computeSkillProductivity(p, players, averageLoserSkill, 
					averageWinnerSkill, cxt);
				int expectedStats = computedExpectedSkillProductivity(p, players, averageLoserRating,
					averageWinnerRating, cxt);
				int resultExpectedStats = expectedStats;
				if (expectedStats < mp._minExpectedSkillProductivity)
				{
					// When expectations get low, accuracy is reduced.
					resultExpectedStats = mp._minExpectedSkillProductivity;
				}
				int resultDiff = actualStats - resultExpectedStats;
				
				// Parameters expectedProductivityDiffDivider and baseWeight were chosen by
				// experimentation. This weighting helps produce convergence that is equivalent
				// to having a high K-factor but keeping the precision of a low K-factor. Without
				// this code, it would be necessary to increase the K-factor above 16 in order
				// to have ratings reflect current player reality.
				int expectedProductivityDiffDivider = mp._minExpectedSkillProductivity;
				int baseWeight = 4 * expectedProductivityDiffDivider;
				boolean isNeg = resultDiff < 0;
				int absResultDiff = (isNeg) ? -resultDiff : resultDiff;
				int exponent = absResultDiff / expectedProductivityDiffDivider;
				int remainder = absResultDiff % expectedProductivityDiffDivider;
				int playerWeight = baseWeight;
				if (isNeg)
				{
					// Make the weight larger.
					playerWeight += remainder;
					playerWeight = playerWeight << exponent;
				}
				else
				{
					// Make the weight smaller.
					playerWeight -= remainder;
					playerWeight = playerWeight >> exponent;
				}
				if (playerWeight <= 0)
				{
					playerWeight = 1;
				}
				
				totalLoserWeight += playerWeight;
				lossWeight[index++] = playerWeight;
				totalLoserActualStats += actualStats;
				totalLoserPredictedStats += expectedStats;
			}
		}
		
		// Use Chess mechanisms for assigning adjustment for win and loss (with multiplier to
		// account for predicted extra variance). Divide by an additional factor of
		// _teamTotalRatingDivider to increase the spread in the ratings to that
		// they are as expected.
		float power = ((float)winnerRatingDiff) / RatingConstants.RATING_LEVEL_INTERVAL;
		
		// How much to reduce skill improvement if the rating totals are too far apart.
		// We use multiplier and divider to allow quicker experimentation by
		// giving more control over exactly how we might want to adjust rating but
		// still do integer arithmetic.
		int skillRatingReducer = 1;
		int kFactorMultiplier = 4;
		int kFactorDivider = kFactorMultiplier;
		boolean isExpectedProductivity = true;
		if (mp._doBadSkillProductivityTesting)
		{
			// See if total productivity figures imply an upward adjustment in the amount
			// ratings move.
			int blowoutThreshold = loser._members.length * mp._negativeProductivityThresholdForBlowout;
			int diffStats = totalLoserActualStats - totalLoserPredictedStats;
			isExpectedProductivity = diffStats >= 0;
			players._expectedProductivity.incrementCounter(isExpectedProductivity);
			
			if (!isExpectedProductivity)
			{
				// This was bad loss, it is no random chance that this occurred. This makes the result of
				// this match better in predictive power. Do increased rating adjustment to reflect this.
				kFactorDivider = kFactorDivider/2;
				
				if (diffStats < -blowoutThreshold)
				{
					// This was a blowout. Movement of rating should be as fast as possible
					// without creating undue instability.
					kFactorDivider =  kFactorDivider/2;
				}
			}
		}
		else
		{
			players._expectedProductivity.incrementNonApplicableCounter();
		}
		
		double eloEval = Math.pow(10, power);
		double portionOfKFactor = 1.0d/(1 + eloEval);
		int ratingChange = (int)((kFactorMultiplier * portionOfKFactor * mp._eloKfactor)/kFactorDivider + 0.5);
		
		// If part of a hugely unequal game, your skill will not improve as quickly. Reduce
		// the skill improvements from training in that case.
		if (power >= 2)
		{
			skillRatingReducer = 1 << (int)power;
		}
		
		// If a game that did not have expected productivity then the players who have played fewer 
		// games on the winning team are likely to have done more to get the victory than the players 
		// who have played more games. This conclusion is based on analysis of the data.
		// Portion out half the winnings based on weight of number of games played for
		// players that have not played many games. This code is highly experimental and subject
		// to change. The current code only gives a minor tweak to the weighting.
		int[] winWeight = null;
		int totalWinWeight = 0;
		int winnerWeightPool = 0;
		int winnerRatingChange = ratingChange;
		if (!isExpectedProductivity && power < .25)
		{
			int halfRatingChange = winnerRatingChange / 2;
			winnerRatingChange -= halfRatingChange;
			winnerWeightPool = winner._members.length * halfRatingChange;
			winWeight = new int[winner._members.length];
			int index = 0;
			for (Player p : winner._members)
			{
				int weight = 2;
				if (p._gamesPlayed < 80)
				{
					weight = 3;
					if (p._gamesPlayed < 20)
					{
						weight = 4;
					}
				}
				totalWinWeight += weight;
				winWeight[index++] = weight;
			}
		}

		
		// Do computations for winners.
		int index = 0;
		for (Player p : winner._members)
		{
			applySkillImprovement(round, p, players, skillRatingReducer, cxt);
			applyEquipmentImprovement(round, true, minWinnerWinCount, p, players, players._baseEquipmentImprovementAmount,
				equipmentWinningsMultiplier, cxt);
			int ratingAdj = winnerRatingChange;
			if (winWeight != null)
			{
				int weightAdjForThisPlayer = winnerWeightPool * winWeight[index++];
				weightAdjForThisPlayer += totalWinWeight/2; // Round to nearest integer when dividing by totalWinWeight.
				ratingAdj += weightAdjForThisPlayer/totalWinWeight;
			}

			// Winners share equally in rating adjustment.
			int playerRatingChange = computeRatingInflationAdjustment(p, winner, loser, players, true, 
				ratingAdj, averageWinnerRating, cxt);
			applyRatingAdjustment(p, winner, loser, players, true, playerRatingChange, averageWinnerRating, cxt);
			p._gamesPlayed++;
			p._numWins++;
			p._inMatch = false;
			
			moveTeamToNonWaitingQueue(round, minWinnerWinCount, p, players, winnerSide, 1, cxt);
		}
		
		// Do computation for losers.
		int playerIndex = 0;
		int ratingChangeLoserPool = loser._members.length * ratingChange;
		for (Player p : loser._members)
		{
			applySkillImprovement(round, p, players, skillRatingReducer, cxt);
			
			int ratingAdj;
			if (mp._useStatsForLosingPlayers)
			{
				// Losers who did not live up to their expected skill productivity based on their rating
				// are punished more severely compared to those who made or exceeded their
				// expected skill productivity.
				int weightAdjForThisPlayer = ratingChangeLoserPool * lossWeight[playerIndex];
				
				weightAdjForThisPlayer += totalLoserWeight/2; // Round to nearest integer when dividing by totalLoserWeight.
				ratingAdj = weightAdjForThisPlayer/totalLoserWeight;
			}
			else
			{
				ratingAdj = ratingChange;
			}
			int playerRatingChange = computeRatingInflationAdjustment(p, winner, loser, players, false, 
				-ratingAdj, averageWinnerRating, cxt);
			applyRatingAdjustment(p, loser, winner, players, false, playerRatingChange, averageWinnerRating, cxt);
			p._gamesPlayed++;
			p._inMatch = false;
			
			moveTeamToNonWaitingQueue(round, minLoserWinCount, p, players, loserSide, 1, cxt);
			playerIndex++;
		}
	}
	
	/** Support method for resolveFinishedMatch */
	public static int computeTeamSkill(Team team, Players players, RdContext cxt)
	{
		int skill = 0;
		for (Player p : team._members)
		{
			skill += p._currentSkill;
		}
		return skill;
	}
	
	/** Support method for resolveFinishedMatch 
	 * Note that teamSkill is NOT normalized so that we can provide alternate mechanisms for
	 * doing randomization of total team skill output. 
	 */
	public static int addTeamSkillVariance(int teamSkill, Team team, Players players, RdContext cxt)
	{
		MatchProcessingParameters mp = players._matchProcessingParameters;
		if (mp._useVariancesOfIndividualPlayers)
		{
			for (int i = 0; i < team._members.length; i++)
			{
				teamSkill += RatingUtils.getRandomInRange(cxt, mp._matchResultVarianceForTeam);
			}
		}
		else
		{
			// Do something really simple and approximate the increase in variance using _teamSkillMultiplier.
			teamSkill += mp._teamSkillDivider * RatingUtils.getRandomInRange(cxt, mp._matchResultVarianceForTeam);
		}
		return teamSkill;
	}
	
	/** Support method for resolveFinishedMatch */
	public static int computeTotalRating(Team team, Players players, RdContext cxt)
	{
		int rating = 0;
		for (Player p : team._members)
		{
			rating += p._rating;
		}
		return rating;
	}
	
	/** Support method for resolveFinishedMatch */
	public static int computeSkillProductivity(Player p, Players players, 
		int avgFriendSkill, int avgOpponentSkill, RdContext cxt)
	{
		// We assume that statistics were accumulated for each player for match and
		// that these statistics can give us some idea how much the player contributed
		// to the match.
		MatchProcessingParameters mp = players._matchProcessingParameters;
		
		// How much our team was better (or worse) than the other team.
		int teamSkillDiff = (int)((players._numPlayersPerMatch * (avgFriendSkill - avgOpponentSkill) 
			+ avgOpponentSkill - p._currentSkill) / mp._teamSkillDivider);
		
		// It is unclear how much the average team skill contributes to our skill, but we will
		// assume it adds linearly for now.
		int playerSkillDiff = p._currentSkill - avgOpponentSkill;
		int skillProductivityAmount = calculateProductivity(teamSkillDiff, playerSkillDiff, p,
			players, cxt);

		if (skillProductivityAmount <= 0)
		{
			// Player probably had no opportunity to do anything.
			return 0;
		}
		
		// Half this amount is random since skill productivity is presumed to be somewhat random.
		int halfS = skillProductivityAmount/2;
		int actualSkillProductivity = RatingUtils.createRandomRange(cxt, halfS, skillProductivityAmount);
		
		// We deliberately cap the amount of measured skill when using per player game statistics, assuming
		// unusual amounts of skill productivity do not correlate well with rating or actual skill.
		if (actualSkillProductivity > 2 * mp._maxSkillProductivity)
		{
			// Can only do so well.
			actualSkillProductivity =  2 * mp._maxSkillProductivity;
		}
		
		// Player only shows some of this because of style of play (player may do things
		// that help the team to win that don't show up in the stats). Players that do
		// things for the good of the team in losing matches will tend to have lower ratings
		// than they deserve. By applying this adjustment only to losing players, we at least
		// do not penalize players on winning teams that sacrificed their productivity stats
		// in order to get the win.
		int playerSkillProductivity = (actualSkillProductivity * p._statCoorelationPercentage) / 100;
		
		// Multiply by two to account for average loss from randomization and statCoorelationPercentage.
		playerSkillProductivity = playerSkillProductivity << 1;

		// Make sure skill productivity has not gone above maximum again.
		if (playerSkillProductivity > mp._maxSkillProductivity)
		{
			playerSkillProductivity = mp._maxSkillProductivity;
		}

		return playerSkillProductivity;
	}
	
	/** Support method for resolveFinishedMatch */
	public static int computedExpectedSkillProductivity(Player p, Players players, 
		int avgFriendRating, int avgOpponentRating, RdContext cxt)
	{
		// This computation will evolve as we come to a better understanding of how rating
		// and skill correlate.
		MatchProcessingParameters mp = players._matchProcessingParameters;
		int teamRatingDiff = (int)((players._numPlayersPerMatch * (avgFriendRating - avgOpponentRating)
			+ avgOpponentRating - p._rating) / mp._teamSkillDivider);
		
		// Team rating can add only so much to our expected skill productivity. The RATING_INDEX_INTERVAL
		// was grabbed out of thin air.
		int teamPredictedSkillDiff = RatingConstants.convertFromRatingToSkill(teamRatingDiff);
		
		// This calculation is just a guess. We multiply by skill variance multiplier for group
		// play to represent the increased variance of skill outcome due to being part of
		// a team.
		int playerRatingDiff = (p._rating - avgOpponentRating);
		int playerPredictedSkillDiff = RatingConstants.convertFromRatingToSkill(playerRatingDiff);
		int expectedSkillProductivity = calculateProductivity(teamPredictedSkillDiff, playerPredictedSkillDiff, p,
			players, cxt);
		// We apply a cap.
		if (expectedSkillProductivity > mp._maxSkillProductivity)
		{
			expectedSkillProductivity = mp._maxSkillProductivity;
		}
		return expectedSkillProductivity;
	}
	
	/** Support method for resolveFinishedMatch */
	static public int calculateProductivity(int teamSkillDiff, int playerSkillDiff, 
		Player p, Players players, RdContext cxt)
	{
		MatchProcessingParameters mp = players._matchProcessingParameters;

		// Team can only help us so much. Current value compared against is a pure guess.
		if (teamSkillDiff > mp._maxTeamSkillProductivity)
		{
			teamSkillDiff = mp._maxTeamSkillProductivity;
		}

		// We do the obvious simple thing for now. Parameters teamSkillDiff and playerSkillDiff
		// have been normalized.
		int skillProductivity = teamSkillDiff + playerSkillDiff +  RatingConstants.SKILL_LEVEL_INTERVAL;
	
		if (skillProductivity < 0)
		{
			return 0;
		}
		
		return skillProductivity;
	}
	
	/** Support method for resolveFinishedMatch */
	public static void applySkillImprovement(int round, Player p, Players players, int reducer, RdContext cxt)
	{
		if (!players._matchProcessingParameters._doSkillTraining)
		{
			TraceUtils.checkTracePlayer(players, p, cxt, "applySkillImprovement-disabled");	
			return;
		}
		int amtCanImprove = p._maxTrainingImprovement - p._trainingImprovement;
		if (amtCanImprove == 0)
		{
			TraceUtils.checkTracePlayer(players, p, cxt, "applySkillImprovement-maxed out");
			return;
		}
		int amtToAdd = p._skillImprovementRate / reducer;
		
		boolean longTimeSinceLastBigSkillImprovement = round - p._lastRoundWithRealSkillIncrease > players._longDurationIntervalForImprovement;
		
		// If long interval since last big skill improvement, do another.
		if (longTimeSinceLastBigSkillImprovement || p._skillIncreasesInInterval < 1)
		{
			// Give a real skill increase if we have not already done a couple.
			p._skillIncreasesInInterval = 0;
			p._lastRoundWithRealSkillIncrease = round;
			
			// Follow along with equipment increase multiplier.
			amtToAdd = amtToAdd << 1;
		}
		else
		{
			// Get less skill if play a lot of games close together.
			if (p._skillIncreasesInInterval >= 2)
			{
				amtToAdd = amtToAdd >> 1;
			}
			if (p._skillIncreasesInInterval >= 8)
			{
				amtToAdd = amtToAdd >> 1;
			}
		}
		p._skillIncreasesInInterval++;
		
		if (amtToAdd > amtCanImprove)
		{
			amtToAdd = amtCanImprove;
		}
		p._trainingImprovement += amtToAdd;
		p._intrinsicSkill += amtToAdd;
		p._currentSkill += amtToAdd;
		TraceUtils.checkTracePlayer(players, p, cxt, "applySkillImprovement");
	}
	
	/** Support method for resolveFinishedMatch */
	public static void applyEquipmentImprovement(int round, boolean isWin, int minWinCount, Player p, Players players, int equipmentIncrease, int multiplier,
		RdContext cxt)
	{
		// See if first win(s) in long time.
		if (isWin)
		{
			boolean longDurationSinceLastWin = round - p._lastRoundWithRealWin >= players._longDurationIntervalForImprovement;
			if (p._realWinCountInInterval < minWinCount || longDurationSinceLastWin)
			{
				// Go up one equipment level. In theory, each level of equipment increase
				// has its own currency and this would allow player to get next level up
				// on currency. By giving such a big bump in each long duration interval,
				// we reduce the advantage gained by players who play constantly.
				equipmentIncrease = (equipmentIncrease << 3)/minWinCount;
				if (longDurationSinceLastWin)
				{
					p._realWinCountInInterval = 0;
					p._numFirstRealWins++;
					p._lastRoundWithRealWin = round;
				}
			}
			p._realWinCountInInterval++;
		}
		
		if (!players._matchProcessingParameters._doEquipmentImprovement)
		{
			TraceUtils.checkTracePlayer(players, p, cxt, "applyEquipmentImprovement-disabled");	
			return;
		}

		int amtCanImprove = players._maxEquipmentImprovement - p._equipmentScore;
		if (amtCanImprove <= 0)
		{
			TraceUtils.checkTracePlayer(players, p, cxt, "applyEquipmentImprovement-maxed out");
			return;
		}
		int curScoreImprovement = p._equipmentScore;
		int reducerExponent = curScoreImprovement /
			players._equipmentImprovementDegradationInterval;
		int reducer = 1 << (3 * reducerExponent);
		int amtToAdd = (equipmentIncrease * multiplier) / reducer;
		if (amtToAdd > amtCanImprove)
		{
			amtToAdd = amtCanImprove;
		}
		p._equipmentScore += amtToAdd;
		p._currentSkill += amtToAdd;
		TraceUtils.checkTracePlayer(players, p, cxt, "applyEquipmentImprovement");
	}
	
	public static int computeRatingInflationAdjustment(Player p, Team friendTeam, Team opposingTeam, 
		Players players, boolean weWon, int originalRatingAdj, int winnerRating, RdContext cxt)
	{
		// We take a partial predicted new rating to figure out multiplier, this reduces upward
		// bias from movement across boundaries for multiplier.
		MatchProcessingParameters mp = players._matchProcessingParameters;
		int ratingAdj = originalRatingAdj;
		if (mp._doRatingInflation)
		{
			int amtToAdd = 0;
			if (weWon && p._realWinCountInInterval == 1 &&
				p._numFirstRealWins < mp._numFirstLongIntervalWinsRatingInflation &&
				mp._doEquipmentImprovement)
			{
				// First win in long duration interval, rating boost to keep up
				// with expected equipment boost.
				amtToAdd = mp._amountFirstWinIncreasesRating;
				if (mp._accelerateInflationForEarlyWins && p._numFirstRealWins < (mp._numFirstLongIntervalWinsRatingInflation >> 3))
				{
					amtToAdd = amtToAdd << 1;
				}
			}
			else if (weWon && p._numWins < mp._numWinsRatingInflation)
			{
				amtToAdd = mp._amountWinIncreasesRating;
				if (mp._accelerateInflationForEarlyWins && p._numWins < (mp._numWinsRatingInflation >> 3))
				{
					amtToAdd = amtToAdd << 1;
				}
			}
			/*
			if (!mp._doEquipmentImprovement)
			{
				// Most of the reason for rating inflation is gone.
				amtToAdd = amtToAdd >> 3;
			}
			if (!mp._doPlayerRetirement)
			{
				amtToAdd = amtToAdd >> 1;
			}
			if (!mp._doSkillTraining)
			{
				amtToAdd = amtToAdd >> 1;
			}
			*/
			ratingAdj = ratingAdj + amtToAdd;
		}
		if (mp._applyGraduatedRatingAdjustment)
		{
			// These adjustments are specifically designed to fix issues with the "alpha"
			// so that they are closer to 100% more uniformly. Doing this seems to
			// improve rating accuracy.
			if (winnerRating >= mp._reduceKfactorRating)
			{
				ratingAdj = ratingAdj / 3;
			}
			/* Experimental code
			else if (winnerRating >= 2200 && winnerRating <= 2800)
			{
				ratingAdj = ratingAdj * 2;
			}
			*/
		}
		return ratingAdj;
	}
	
	public static void applyRatingAdjustment(Player p, Team friendTeam, Team opposingTeam, Players players, 
		boolean weWon, int ratingAdj, int winnerRating, RdContext cxt)
	{
		MatchProcessingParameters mp = players._matchProcessingParameters;
		if (!mp._doRatingInflation && !mp._doBadSkillProductivityTesting)
		{
			// Doing pure rating system on normal ratings. Multiply K-factor for players that have not played many games. Players
			// start out with a much greater diversity of ratings so we need to drastically accelerate convergence at the start.
			// We also cannot use low ratings as a proxy for a player that needs faster acceleration in ratings.
			if (p._gamesPlayed < 5)
			{
				ratingAdj = ratingAdj << 3;				
			}
			else if (p._gamesPlayed < 10)
			{
				ratingAdj = ratingAdj << 2;
			}
			else if (p._gamesPlayed < 100)
			{
				ratingAdj = ratingAdj << 1;
			}
		}
		else if (p._gamesPlayed < 20)
		{
			// Allow some acceleration to get the initial rating set.
			ratingAdj = ratingAdj << 1;
			if (p._gamesPlayed < 7)
			{
				ratingAdj = ratingAdj << 1;
			}
			if (p._gamesPlayed < 3)
			{
				ratingAdj = ratingAdj << 1;
			}
		}
		p._rating += ratingAdj;
		if (p._rating < 0)
		{
			p._rating = 0;
		}
		if (TraceUtils.checkTracePlayer(players, p, cxt, "applyRatingAdjustment-weWon=" + weWon))
		{
			if (opposingTeam._members.length <= 3)
			{
				RP.detailln("Opposing team: " + opposingTeam, cxt);
			}
		}
	}
	
	/** Support method for resolveFinishedMatch */
	public static void moveTeamToNonWaitingQueue(int round, int minWinCount, Player p, Players players,
		PlayerGroup playerGroup, int waitMultiplier,  RdContext cxt)
	{
		boolean retiredPlayer = false;
		if (players._matchProcessingParameters._doPlayerRetirement)
		{
			// Check to see if player is going to quit (for at least a while).
			
			// Compute how well player is doing. The better player is doing, the longer
			// they will stick around.
			int equipAsRating = RatingConstants.convertFromSkillToRating(p._equipmentScore);
			int successRating = p._rating + equipAsRating;
			int multiplesOfGoodTime = successRating/players._goodTimeRatingThreshold;
			
			// Each 2 multiple doubles the number of games we are willing to play.
			int maxGames = (int)(p._minNumberOfGamesToPlay * Math.sqrt(1 << multiplesOfGoodTime));
			if (p._gamesPlayed >= maxGames)
			{
				retiredPlayer = true;
				if (playerGroup._retiredPlayers == null)
				{
					playerGroup._retiredPlayers = new PlayerGroup(playerGroup._namePrefix);
				}
				playerGroup._players.remove(p);
				playerGroup._retiredPlayers._players.add(p);
				
				// Call for new players to be added to this player group.
				playerGroup._numNewPlayersToAdd++;
			}
		}
		if (!retiredPlayer)
		{
			int waitTime = waitMultiplier * RatingUtils.getRandomInRange(cxt, 
				players._playerRoundWaitRange);
			if (p._realWinCountInInterval >= minWinCount && round - p._lastRoundWithRealWin < players._longDurationIntervalForImprovement)
			{
				waitTime = waitTime * 4 * p._casualnessLevel;
			}
			p._roundsToWaitTillReadyForMatch = waitTime;
			playerGroup._playersNotWaiting.add(p);
			if (TraceUtils.checkTracePlayer(players, p, cxt, "moveTeamToNonWaitingQueue"))
			{
				RP.detailln("-waitTime=" + waitTime, cxt);
			}
		}
		else
		{
			TraceUtils.checkTracePlayer(players, p, cxt, "moveTeamToNonWaitingQueue-player retired");
		}
	}
	//+endsection resolveMatches

}
