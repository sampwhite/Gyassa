package groupratings;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;

import rdd.core.primitives.ArrayUtils;


public class PlayerGroup implements Comparator<Player>
{
	public int _totalNumPlayers;
	public String _namePrefix;
	public Collection<Player> _players;
	public Collection<Player> _playersNotWaiting;
	public Collection<Player> _playersWaiting;
	public Collection<Player>[] _ratingDistributedWaitingPlayers;
	public int _maxRatingIndex;
	public int _totalWins;
	
	// Retired players, put into another PlayerGroup object to allow access
	// to sorting methods.
	PlayerGroup _retiredPlayers;
	
	// Number of new players that should be added to pool of players. Allows players
	// to enter after start of simulation.
	public int _numNewPlayersToAdd;
	
	// Attributes created during reporting phase.
	public Player[] _playersSortedByRating;
	public GroupedResults[] _groupedResults;
	
	public PlayerGroup(String namePrefix)
	{
		_namePrefix = namePrefix;
		_players = RatingUtils.createOrderedSet(null);
		_playersNotWaiting = RatingUtils.createOrderedSet(null);
		_playersWaiting = RatingUtils.createOrderedSet(null);
	}
	
	public Collection<Player> getPlayersAtRatingIndex(int index)
	{
		if (index > _maxRatingIndex)
		{
			return null;
		}
		return _ratingDistributedWaitingPlayers[index];
	}
	
	public void createSortedListByRating()
	{
		Player[] parray = new Player[_players.size()];
		int i = 0;
		for (Player p : _players)
		{
			parray[i++] = p;
		}
		Arrays.sort(parray, this);
		_playersSortedByRating = parray;
	}
	
	public void createGroupedRatingAndSkillResultsFromSortedList(int ratingDivider, int skillDivider)
	{
		GroupedResults[] groupedResults = new GroupedResults[10];
		int index = -1;
		for (Player p : _playersSortedByRating)
		{
			// Group by rating.
			int pi = p._rating/ratingDivider;
			GroupedResults gr;
			if (pi > index)
			{
				index = pi;
				gr = new GroupedResults(pi * ratingDivider);
				groupedResults = ArrayUtils.setAllowGrowthArray(groupedResults, index, gr);
			}
			else
			{
				gr = groupedResults[pi];
			}
			
			// Capture distribution points.
			int deltaRating = p._rating - gr._baseRating;
			DistributionPoint pt = new DistributionPoint(deltaRating, p._currentSkill);
			gr._distPoints.add(pt);
			gr._sumOfRatingValues += deltaRating;
			gr._sumOfSkillValues += p._currentSkill;
			
			// Group by skill and compute stats for each group.
			int si = p._currentSkill/skillDivider;
			StatTotal st = null;
			if (si < gr._groupedTotals.length)
			{
				st = gr._groupedTotals[si];
			}
			if (st == null)
			{
				st = new StatTotal();
				gr._groupedTotals = ArrayUtils.setAllowGrowthArray(
					gr._groupedTotals, si, st);			
			}
			st._total++;
			st._wins += p._numWins;
			st._games += p._gamesPlayed;
			st._totalEquip += p._equipmentScore;
		}
		
		for (GroupedResults gr : groupedResults)
		{
			if (gr != null)
			{
				
				int numPts = gr._distPoints.size();
				float avgRatingDiff = (float)gr._sumOfRatingValues / numPts;
				float avgSkill = (float)gr._sumOfSkillValues / numPts;
				// Compute best fit coefficient where coefficient is the variable C in
				// the expression C + 10*(deltaRating).
				int coeffSum = 0;
				float crossProductSum = 0;
				float ratingMinusAvgSquareSum = 0;
				for (DistributionPoint pt : gr._distPoints)
				{
					coeffSum += (pt._skill - RatingConstants.convertFromRatingToSkill(pt._deltaRating));
					float deltaRatingMinusAvg = (pt._deltaRating - avgRatingDiff);
					float skillMinusAvg = (pt._skill - avgSkill);
					crossProductSum += deltaRatingMinusAvg * skillMinusAvg;
					ratingMinusAvgSquareSum += deltaRatingMinusAvg * deltaRatingMinusAvg;
				}
				// Compute coefficient.
				int coeff = coeffSum / numPts;
				
				// Compute deviation.
				long sumSquares = 0;
				for (DistributionPoint pt : gr._distPoints)
				{
					int delta = (pt._skill - RatingConstants.convertFromRatingToSkill(pt._deltaRating) - coeff);
					sumSquares += (delta * delta);
				}
				double avgSquare = (double)sumSquares / numPts;
				int dev = (int)Math.sqrt(avgSquare);
				
				// Compute the slope of the line that would be the best fit line for the
				// current distribution of points.
				float slopeBestFitLine = 0;
				if (ratingMinusAvgSquareSum > 0)
				{
					slopeBestFitLine = crossProductSum / ratingMinusAvgSquareSum;
				}
				
				gr._coefficient = coeffSum / numPts;
				gr._deviation = dev;
				gr._slopeOfBestFitLine = slopeBestFitLine;
			}
		}
		
		_groupedResults = groupedResults;
	}

	@Override
	public int compare(Player arg0, Player arg1)
	{
		return arg0._rating - arg1._rating;
	}
}
