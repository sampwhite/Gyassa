package groupratings;

public class RatingConstants
{
	static public final int RATING_INTERVAL = 100;
	static public final int RATING_INDEX_INTERVAL = 2 * RATING_INTERVAL;
	static public final int RATING_LEVEL_INTERVAL = 4 * RATING_INTERVAL;
	
	// This can be adjusted to account for actual ration of realized skill level intervals
	// to rating intervals. For now, there is sufficient inflation and skill expectation
	// corrections that no adjustments have to be made.
	static public final int SKILL_LEVEL_INTERVAL = 4000;
	
	static public final int convertFromSkillToRating(int skill)
	{
		return skill / 10;
	}
	
	static public final int convertFromRatingToSkill(int rating)
	{
		return rating * 10;
	}

}
