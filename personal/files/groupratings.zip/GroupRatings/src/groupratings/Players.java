package groupratings;
import java.util.Collection;

import rdd.core.RdCharArray;
import rdd.core.RdContext;


public class Players
{
	public PlayerGroup _side1;
	public PlayerGroup _side2;
	
	public Collection<Match> _currentMatches;
	public int[] _playerTypeRandomRanges;
	public int _weightTypeRange;
	public int _numRequiredTypes;

	public int _numPlayersPerGroup = 500;
	public int _numPlayersPerMatch = 5;
	public int[] _playerTypeWeightings = {1, 1, 3};
	public int[] _playerTypesRequired = {1, 1, 1};
	
	
	// Parameters that control how matches are created and assembled.
	MatchCreationParameters _matchCreationParameters = new MatchCreationParameters();
	
	// Parameters that control how matches are resolved and how the results impact the ratings
	// equipment of the players.
	MatchProcessingParameters _matchProcessingParameters = new MatchProcessingParameters();
	
	
	//+section Hardwired parameters
	// Every improvement interval, cost multiplies by 8.
	public int _equipmentImprovementDegradationInterval = 2 * RatingConstants.SKILL_LEVEL_INTERVAL;
	// If the minimum rating for all players in match is greater than the experienced player rating
	// then the match is worth more. Divide by this number and use it as a power of 2 for the value 
	// of the match for equipment.
	public int _rateEquipmentImprovementMultiplierInterval = RatingConstants.RATING_INDEX_INTERVAL;
	// The maximum amount that equipment can improve.
	public int _maxEquipmentImprovement = 3 * _equipmentImprovementDegradationInterval;

	// Controls how quickly equipment improvements are given out. Set from SimulationProfile.
	public int _baseEquipmentImprovementAmount = 30;
	
	// Threshold for having a good time playing.
	public int _goodTimeRatingThreshold = 4 * RatingConstants.RATING_LEVEL_INTERVAL;
	
	// Amount player waits before being put back into the queue for "players waiting for a match".
	public RandomRange _playerRoundWaitRange = new RandomRange(1, 5);
	// The number of rounds simulating the passage of a day. In order to keep the number of players
	// down to a manageable level we assume that each player represents 10 "real" players each
	// rotating in one after another playing the role of our simulated players.
	public int _longDurationIntervalForImprovement = 200; // This simulates a "day" being passed in the sense of a "get rid of most of the uninteresting part"
	// How many rounds that a player waits for a match that will cause a "long wait" event to be reported.
	public int _longWaitDuration = 8;
	//+endsection Hardwired attributes.
	
	// Results capturing.
	public BooleanResultCounter _randomBeatSkill = new BooleanResultCounter("RandomBeatSkill");
	public BooleanResultCounter _expectedProductivity = new BooleanResultCounter("ExpectedProductivity");
	public BooleanResultCounter _expertMatch = new BooleanResultCounter("ExpertMatch");
	public BooleanResultCounter _longWaitForMatchSide1 = new BooleanResultCounter("LongQueueWaitSide1");
	public BooleanResultCounter _longWaitForMatchSide2 = new BooleanResultCounter("LongQueueWaitSide2");
	public BooleanResultCounter _goodSkillMatches = new BooleanResultCounter("GoodSkillMatch");
	public BooleanResultCounter _properlyCreatedMatch = new BooleanResultCounter("ProperlyCreatedMatch");
	public BooleanResultCounter _goodRatedMatches = new BooleanResultCounter("GoodRatedMatch");
	public BooleanResultCounter _ratingsPredictedSkillWell = new BooleanResultCounter("RatingsPredictedSkillWell");
	public BooleanResultCounter _expertRatingsPredictedSkillWell =  new BooleanResultCounter("ExpertRatingsPredictedSkillWell");
	public BooleanResultCounter _ratingsPredictedSkillNotBadly = new BooleanResultCounter("RatingsPredictedSkillNotBadly");
	
	public ResultsDistribution _resultsDistribution;
	public int _ratingsForSkillVariance[] = {200}; //{60, 100, 200};
	public RatingDifferenceSkillVariance[] _ratingSkillVariances;
	
	// Match counter.
	public volatile int _matchCounter = 0;
	
	// Logic control of rewards. The idea is to give out smaller rewards bonuses more often if
	// need more players on one side vs the other.
	public int _cumulativeTeam1VsTeam2QueueSizeDiff;
	public int _numRewardsPerIntervalSide1;
	public int _numRewardsPerIntervalSide2;
	
	// Boolean counters.
	public BooleanResultCounter[] _booleanResultCounters = new BooleanResultCounter[] {
		_randomBeatSkill,
		_longWaitForMatchSide1,
		_longWaitForMatchSide2,
		_expectedProductivity,
		_expertMatch,
	    _goodSkillMatches,
	    _properlyCreatedMatch,
		_goodRatedMatches,
		_ratingsPredictedSkillWell,
		_expertRatingsPredictedSkillWell,
		_ratingsPredictedSkillNotBadly,
		};
	
	public Players(int numPlayersPerGroup, int numPlayersPerMatch, RandomRange playersRoundWaitRange,
		RandomRange matchDurationRange, int[] playerTypeWeightings, int[] playerTypesRequired,
		RandomRange startSkillRange, int maxIntervalToleranceForMatches, int baseEquipmentImprovementAmount)
	{
		_numPlayersPerGroup = numPlayersPerGroup;
		_numPlayersPerMatch = numPlayersPerMatch;
		_playerRoundWaitRange = playersRoundWaitRange;
		_matchCreationParameters._matchDurationRange = matchDurationRange;
		_playerTypeWeightings = playerTypeWeightings;
		_playerTypesRequired = playerTypesRequired;
		_matchCreationParameters._startSkillRange = startSkillRange;
		_matchCreationParameters._maxIntervalToleranceForMatches = maxIntervalToleranceForMatches;
		_baseEquipmentImprovementAmount = baseEquipmentImprovementAmount;
	}
	
	public void init(PlayerGroup side1, PlayerGroup side2, RdContext cxt)
	{
		_side1 = side1;
		_side2 = side2;
		_currentMatches = RatingUtils.createOrderedSet(null);
		_weightTypeRange = 0;
		_playerTypeRandomRanges = new int[_playerTypeWeightings.length];
		for (int i = 0; i < _playerTypeWeightings.length; i++)
		{
			_weightTypeRange += _playerTypeWeightings[i];
			_numRequiredTypes += _playerTypesRequired[i];
			_playerTypeRandomRanges[i] = _weightTypeRange;
		}
	}
	
	public void initResultsDistribution(int rateRange, int skillRange)
	{
		_resultsDistribution = new ResultsDistribution(rateRange);
		_resultsDistribution.init();
		_ratingSkillVariances = new RatingDifferenceSkillVariance[_ratingsForSkillVariance.length];
		for (int i = 0; i < _ratingsForSkillVariance.length; i++)
		{
			_ratingSkillVariances[i] = new RatingDifferenceSkillVariance(_ratingsForSkillVariance[i], 
				skillRange);
		}
	}
	
	public String createBooleanResultCounterReport(RdContext cxt)
	{
		RdCharArray report = new RdCharArray();
		try
		{
			boolean lineHasContent = false;
			for (int i = 0; i < _booleanResultCounters.length; i++)
			{
				if (lineHasContent)
				{
					report.append(",");
				}
				report.append(_booleanResultCounters[i].toString());
				if ((i + 1) % 3 == 0)
				{
					report.append("\n");
					lineHasContent = false;
				}
				else
				{
					lineHasContent = true;
				}
			}
		}
		catch (Exception ignore)
		{
		}
		return report.toString();
	}
}
