package groupratings;

public class MatchProcessingParameters
{
	//+section K-factor
	// The Elo K-factor. The current value being used presumes that the
	// average master player will have played 2000 games to achieve their high rating in a multiplayer
	// setting. The general rule is that higher values are used only when a player has not played many games at all
	// or if there is good reason (such as a long passage of time) to believe that the player's last rating may no longer
	// reflect reality. Other rating systems use dynamic modification of this attribute
	// depending on the players and their play history, we stick to a more traditional approach,
	// see _applyGraduatedRatingAdjustmentMultiplier.
	public int _eloKfactor = 16;

	// Whether to apply a graduated adjustment to the rating dependent on rating level. If enabled, the k-factor
	// is decreased significantly at higher ratings and adjusted at other rating intervals based on
	// observations about which rating intervals tend to have high or low alphas. Enabling
	// this appears to only be useful for single player games where there seems to
	// be more pronounced issues with alpha. As a quick reminder, alpha is the ratio
	// of the spread of skill for a rating range relative to the desired spread expressed
	// as a percentage value.
	public boolean _applyGraduatedRatingAdjustment = true;
	
	// The rating at which to reduce the K-factor if applyGraduatedRatingAdjustmentMultiplier
	// is enabled.
	public int _reduceKfactorRating = 7 * RatingConstants.RATING_LEVEL_INTERVAL;
	//+endsection K-factor

	//+section Team rating and skill dividers
	// The differences between the total ratings of the two contested teams is divided by
	// this value before being compared against RatingConstants.RATING_LEVEL_INTERVAL to
	// determine how much the ratings of players should be adjusted upward and downward.
	// Doubling this value will double the theoretical rating range but the actual
	// effect may be quite different over the first few thousand games.
	// The issue with this value is similar to the issue with the k-factor. It takes quite some time
	// for a group of players to reach the eventual true spread of ratings. In many cases it may
	// be thousands of games even in single player scenarios. Experimental evidence has shown
	// that even in single player scenarios setting this value to 2 gives better predictive
	// results for the differences in skill of two players during the first few hundred
	// games assuming adjustments for skill expectation are disabled (_doBadSkillExpressionTesting is
	// set to false which would align more with reality for chess).
	// In multiplayer games, the issue is that there is a great variance in the expected outcome
	// for any particular player because of the randomization factors that come from the team mates.
	// The team mates not only have variations in their expressed skills they also have variances
	// of the true skill from the predicted skill given their current rating. These combine
	// to create a fairly large spread in realized skill outcomes. To account for this
	// and create results that give better predictive abilities for skill given a particular
	// rating, fairly high values for this attribute are needed if no corrective
	// inflation or skill expectation adjustments are used.  If large k-factors are used, 
	// then this attribute can be reduced but usually that produces less predictive power for the ratings.
	// ---
	// However, in this implementation we have access to expected skill statistics of losing players
	// and can determine the severity of a loss. If this is taken into account (which it is
	// by default), then the ratings move faster and more accurately to their correct values
	// and this value can be set to be the same as _teamSkillDivider (the correct theoretical
	// value if running more than 2000 games per player for players whose skill do not change
	// during that run). This value is initialized from the SimulationProfile class.
	public float _teamTotalRatingDivider = 2.23f;
	
	// Used for normalizing the range of skill differences from multiplayer matches so they
	// can be compared or contrasted to the ranges of skill differences in single player (on a team) matches.
	// The skill totals of two teams are differenced then divided by this value before tested and tracked
	// for statistical results. This value is also used as a multiplier on the outcome of 
	// _matchResultVarianceForTeam before it is added
	// to the the team's skill total (assuming _useVariancesOfIndividualPlayers is disabled). 
	// It reflects the increased variance produced by adding
	// up all the variances of individual team players. Using the rules about summing up
	// n bell curves increasing the deviation of the sum by the square root of n, we
	// assume this value should be about the square root of _numPlayersPerMatch.
	public float _teamSkillDivider = 2.23f; 
	//+endsection Team rating and skill dividers

	//+section Rating Inflation
	// A player with less than this number of regular wins gets a rating bonus with each win.
	// This attribute is set by the SimulationProfile.
	public int _numWinsRatingInflation = 400;
	// The amount to add to the rating after a regular win.
	public int _amountWinIncreasesRating = 1;
	// If a player has fewer than this number of "first" (first in a duration interval) wins, 
	// then each first win adds a bonus rating amount. The idea is that the first win on each "day"
	// gives a big rating boost, but only for so many days. This number should be set
	// to a value that causes the number of "Expert Match" games to be about 20% after
	// 60,000 iterations of queueing. Most players after playing a 500 matches should
	// reach the expert level because of equipment improvements.
	public int _numFirstLongIntervalWinsRatingInflation = _numWinsRatingInflation / 4;
	// Amount to add to rating if under threshold of number of first wins and player wins a game.
	public int _amountFirstWinIncreasesRating = _amountWinIncreasesRating * 8;
	// Whether to accelerate inflation for early wins. Currently enabling this variable
	// actually hurts the accuracy of the rating system for reasons that are not clear.
	public boolean _accelerateInflationForEarlyWins = false;
	//+endsection Rating Inflation
	
	//+section Variances and Results Expectation Ranges
	// Plus or minus to add to skill for each team. The combination of the two variances creates
	// a triangle probability distribution that mimics a bell curve closely enough. There is a lot
	// of debate about what is the proper distribution of a player's skill manifestation, but
	// there is research evidence that it does not much matter which distribution is used 
	// when it comes to the resulting utility of the rating system. Because of this, we
	// stick to the simplest model we can. Our current choice gives the following results.
	// Assume player A is playing player B.
	// Player A is SKILL_LEVEL_INTERVAL lower in skill to B -> probability of winning is 8%
	// Player A is SKILL_LEVEL_INTERVAL/2 lower in skill to B -> probability of winning is 24.5%
	// Player A is SKILL_LEVEL_INTERVAL/4 lower in skill to B -> probability of winning is 36%
	// This is fairly close to the expectations of winning given by the Elo rating system.
	public int _resultVarianceRange = (5 * RatingConstants.SKILL_LEVEL_INTERVAL) / 6; 
	public RandomRange _matchResultVarianceForTeam = 
		new RandomRange(-_resultVarianceRange, _resultVarianceRange);
	// Rating required to be considered "serious" about the activity (800).
	public int _experiencedPlayerRating = 2 * RatingConstants.RATING_LEVEL_INTERVAL;
	// Rating required to be an expert player (1600).
	public int _expertPlayerRating = 4 * RatingConstants.RATING_LEVEL_INTERVAL;
	// Good match rating variance. Assigned.
	public int _goodMatchRatingVariance;
	// Good match skill variance. Assigned.
	public int _goodMatchSkillVariance;
	// Skill did well enough in predicting skill given variances in manifestation of skill
	// and rating. Assigned.
	public int _goodSkillPredictionByRatingVariance;
	// Outside of this variance, rating did poorly in predicting skill. Assigned.
	public int _badSkillPredictionByRatingVariance;
	
	// Maximum amount of skill productivity allowed.
	public int _maxSkillProductivity = RatingConstants.SKILL_LEVEL_INTERVAL;
	// Maximum amount team can improve skill productivity of a player on team.
	public int _maxTeamSkillProductivity = RatingConstants.SKILL_LEVEL_INTERVAL;
	
	// Base level of minimum skill productivity. Doing much more than this relative
	// to your rating means you get a lot less share of the loss.
	public int _minExpectedSkillProductivity = RatingConstants.SKILL_LEVEL_INTERVAL / 2;
	
	// Used to test whether a match is a blowout. If the total skill productivity of a team
	// minus its total expected productivity is less than this number times the number
	// of team members, then the match is a blowout.
	public int _negativeProductivityThresholdForBlowout = RatingConstants.SKILL_LEVEL_INTERVAL / 4;
	
	// Whether to sum up variances from individual players to produce variances of total.
	// It is not at all clear how inputs from individual players in a team competition
	// combine, but this gives another option to test. So far experimentation has shown
	// little difference whether this value is enabled or not. Enabling this value
	// does mean that the _teamSkillDivider is NOT used when computing the variance for
	// a team, which may be desired in some cases.
	public boolean _useVariancesOfIndividualPlayers = false;
	//+section Variances and Results Expectation Ranges


	
	// Flags controlling different operational features. These should normally be true,
	// but can be false if trying to see how feature impacts results.
	// Controls whether to use stats for losing players. Normally is true unless setting
	// to false to compare results.
	//+section Flags controlling features
	public boolean _useStatsForLosingPlayers = true;
	// Whether to do equipment improvement. If this is set to false, then halve the
	// K-factor since ratings don't need to move as fast. Otherwise alpha tends to
	// be too small.
	public boolean _doEquipmentImprovement = true;
	// Whether to do skill training.
	public boolean _doSkillTraining = true;
	// Whether players are retired after a certain amount of time.
	public boolean _doPlayerRetirement = true;
	// Whether there should be rating inflation for new players and for
	// players with low rating.
	public boolean _doRatingInflation = true;
	// If the losing team has a poor showing, then that implies the defeat is legitimate
	// and the rating adjustment should be increased.
	public boolean _doBadSkillProductivityTesting = true;
	//+endsection Flags controlling features

}
