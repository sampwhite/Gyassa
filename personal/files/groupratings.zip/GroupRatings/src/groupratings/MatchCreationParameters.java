package groupratings;

public class MatchCreationParameters
{
	// The skill range of new players.
	public RandomRange _startSkillRange = 
		new RandomRange(2 * RatingConstants.SKILL_LEVEL_INTERVAL, 4 * RatingConstants.SKILL_LEVEL_INTERVAL);
	
	// Attributes not initialized by constructor. These attributes are less likely to need to change
	// for various types of tests.
	//+section Hardwired attributes
	public RandomRange _maxSkillImprovementRateRange = 
		new RandomRange(2 * RatingConstants.SKILL_LEVEL_INTERVAL, 4 * RatingConstants.SKILL_LEVEL_INTERVAL);
	
	// About 1000 to 4000 games required to reach your potential if you have a really good potential.
	public RandomRange _skillImprovementRange = new RandomRange(_maxSkillImprovementRateRange._high/4000, _maxSkillImprovementRateRange._high/1000);

	// If character starts playing after the first 10,000 rounds, then they get some initial
	// training.
	public RandomRange _initialSkillTrainedPercentage = new RandomRange(0, 75);

	// Controls how close in ratings we try to make the two teams when creating matches
	// using ratings as a guide. An interval is the team rating divided by 
	// _rateEquipmentImprovementMultiplierInterval. This attribute controls how many such
	// interval deviations are tolerated.
	public int _maxIntervalToleranceForMatches = 2;
	
	//+section Hardwired randomization parameters
	public RandomRange _matchDurationRange = new RandomRange(5, 10);
	public RandomRange _statCoorelationRange = new RandomRange(50, 100);
	public RandomRange _minNumGamesToPlay = new RandomRange(100, 1500);
	public RandomRange _casualnessLevel = new RandomRange(1, 8);
	//+endsection Hardwired randomization parameters

	// Internal parameters that control how matches are created from waiting queues
	// of players. This is very much an area that needs more investigation since
	// the current algorithms produce results that have certain non optimal characteristics
	// such as creating out comes that tend to favor one side or another or produce
	// unequal length queues.
	//+section Internal parameters
	public int _minNumberOfMatchesPerScheduling = 6;
	public int _minNumberOfEstimatedMatchesForRatingsBasedGrouping = 2;
	public int _numRoundsForMaxTrainingUpFront = 20000;
	//+endsection Internal parameters
	
	// These flags enable features in the solution. Some are turned on just to test
	// out a particular part of the overall solution. Others are on by default and
	// turned off to see what happens if a particular feature is removed.
	//+section Feature control
	public boolean _useSomeBottomUpPairing = true;
	public boolean _improveBottomUpPairing = false;
	public boolean _tripleInitialSkillRange = false;
	//+endsection Feature control
	

}
