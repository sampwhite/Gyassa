package groupratings;
import java.io.IOException;

import rdd.core.RdAppendDebug;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;


public class ResultsDistribution implements RdAppendDebug
{
	// Range of possible inputs is from negative to positive of this value.
	public int _range;
	public int _offset;
	
	public int _numIntervals = 20;
	public int _totalOfInRangeValues;
	public long _totalOfSquareOfInRangeValues;
	
	public BooleanResultCounter[] _resultCounters;
	public BooleanResultCounter _inRange = new BooleanResultCounter("InReportRange");
	
	public ResultsDistribution(int range)
	{
		_range = range;
	}
	
	public void init()
	{
		_resultCounters = new BooleanResultCounter[_numIntervals];
		for (int i = 0; i < _numIntervals; i++)
		{
			int start = -_range + (2 * _range * i) / _numIntervals + _offset;
			int end = -_range + (2 * _range * (i + 1)) / _numIntervals + _offset;
			String resultCounterTitle = "[" + start + "," + end + "]";
			BooleanResultCounter resultCounter = new BooleanResultCounter(resultCounterTitle);
			resultCounter._trueString = "win";
			resultCounter._falseString = "lose";
			_resultCounters[i] = resultCounter;
		}
	}
	
	public void reportResult(int val, boolean result)
	{
		val -= _offset;
		// If out of range, then value is ignored.
		if (val <= -_range || val >= _range)
		{
			_inRange.incrementCounter(false);
		}
		else
		{
			int index = ((_range + val) * _numIntervals) / (2 * _range);
			_resultCounters[index].incrementCounter(result);
			_inRange.incrementCounter(true);
			_totalOfInRangeValues += val;
			_totalOfSquareOfInRangeValues += (val * val);
		}
	}
	
	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		for (int i = 0; i < _numIntervals; i++)
		{
			if (i > 0 && i % 5 == 0)
			{
				appendable.append('\n');
			}
			appendable.append("" + _resultCounters[i]);
		}
		appendable.append('\n');
		appendable.append("" + _inRange);
		if (_inRange._numTrue > 0)
		{
			int avg = _totalOfInRangeValues / _inRange._numTrue + _offset;
			int dev = (int)(Math.sqrt((double)_totalOfSquareOfInRangeValues/_inRange._numTrue) + 0.5d);
			appendable.append(" Average="+ avg);
			appendable.append(" Expected Average=" + _offset);
			appendable.append(" Statistical Deviation From Expected Average " + dev);
		}
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
