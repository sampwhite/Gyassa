package groupratings;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.primitives.ArrayUtils;


public class MatchCreationUtils
{
	// Utility object.
	static public Collection<Player> EMPTY_COLLECTION_OF_PLAYERS = new ArrayList<Player>();

	//+section Player creation
	static public void initPlayerGroup(String namePrefix, Players players,
		PlayerGroup playerGroup, int numPlayers, RdContext cxt)
	{
		playerGroup._players.clear();
		RdCharArray name = new RdCharArray();
		for (int i = 0; i < numPlayers; i++)
		{
			name.reset();
			appendPlayerName(name, namePrefix, playerGroup);
			String nameStr = name.toString();
			Player player = createNewPlayer(0, nameStr, players, playerGroup, 0, cxt);
			playerGroup._players.add(player);
		}
	}
	
	static public void addPendingPlayers(int round, String namePrefix, Players players, 
		PlayerGroup playerGroup, RdContext cxt)
	{
		RdCharArray name = new RdCharArray();
		while (playerGroup._numNewPlayersToAdd > 0)
		{
			name.reset();
			appendPlayerName(name, namePrefix, playerGroup);
			String nameStr = name.toString();
			Player player = createNewPlayer(round, nameStr, players, playerGroup, 0, cxt);
			playerGroup._players.add(player);
			playerGroup._playersWaiting.add(player);
			playerGroup._numNewPlayersToAdd--;
		}
	}
	
	static public void appendPlayerName(Writer w, String namePrefix, PlayerGroup playerGroup)
	{
		try
		{
			w.append(namePrefix);
			w.append("-" + ++playerGroup._totalNumPlayers);
		}
		catch (Exception ignore)
		{
			
		}
	}
	
	static public Player createNewPlayer(int round, String playerName, Players players,
		PlayerGroup playerGroup, int flags, RdContext cxt)
	{
		MatchCreationParameters mc = players._matchCreationParameters;
		MatchProcessingParameters mp = players._matchProcessingParameters;
		int type = getRandomType(players, cxt);
		int startSkill = RatingUtils.getRandomInRange(cxt, mc._startSkillRange);
		if (mc._tripleInitialSkillRange)
		{
			startSkill = 3 * startSkill;
		}
		if (!mp._doSkillTraining && !mp._doEquipmentImprovement)
		{
			// Doing simpler model, double skill range.
			startSkill = 2 * startSkill;
			/*
			int avg = mc._startSkillRange._low + mc._startSkillRange._high;
			if (startSkill >= avg && startSkill <= avg + 8000 && startSkill % 3 != 0)
			{
				startSkill = avg + 8000;
			}
			else if (startSkill <= avg && startSkill >= avg - 8000 && startSkill % 3 != 0)
			{
				startSkill = avg - 8000;
			}
			*/
		}
		int skillImprovementRate = RatingUtils.getRandomInRange(cxt, mc._skillImprovementRange);
		int maxSkillImprovement = RatingUtils.getRandomInRange(cxt, mc._maxSkillImprovementRateRange);
		int casualnessLevel = RatingUtils.getRandomInRange(cxt, mc._casualnessLevel);
		int minGamesToPlay = RatingUtils.getRandomInRange(cxt, mc._minNumGamesToPlay);
		int startRating = 0;
		if (!mp._doEquipmentImprovement || !mp._doRatingInflation)
		{
			// Ratings are not expected to grow so much over time so start at a higher value.
			startRating = mp._expertPlayerRating + RatingConstants.RATING_LEVEL_INTERVAL;
			
			// Players will retire faster because ratings and/or equipment will not be making
			// them stick around. Need to compensate.
			minGamesToPlay = (3 * minGamesToPlay) / 2;
		}
		
		int statCoorelation = RatingUtils.getRandomInRange(cxt, mc._statCoorelationRange);
		Player player = new Player(round, playerName, type, startSkill, skillImprovementRate, maxSkillImprovement,
			startRating, statCoorelation, casualnessLevel, minGamesToPlay);
		if (round > 0)
		{
			int percentageSkillGotten = (100 * round)/mc._numRoundsForMaxTrainingUpFront;
			if (percentageSkillGotten > 100)
			{
				percentageSkillGotten = 100;
			}
			int percentageTrained = RatingUtils.getRandomInRange(cxt, mc._initialSkillTrainedPercentage);
			int trained = (percentageSkillGotten * percentageTrained * maxSkillImprovement)/10000;
			player._trainingImprovement = trained;
			player._intrinsicSkill += trained;
			player._currentSkill += trained;
		}
		return player;
	}
	
	static public int getRandomType(Players players, RdContext cxt)
	{
		int randomNum = RatingUtils.createRandomRange(cxt, 0, players._weightTypeRange - 1);
		int type = 0;
		for (int i = 0; i < players._playerTypeRandomRanges.length; i++)
		{
			if (randomNum < players._playerTypeRandomRanges[i])
			{
				type = i;
				break;
			}
		}
		return type;
	}
	//+endsection Player creation
	
	//+section matchUpPlayers
	public static void matchUpPlayers(Players players, int roundCount, RdContext cxt)
	{
		MatchCreationParameters mc = players._matchCreationParameters;
		
		// Match from lowest to highest until we are left with double the number of players
		// required to make a team, then sort by order in the waiting queue so high rated
		// players will get eventually paired.
		PlayerGroup side1 = players._side1;
		PlayerGroup side2 = players._side2;
		int nSide1 = side1._playersWaiting.size();
		int nSide2 = side2._playersWaiting.size();
		boolean nSide1HasMore = (nSide1 > nSide2);
		int numToPair = (nSide1HasMore) ? nSide2 : nSide1;
		
		// Add new players to queue.
		addPendingPlayers(roundCount, side1._namePrefix, players, side1, cxt);
		addPendingPlayers(roundCount, side2._namePrefix, players, side2, cxt);
		
		// Don't bother unless we have at least a minimum number of matches we can put together, punt
		// to next round if condition is not met.
		if (numToPair/(1 + players._numPlayersPerMatch) >= mc._minNumberOfMatchesPerScheduling)
		{
			createMatches(players, side1, side2, roundCount, nSide1, nSide2, numToPair, cxt);
		}
		
		addToWaitingCount(side1, cxt);
		addToWaitingCount(side2, cxt);
	}
	
	/** Support method for matchUpPlayers **/
	public static void createMatches(Players players, PlayerGroup side1, PlayerGroup side2,
		int roundCount, int nSide1, int nSide2, int numToPair, RdContext cxt)
	{
		MatchCreationParameters mc = players._matchCreationParameters;
		
		int rDivider = players._rateEquipmentImprovementMultiplierInterval;
		boolean side1HasExcess = false;
		boolean side2HasExcess = false;

		int diff = nSide1 - nSide2;
		int excessDiff = 2 * players._numPlayersPerMatch + 5;
		int rewardDivider = 4;
		if (mc._improveBottomUpPairing)
		{
			if (diff > excessDiff)
			{
				side1HasExcess = true;
			}
			else if (diff < -excessDiff)
			{
				side2HasExcess = true;
			}
		}
		players._cumulativeTeam1VsTeam2QueueSizeDiff += diff;
		int estimatedNextRoundCumulativeDiff = players._cumulativeTeam1VsTeam2QueueSizeDiff + diff;
		if (estimatedNextRoundCumulativeDiff > 0 || diff > nSide2/4)
		{
			players._numRewardsPerIntervalSide1 = 1;
		}
		if (estimatedNextRoundCumulativeDiff < 0 || -diff > nSide1/4)
		{
			players._numRewardsPerIntervalSide2 = 1;
		}
		if (estimatedNextRoundCumulativeDiff > 
			2 * (nSide2 + 3 * players._numPlayersPerMatch + 5) && -diff < nSide1)
		{
			players._numRewardsPerIntervalSide2 = rewardDivider;
		}
		else if (-estimatedNextRoundCumulativeDiff > 
			2 * (nSide1 + 3 * players._numPlayersPerMatch + 5) && diff < nSide2)
		{
			players._numRewardsPerIntervalSide1 = rewardDivider;
		}
		
		// If shorter queue is (mostly likely temporarily) on the losing side then take
		// advantage of this by queuing from the bottom. Queuing from the bottom creates
		// an advantage for the shorter queue. Also, doing bottom queuing allows players
		// that get starved in the queue (because certain types of required types of team
		// members are being sucked up by the higher rated players) to get more favored.
		boolean side1HasMoreWins = (side1._totalWins > side2._totalWins);
		boolean doBottomUp = ((diff > 0 && side1HasMoreWins) ||
			(diff < 0 && !side1HasMoreWins)) && mc._useSomeBottomUpPairing;
		if (TraceUtils._reportRounds)
		{
			RdCharArray msg = new RdCharArray();
			msg.prepareForAppend(100);
			try
			{
				if (players._numRewardsPerIntervalSide1 > 1)
				{
					msg.append("-Call for side 1");
				}
				else if (players._numRewardsPerIntervalSide2 > 1)
				{
					msg.append("-Call for side 2");
				}
				else
				{
					msg.append("-Queues relatively even");
				}
				msg.append( " (queue1=" + nSide1 + ",queue2=" + nSide2 + ",diff=" + diff + 
					",totDiff=" + players._cumulativeTeam1VsTeam2QueueSizeDiff + 
					",queueFromBottom=" + doBottomUp + ")");
				RP.detailln(msg, cxt);
			}
			catch (Exception ignore)
			{
				
			}
		}
		
		// Only so many players from the front of each queue are sorted to be used
		// for direct rating assignment. This makes it more likely that players
		// in the front of the queue will be matched up and decrease the issue of
		// starvation for some players.
		int numNeededForTeam = players._numPlayersPerMatch;

		int numNonRatedMatchPlayers = mc._minNumberOfEstimatedMatchesForRatingsBasedGrouping * numNeededForTeam;
		int maxQueuedPlayers = (nSide1 > nSide2) ? nSide2 + 2 * numNonRatedMatchPlayers :
			nSide1 + 2 * numNonRatedMatchPlayers;
		sortPlayerGroupWaitingList(players, players._side1, maxQueuedPlayers, cxt);
		sortPlayerGroupWaitingList(players, players._side2, maxQueuedPlayers, cxt);

		int totalMatched = 0;
		boolean runOutOfEvenMatches = false;
		int numTypes = players._playerTypeWeightings.length;
		boolean noMoreTeams = false;
		while (!noMoreTeams)
		{
			Team team1 = new Team(numTypes, numNeededForTeam);
			Team team2 = new Team(numTypes, numNeededForTeam);
			Player player1 = null;
			Player player2 = null;
			boolean foundPlayer1 = false;
			boolean foundPlayer2 = false;
			int totalRatingDiff = 0;
			int estimatedNumTeamsLeft = (numToPair - totalMatched)/numNeededForTeam;
			int numPlayersNeeded = numNeededForTeam;
			boolean wellFormedMatch = true;
			if (estimatedNumTeamsLeft > mc._minNumberOfEstimatedMatchesForRatingsBasedGrouping && !runOutOfEvenMatches)
			{
				boolean pairFromBottomUp = doBottomUp;
				int ratingIndexSide1;
				int ratingIndexSide2;
				if (pairFromBottomUp)
				{
					// Start from bottom
					ratingIndexSide1 = 0;
					ratingIndexSide2 = 0;
				}
				else
				{
					// We use rating based pairing, pairing from lowest to highest but trying
					// to insure even matches by allowing rating index never to differ by
					// more than 2, but once greater than 6 no longer care, match anything.
					ratingIndexSide1 = side1._maxRatingIndex;
					ratingIndexSide2 = side2._maxRatingIndex;
				}
				
				// Determine starting index for search.
				int si1 = -1;
				int si2 = -1;
				Collection<Player> s1 = null;
				Collection<Player> s2 = null;
				while (numPlayersNeeded > 0)
				{
					int maxDiffAllowed = mc._maxIntervalToleranceForMatches;
					int adjustDivider = (1 + numPlayersNeeded/(maxDiffAllowed + 1));
					
					// Force rating indexes to not be too far apart.
					int currentDiff = totalRatingDiff / rDivider;
					int actualDiff = ratingIndexSide1 - ratingIndexSide2;
					int adjust = (currentDiff + actualDiff) / adjustDivider;
					
					if (adjust >= maxDiffAllowed)
					{
						int adj = (currentDiff >= maxDiffAllowed) ? 1 : 0;
						if (pairFromBottomUp)
						{
							if (ratingIndexSide2 <= ratingIndexSide1)
							{
								ratingIndexSide2 = ratingIndexSide1 + adj;
							}
							if (ratingIndexSide2 > side2._maxRatingIndex)
							{
								// A uneven match is likely.
								ratingIndexSide2 = side2._maxRatingIndex;
								wellFormedMatch = false;
							}
						}
						else
						{
							if (ratingIndexSide1 >= ratingIndexSide2)
							{
								ratingIndexSide1 = ratingIndexSide2 - adj;
							}
							if (ratingIndexSide1 < 0)
							{
								// A uneven match is likely.
								ratingIndexSide1 = 0;
								wellFormedMatch = false;
							}
						}
					}
					if (adjust <= -maxDiffAllowed)
					{
						int adj = (currentDiff <= -maxDiffAllowed) ? 1 : 0;
						if (pairFromBottomUp)
						{
							if (ratingIndexSide1 <= ratingIndexSide2)
							{
								ratingIndexSide1 = ratingIndexSide2 + adj;
							}
							if (ratingIndexSide1 > side1._maxRatingIndex)
							{
								// A uneven match is likely.
								ratingIndexSide1 = side1._maxRatingIndex;
								wellFormedMatch = false;
							}
						}
						else
						{
							if (ratingIndexSide2 >= ratingIndexSide1)
							{
								ratingIndexSide2 = ratingIndexSide1 - adj;
							}
							if (ratingIndexSide2 < 0)
							{
								// A uneven match is likely.
								ratingIndexSide2 = 0;
								wellFormedMatch = false;
							}
						}
					}
					
					if (si1 != ratingIndexSide1)
					{
						s1 = getPlayersAtRatingIndexSafe(side1, ratingIndexSide1);
						si1 = ratingIndexSide1;
						foundPlayer1 = false;
					}
					if (si2 != ratingIndexSide2)
					{
						s2 = getPlayersAtRatingIndexSafe(side2, ratingIndexSide2);
						si2 = ratingIndexSide2;
						foundPlayer2 = false;
					}
					int numTypesNeededTeam1 = players._numRequiredTypes - team1._numTypesFound;
					int numTypesNeededTeam2 = players._numRequiredTypes - team2._numTypesFound;
					boolean mustBeNewTypeTeam1 = (numPlayersNeeded == numTypesNeededTeam1);
					boolean mustBeNewTypeTeam2 = (numPlayersNeeded == numTypesNeededTeam2);
					
					boolean alterIndexSide1 = (s1.size() == 0);
					boolean alterIndexSide2 = (s2.size() == 0);
					if (!alterIndexSide1 && !foundPlayer1)
					{
						// Look for a player for side 1 team.
						Iterator<Player> sit1 = s1.iterator();
						player1 = getPlayerForTeam(team1, players, sit1, mustBeNewTypeTeam1);
						if (player1 != null)
						{
							foundPlayer1 = true;
						}
						else
						{
							alterIndexSide1 = true;
							if (side2HasExcess && ratingIndexSide1 == ratingIndexSide2 && pairFromBottomUp)
							{
								// EXCESS TEST: Try for exact alignment in matching. This reduces problems
								// where going from top favors the longer queue, and going
								// from the bottom favors the shorter queue in terms
								// of creating matches that are more likely to win.
								alterIndexSide2 = true;
							}
						}
					}
					if (!alterIndexSide2 && !foundPlayer2)
					{
						// Look for a player for side 1 team.
						Iterator<Player> sit2 = s2.iterator();
						player2 = getPlayerForTeam(team2, players, sit2, mustBeNewTypeTeam2);
						if (player2 != null)
						{
							foundPlayer2 = true;
						}
						else
						{
							alterIndexSide2 = true;
							if (side1HasExcess && ratingIndexSide1 == ratingIndexSide2 && pairFromBottomUp)
							{
								// See comment on EXCESS TEST above.
								alterIndexSide1 = true;
							}
						}
					}
					if (foundPlayer1 && foundPlayer2)
					{
						addPlayerToTeam(team1, players, player1, s1);
						addPlayerToTeam(team2, players, player2, s2);
						s1.remove(player1);
						s2.remove(player2);
						foundPlayer1 = false;
						foundPlayer2 = false;
						totalRatingDiff += player1._rating - player2._rating;
						numPlayersNeeded--;
					}
					
					// Adjust index if run out of choices at current index.
					if (alterIndexSide1)
					{
						foundPlayer1 = false;
						if (pairFromBottomUp)
						{
							ratingIndexSide1++;
							if (ratingIndexSide1 > side1._maxRatingIndex)
							{
								runOutOfEvenMatches = true;
								break;
							}
						}
						else
						{
							ratingIndexSide1--;
							if (ratingIndexSide1 < 0)
							{
								runOutOfEvenMatches = true;
								break;
							}
						}
					}
					if (alterIndexSide2)
					{
						if (pairFromBottomUp)
						{
							ratingIndexSide2++;
							if (ratingIndexSide2 > side2._maxRatingIndex)
							{
								runOutOfEvenMatches = true;
								break;
							}
						}
						else
						{
							ratingIndexSide2--;
							if (ratingIndexSide2 < 0)
							{
								runOutOfEvenMatches = true;
								break;
							}
							foundPlayer2 = false;
						}
					}
				}
			}
			else
			{
				// We use first in and first out pairing and do not care about whether the
				// outcome creates fair matches. In real situation, one side could be
				// "buffed" to create a more balanced result.
				Iterator<Player> sit1 = side1._playersWaiting.iterator();
				Iterator<Player> sit2 = side2._playersWaiting.iterator();
				wellFormedMatch = false;
				while (numPlayersNeeded > 0)
				{
					int numTypesNeededTeam1 = players._numRequiredTypes - team1._numTypesFound;
					int numTypesNeededTeam2 = players._numRequiredTypes - team2._numTypesFound;
					boolean mustBeNewTypeTeam1 = (numPlayersNeeded == numTypesNeededTeam1);
					boolean mustBeNewTypeTeam2 = (numPlayersNeeded == numTypesNeededTeam2);
					player1 = getPlayerForTeam(team1, players, sit1, mustBeNewTypeTeam1);
					player2 = getPlayerForTeam(team2, players, sit2, mustBeNewTypeTeam2);
					if (player1 != null && player2 != null)
					{
						addPlayerToTeam(team1, players, player1, side1._playersWaiting);
						addPlayerToTeam(team2, players, player2, side2._playersWaiting);
						totalRatingDiff += player1._rating - player2._rating;
						numPlayersNeeded--;
					}
					else
					{
						noMoreTeams = true;
						break;
					}
				}
			} // if (estimatedNumTeamsLeft > 4 && !runOutOfEvenMatches)
			
			if (numPlayersNeeded == 0)
			{
				// A valid pairing of teams.
				removeMatchedUpPlayers(team1, true, players, side1, cxt);
				removeMatchedUpPlayers(team2, false, players, side2, cxt);
				totalMatched += numNeededForTeam;
				int numRoundsForMatch = RatingUtils.getRandomInRange(cxt, mc._matchDurationRange);
				int matchCounter = ++players._matchCounter;
				players._properlyCreatedMatch.incrementCounter(wellFormedMatch);
				Match match = new Match("Match " + matchCounter, team1, team2, roundCount, numRoundsForMatch);
				players._currentMatches.add(match);
			}
		}
		
	}
	
	/** Support method for matchUpPlayers **/
	public static void sortPlayerGroupWaitingList(Players players, PlayerGroup playerGroup, 
		int maxNumPlayers, RdContext cxt)
	{
		playerGroup._maxRatingIndex = 0;
		Collection<Player> w = playerGroup._playersWaiting;
		Collection<Player>[] sp = new Collection[4];
		int interval = 	players._rateEquipmentImprovementMultiplierInterval;
		int playerCount = 0;
		for (Player p : w)
		{
			if (playerCount++ >= maxNumPlayers)
			{
				break;
			}
			int index = p._rating/interval;
			Collection<Player> cur = null;
			if (index < sp.length)
			{
				cur = sp[index];
			}
			if (cur == null)
			{
				cur = RatingUtils.createOrderedSet(null);
				sp = ArrayUtils.setAllowGrowthArray(sp, index, cur);
			}
			if (index > playerGroup._maxRatingIndex)
			{
				playerGroup._maxRatingIndex = index;
			}
			cur.add(p);
		}
		playerGroup._ratingDistributedWaitingPlayers = sp;
	}
	
	/** Support method for matchUpPlayers **/
	public static Collection<Player> getPlayersAtRatingIndexSafe(PlayerGroup group, int index)
	{
		Collection<Player> players = group.getPlayersAtRatingIndex(index);
		if (players == null)
		{
			players = EMPTY_COLLECTION_OF_PLAYERS;
		}
		return players;
	}
	
	/** Support method for matchUpPlayers **/
	public static Player getPlayerForTeam(Team team, Players players, Iterator<Player> playersIter, 
		boolean mustBeNewType)
	{
		Player teamPlayer = null;
		while (playersIter.hasNext())
		{
			Player p = playersIter.next();
			if (!mustBeNewType || team._typesFoundCount[p._type] < players._playerTypesRequired[p._type])
			{
				teamPlayer = p;
				break;
			}
		}
		
		return teamPlayer;
	}
	
	/** Support method for matchUpPlayers **/
	public static void addPlayerToTeam(Team team, Players players, Player player, Collection<Player> coll)
	{
		if (team._numPlayersFound == 0)
		{
			team._minRating = player._rating;
		}
		else if (team._minRating > player._rating)
		{
			team._minRating = player._rating;
		}
		team._members[team._numPlayersFound] = player;
		team._collectionsWithMembers[team._numPlayersFound++] = coll;
		int numOfPlayerType = team._typesFoundCount[player._type];
		if (numOfPlayerType < players._playerTypesRequired[player._type])
		{
			team._numTypesFound++;
		}
		team._typesFoundCount[player._type] = numOfPlayerType + 1;
	}
	
	/** Support method for matchUpPlayers **/
	public static void removeMatchedUpPlayers(Team team, boolean isSide1, Players players, PlayerGroup playerGroup, RdContext cxt)
	{
		Collection<Player> waitingQueue = playerGroup._playersWaiting;
		for (Player p : team._members)
		{
			p._inMatch = true;
			if (isSide1)
			{
				players._longWaitForMatchSide1.incrementCounter(
					p._numRoundsWaitingInQueue >= players._longWaitDuration);
			}
			else
			{
				players._longWaitForMatchSide2.incrementCounter(
					p._numRoundsWaitingInQueue >= players._longWaitDuration);
			}
			p._numRoundsWaitingInQueue = 0;
			waitingQueue.remove(p);
		}
	}
	
	public static void addToWaitingCount(PlayerGroup playerGroup, RdContext cxt)
	{
		Collection<Player> waitingPlayers = playerGroup._playersWaiting;
		for (Player p : waitingPlayers)
		{
			p._numRoundsWaitingInQueue++;
			p._totalRoundsWaitingInQueue++;
		}
	}
	//+endsection matchUpPlayers

}
