package groupratings;

public class SimulationProfile
{
	public int _numPlayersPerGroup = 1000;
	public int _numPlayersPerMatch = 10;
	// Controls how quickly the ratings move with wins and losses. See same attribute in
	// MatchProcessingParameters. Needs to be bigger if multipliers from bad losses
	// are not used.
	public int _eloKfactor = 16;
	// Calculations show this to be approximately equal to the number of players if inflators
	// and skill expectation adjustments are not used, but should be about the _teamSkillDivider
	// otherwise. See the same attribute in MatchProcessingParameters for a long discussion.
	public float _teamTotalRatingDivider = 3.16f; 
	// Random walk variance is square root of number of combined inputs. This attribute
	// should normally be a close approximation of the square root of _numPlayersPerMatch.
	// See MatchProcessingParameters._teamSkillDivider. If this number is varied
	// to produce seemingly better results, the results are not actually better. A larger
	// number here produces more tolerance for error.
	public float _teamSkillDivider = 3.16f; 
	public RandomRange _playerRoundWaitRange = new RandomRange(1, 5);
	public RandomRange _matchDurationRange = new RandomRange(5, 10);
	public int[] _playerTypeWeightings = {1, 1, 3};
	public int[] _playerTypesRequired = {2, 1, 3};
	public int _baseEquipmentImprovementAmount = 40;
	public int _numWinsRatingInflation = 160;
	public RandomRange _startSkillRange = 
		new RandomRange(2 * RatingConstants.SKILL_LEVEL_INTERVAL, 4 * RatingConstants.SKILL_LEVEL_INTERVAL);
	
	public SimulationProfile(int numPlayersPerGroup, int numPlayersPerMatch, int eloKfactor, 
		float teamTotalRatingDivider, float teamSkillDivider,
		int[] playerTypeWeightings, int[] playerTypesRequired, int baseEquipmentImprovementAmount, int numWinsRatingInflation)
	{
		_numPlayersPerGroup = numPlayersPerGroup;
		_numPlayersPerMatch = numPlayersPerMatch;
		_eloKfactor = eloKfactor;
		_teamTotalRatingDivider = teamTotalRatingDivider;
		_teamSkillDivider = teamSkillDivider;
		_playerTypeWeightings = playerTypeWeightings;
		_playerTypesRequired = playerTypesRequired;
		_baseEquipmentImprovementAmount = baseEquipmentImprovementAmount;
		_numWinsRatingInflation = numWinsRatingInflation;
	}
}
