package groupratings;
import rdd.core.RdContext;
import rdd.core.io.RdMessageAppender;
import rdd.core.io.StdRdMessageAppender;


/**
 * Currently this just dumps output to standard output. But if this code is integrated
 * into a larger project, then the static attributes can be set or replaced as desired.
 * This code does suppress errors because it lacks a mechanism for properly reporting them given
 * that this class is used for reporting errors.
 */
public class RP
{
	/**
	 * A message appender for text reports. Can be replaced at start up with
	 * another RdMessageAppender.
	 */
	static public RdMessageAppender _rp = new StdRdMessageAppender(System.out);
	
	/**
	 * A message appender for text tracing. Can be replaced at start up with
	 * another RdMessageAppender.
	 */
	static public RdMessageAppender _detail = new StdRdMessageAppender(System.out);
	
	/**
	 * Whether to send reports to the detail appender as well.
	 */
	static public boolean _sendReportToDetailStream = false;

	
	/**
	 * Report a message without a line feed break at the end.
	 */
	static public void rp(CharSequence msg, RdContext cxt)
	{
		try
		{
			_rp.appendMessage(msg, 0, cxt);
			if (_sendReportToDetailStream)
			{
				_detail.appendMessage(msg, 0, cxt);
			}
		}
		catch (Exception ignore)
		{
			// Ignore
		}

	}

	/**
	 * Report a message with a line feed break at the end.
	 */
	static public void rpln(CharSequence msg, RdContext cxt)
	{
		appendLineMessage(msg, _rp, cxt);
		if (_sendReportToDetailStream)
		{
			appendLineMessage(msg, _detail, cxt);
		}
	}

	/**
	 * Output a detail tracing message without a line feed break at the end.
	 */
	static public void detail(CharSequence msg, RdContext cxt)
	{
		try
		{
			_detail.appendMessage(msg, 0, cxt);
		}
		catch (Exception ignore)
		{
			// Ignored.
		}
	}
	
	/**
	 * Output a detail tracing message with a line feed break at the end.
	 */
	static public void detailln(CharSequence msg, RdContext cxt)
	{
		appendLineMessage(msg, _detail, cxt);
	}
	
	/**
	 * Outputs a line message to an appender and suppresses the error.
	 */
	static public void appendLineMessage(CharSequence msg, RdMessageAppender appender, RdContext cxt)
	{
		try
		{
			appender.appendMessage(msg, RdMessageAppender.F_APPEND_LF, cxt);
		}
		catch (Exception ignore)
		{
			// Ignored.
		}
	}

}
