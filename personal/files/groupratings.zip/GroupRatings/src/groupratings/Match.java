package groupratings;
import java.io.IOException;

import rdd.core.RdAppendDebug;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;


public class Match implements RdAppendDebug
{
	//+section Values for _result
	static final int TEAM_ONE_WON = 1;
	static final int TEAM_TWO_WON = 2;
	//+endsection
	
	public String _name;
	public Team _team1;
	public Team _team2;
	public int _numRoundsActive;
	public int _startRound;
	public int _endRoundCount;
	
	int _result;
	
	public Match(String name, Team team1, Team team2, int startRound, int endRoundCount)
	{
		_name = name;
		_team1 = team1;
		_team2 = team2;
		_startRound = startRound;
		_endRoundCount = endRoundCount;
	}
	
	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		appendable.append(_name);
		appendable.append("(start=" + _startRound + ",active=" + _numRoundsActive);
		appendable.append(",end=" + _endRoundCount);
		appendable.append(")\n*Team 1 ");
		_team1.appendDebug(appendable, cxt, flags);
		appendable.append("\n*Team 2 ");
		_team2.appendDebug(appendable, cxt, flags);
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
