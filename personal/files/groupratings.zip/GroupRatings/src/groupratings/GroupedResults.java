package groupratings;

import java.util.ArrayList;
import java.util.List;

/**
 * Captures data about players in a particular rating interval. It is used to create
 * reports about players in that rating interval.
 */
public class GroupedResults
{
	public int _baseRating;
	public StatTotal[] _groupedTotals = new StatTotal[10];
	public List<DistributionPoint> _distPoints = new ArrayList<DistributionPoint>();
	public int _sumOfRatingValues = 0;
	public int _sumOfSkillValues = 0;
	
	/** Coefficient in equation  Coefficient + (rating - baseRating) * 10 that is best fit
	 * for distribution points. 
	 */
	public int _coefficient;
	
	/** Computation about how well line with slope 10 actually fits data */
	public int _deviation;
	
	/** Slope of line if we were computing best fit line based on actual data. Note
	 * that _coefficient is the coefficient for the best fit line with 10 slope, not
	 * with this slope. */
	public float _slopeOfBestFitLine;
	
	
	
	public GroupedResults(int baseRating)
	{
		_baseRating = baseRating;
	}
}
