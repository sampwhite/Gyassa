package groupratings;

public class StatTotal
{
	public int _total;
	public int _wins;
	public int _games;
	public int _totalEquip;
}
