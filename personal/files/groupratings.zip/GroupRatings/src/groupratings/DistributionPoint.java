package groupratings;

/**
 * Captures for a particular rating interval and a particular player, the difference of the
 * player's rating from the floor of the interval and the player's current skill. It is used
 * to compute linear regression best line fit for all the DistributionPoint values in a
 * particular rating interval.
 */
public class DistributionPoint
{
	public int _deltaRating;
	public int _skill;
	
	public DistributionPoint(int deltaRating, int skill)
	{
		_deltaRating = deltaRating;
		_skill = skill;
	}
}
