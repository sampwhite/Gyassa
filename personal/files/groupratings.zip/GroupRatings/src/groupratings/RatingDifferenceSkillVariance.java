package groupratings;

public class RatingDifferenceSkillVariance
{
	public int _ratingDiff;
	public int[] _ratingDiffRange;
	ResultsDistribution _dist;
	
	public RatingDifferenceSkillVariance(int ratingDiff, int skillRange)
	{
		_ratingDiff = ratingDiff;
		_ratingDiffRange = new int[]{ratingDiff - 20, ratingDiff + 20};
		_dist = new ResultsDistribution(skillRange);
		int offset = (_ratingDiff * skillRange) / RatingConstants.RATING_LEVEL_INTERVAL;
		_dist._offset = offset;
		_dist.init();
	}
	
	public void reportMatchResult(int ratingDiff, int skill, boolean wonMatch)
	{
		if (ratingDiff >= _ratingDiffRange[0] && ratingDiff <= _ratingDiffRange[1])
		{
			_dist.reportResult(skill, wonMatch);
		}
	}
}
