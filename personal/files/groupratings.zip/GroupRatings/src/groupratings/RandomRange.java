package groupratings;

public class RandomRange
{
	public int _low;
	public int _high;
	
	public RandomRange(int low, int high)
	{
		_low = low;
		_high = high;
	}
	
	@Override
	public String toString()
	{
		return "" + _low + " to " + _high;
	}
	
}
