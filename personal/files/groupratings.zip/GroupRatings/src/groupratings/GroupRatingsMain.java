package groupratings;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import rdd.core.RdAppRegistry;
import rdd.core.RdCharArray;
import rdd.core.RdContext;
import rdd.core.primitives.StdProbablityDistribution;


public class GroupRatingsMain
{
	/**
	 * The code executes 100,000 rounds by default. Each round is considered to simulate an elapsed
	 * 30 second period of time. Typical matches will take about 5 minutes and a player is expected
	 * to sign up for matches every couple of minutes. These waits are randomized and can vary
	 * significantly and may be changed without notice. A 200 round period is considered to be a "day"
	 * and this simulation should be considered as a window into a 100 minute period in each day
	 * of a true online gaming solution. This allows us to reduce the number of players that are
	 * simulated so that the execution time is in seconds instead of minutes. In particular, the
	 * number of players used in the simulation should be multiplied by about 50 to determine the
	 * number of active players that are required on a real gaming site to produce similar results.
	 * For example, the simulation for 10 man teams requires 1000 players on each side to be available
	 * in the 100 minute window. Less than that and the rating system starts to produce less useful results.
	 * This means that if a gaming site has less than 50,000 players (or 25,000 per side), then it
	 * it should not use this rating solution except in limited scenarios where players can sign
	 * up in advance for predetermined announced starting times. Also, the concept of alliances
	 * should be dropped in that case for higher rated matches and high rated players should be 
	 * randomly selected for teams without any respect for any larger group membership.
	 * 
	 * The constructor of SimulationProfile takes the following parameters.
	 * int numPlayersPerGroup - The number of players on each side of the two alliances simulation.
	 *  Example value: 1000 players is the most commonly tested value. Larger values make the simulation take
	 *  noticeably longer to run and lower values tend to give less useful results.
	 * int numPlayersPerMatch - The number of players required to make a team for a match. Each team
	 *  consists of only players from a particular alliance ("side1" or "side2").
	 *  Example value: 10 is the most commonly tested value for the number of players on a team.
	 * int eloKfactor - The Elo K-factor to use. Values over 16 increase the speed at which
	 *  highly incorrect ratings converge to the correct values but at the cost of reducing the accuracy
	 *  of ratings that are close to correct value. If you increase the eloKfactor from 16 you will
	 *  need to reduce the rating inflation number. Look for the report "Match Skill Differences Distribution"
	 *  and try to make the computed average fairly close to the actual average. If you do not do this,
	 *  you may get good results but large overall statistical distortions may remain. To compare "apples"
	 *  to "apples" in judging whether one choice is better than another, setting the inflation
	 *  rate so that produces good statistical outcomes for skill variance for any given
	 *  K-factor will give a better judge of which K-factor is better.
	 *  Example value: 16 K-factor, the widely adopted standard for adjusting ratings of
	 *  experienced players that have played many games.
	 * int teamTotalRatingDivider - The team rating is computed by summing up the ratings of the members. Before
	 *  the Elo rating computation is done based on a -400 to 400 range, the total ratings for a team is
	 *  divided by this value to normalize the team rating. Standard probability theory indicates 
	 *  that this value should be about the square root of the number of players.
	 *  Example value: 3.16 is appropriate for a 10 player per team match. Other values can be tried
	 *  to see how it changes results. Changes tend to have less impact that one might expect -- a
	 *  topic of future research.
	 * int teamSkillDivider - The team skill is computed by summing up the skills of the members. Before skills
	 *  are compared or used for reporting, they are divided by this value to normalize the team skill
	 *  This parameter is the expected increase in variance created by adding the contributions 
	 *  from multiple players. Standard probability theory indicates that this value should be about 
	 *  the square root of the number of players.
	 * 	Example value: 3.16 is appropriate for a 10 player per team match. If this value is changed, it will
	 *  influence the statistics that are computed and in particular if it is increased 
	 *  it will cause the statistics to falsely report an improvement because the tolerances 
	 *  for failure will have widened.
	 * int[] playerTypeWeightings - This attribute is an array of integers. It indicates the relative
	 *  ratio of how many players of each type should be produced. The number of possible types
	 *  is equal to the length of this array with the player type being used as an index into this
	 *  array. For example, an array new int[]{2, 3} indicates that for every two players of type 0
	 *  there are about three players of type 1 produced. The selection of player type is random
	 *  and this array gives the weightings used for the randomized selection.
	 *  Example value: new int[]{1, 1, 3} which implies that on average for every one player of type 0
	 *  and type 1 that are produced, three players of type 2 are produced. This value can be
	 *  varied to increase or decrease the number of types or to make certain types significantly
	 *  more popular than others.
	 * int[] _playerTypesRequired - This parameter is used in conjunction with the previous parameter
	 *  and must be of the same length. It specifies the minimum number of players of each type that
	 *  must be on a team. By requiring players of different types on a team, the simulation code
	 *  can reproduce the team matching problems created by mandating that teams have a certain
	 *  number of players with a given role at the time of matching.
	 *  Example value: new int[]{1, 1, 3} which for 10 man teams essentially mandates that there
	 *  is at least one player of type 0 and one player of type 1 on every team. By increasing these
	 *  numbers, we can cause significant issues in creating matches. In particular, players that
	 *  are of the most common types relative to the demands for a team will experience long 
	 *  delays and be more likely to be put onto weaker teams.
	 * int baseEquipmentImprovementAmount - The amount a player's equipment score is increased after
	 *  a win given no other adjustments. For every 200 the minimum rating for both teams is over
	 *  800 this value is doubled. Unless the player is in an alliance which is being called on to
	 *  sign up for more matches, the adjustment will be multiplied by 8 for the first win after
	 *  200 rounds since the last win that was marked as a first win. If an alliance is being
	 *  called up to play more then the adjustment is multiplied by two instead of eight and it
	 *  applies to the first four wins in a 200 round period. If after adjusting other parameters,
	 *  too few players are retiring, you can decrease this value. If too many players are retiring,
	 *  you can increase this value. 
	 *  Example value: 10 seems to work well in making it somewhat difficult for moderately good players
	 *  to maximize their equipment score in less than 1000 games played. This value is one of the
	 *  more varied parameters during actual simulation runs.
	 * int numWinsRatingInflation - The number of wins a player has to reach before they stop getting
	 *  an additional 2 rating points added to their rating for their win. One fourth of this
	 *  parameter is used as a similar number for the number of "first wins". A first win improves
	 *  the rating by 16 points until all the first wins are used up. Rating inflation is
	 *  used only if ratings are started at zero. If rating inflation and equipment score usage
	 *  is disabled then the simulation starts ratings at 1600.
	 *  Example value: 800 - After 800 wins and 200 first wins, the inflation will
	 *  have injected 2400 rating points into a player's rating. This should take about 1600 games
	 *  and is about the expected rating for an average player after that number of games, though
	 *  much of that increased rating comes from improved equipment and not necessarily from 
	 *  intrinsic skill. This value has also been varied significantly during simulations. If it
	 *  is too small or too big, the speed with which ratings converge to their expected value
	 *  can be much slower and it can seriously harm the success of the rating system.
	 */
	static public SimulationProfile _stdTenPlayerTeams = new SimulationProfile(1000, 10, 16, 3.16f, 3.16f,
		new int[]{1, 1, 3}, new int[]{1, 1, 3}, 10, 800);
	static public SimulationProfile _stdFivePlayerTeams = new SimulationProfile(500, 2, 16, 2.23f, 2.23f,
		new int[]{1, 1, 2}, new int[]{1, 1, 0}, 20, 800);
	static public SimulationProfile _stdSinglePlayerMatches = new SimulationProfile(200, 1, 16, 1f, 1,
		new int[]{1}, new int[]{0}, 10, 800);
	
	// Edit as you please.
	static public SimulationProfile _customProfile = new SimulationProfile(1000, 10, 16, 20, 3,
		new int[]{1}, new int[]{0}, 5, 400);
	
	/**
	 * Run a simulation of two groups of players playing each other in teams
	 * and calculating ratings for the players. Players improve both in skill
	 * for each game played and in equipment for each game won. The idea is to see
	 * how closely the rating for a player tracks their actual skill.
	 */
	public static void main(String[] args)
	{
		SimulationProfile profile = _stdTenPlayerTeams;
		RdContext cxt = RdAppRegistry.getThreadWrapperContext();
		if (args.length > 0)
		{
			if (args[0].equals("-5"))
			{
				profile = _stdFivePlayerTeams;
			}
			else if (args[0].equals("-1"))
			{
				profile = _stdSinglePlayerMatches;
			}
			else if (args[0].equalsIgnoreCase("-custom"))
			{
				profile = _customProfile;
			}
			else if (args[0].equalsIgnoreCase("-cdfTest"))
			{
				showCdfValues(cxt);
				return;
			}
			else if (args[0].equalsIgnoreCase("-eloTest"))
			{
				showExpectedEloWinRates(cxt);
				return;
			}
			else if (args[0].equalsIgnoreCase("-varianceTest"))
			{
				testVarianceRange(cxt);
				return;
			}
		}
		int maxIntervalMultiplierForMatchCreationValidnessCriteria = (int)profile._teamSkillDivider;
		Players players = new Players(profile._numPlayersPerGroup, profile._numPlayersPerMatch, 
			profile._playerRoundWaitRange, profile._matchDurationRange,
			profile._playerTypeWeightings, profile._playerTypesRequired, profile._startSkillRange,
			maxIntervalMultiplierForMatchCreationValidnessCriteria, profile._baseEquipmentImprovementAmount);
		PlayerGroup playerGroup1 = new PlayerGroup("Side1");
		PlayerGroup playerGroup2 = new PlayerGroup("Side2");

		players.init(playerGroup1, playerGroup2, cxt);
		cxt.put(cxt, "Players", players);
		MatchProcessUtils.init(profile._eloKfactor, 
			profile._teamTotalRatingDivider, 
			profile._teamSkillDivider, profile._numWinsRatingInflation, players, cxt);
		players.initResultsDistribution(RatingConstants.RATING_LEVEL_INTERVAL, RatingConstants.SKILL_LEVEL_INTERVAL);
		
		fillInPlayers(players, cxt);
		
		// Run the simulation for a while.
		int numRounds = 100000;
		long movePlayersElapsedTime = 0;
		long matchUpElapsedTime = 0;
		long resolveMatchesElapsedTime = 0;
		long prevNanoTime = System.nanoTime();
		long curNanoTime = 0;
		
		// Each round represents about 30 seconds of passed time.
		for (int i = 0; i < numRounds; i++)
		{
			if (TraceUtils._reportRounds)
			{
				RP.detailln("***Round " + (i + 1) + "***", cxt);
			}
			
			// Move players that have finished waiting into queue for being assigned to matches.
			movePlayersToWaitingQueue(players, cxt);
			curNanoTime = System.nanoTime();
			movePlayersElapsedTime += (curNanoTime - prevNanoTime);
			prevNanoTime = curNanoTime;
			
			// Create matches.
			MatchCreationUtils.matchUpPlayers(players, i, cxt);
			curNanoTime = System.nanoTime();
			matchUpElapsedTime += (curNanoTime - prevNanoTime);
			prevNanoTime = curNanoTime;
			
			// Resolve matches that have finished.
			MatchProcessUtils.resolveMatches(i, players, cxt);
			curNanoTime = System.nanoTime();
			resolveMatchesElapsedTime += (curNanoTime - prevNanoTime);
			prevNanoTime = curNanoTime;
			
			// Report results.
			int reportTestIndex = i + 1;
			if ((reportTestIndex % 10000) == 0 && numRounds - reportTestIndex >= 10000)
			{
				reportResults(players, reportTestIndex, cxt);
			}
		}
		RP.rpln("\n***Final Report****", cxt);
		reportResults(players, numRounds, cxt);
		int mill = 1000000;
		RP.rpln("Elapsed computational time for different activities: move=" 
			+ movePlayersElapsedTime/mill + 
			"ms, match=" + matchUpElapsedTime/mill + 
			"ms, resolve=" + resolveMatchesElapsedTime/mill + "ms", cxt);
	}
	
	//+section Exploratory code
	public static void showCdfValues(RdContext cxt)
	{
		int count = 0;
		for (double v = 0; v < 2.5; v += .05)
		{
			if (count > 0)
			{
				int mod = count % 5;
				if (mod == 0)
				{
					RP.rp("\n", cxt);
				}
				else
				{
					RP.rp("  ", cxt);
				}
			}
			double cdfResult = StdProbablityDistribution.cdfPhi(v);
			// Looking for probability we are beyond tail.
			double propErr = 1 - cdfResult;
			RP.rp("(" + (float)v + ", " + (float)propErr + ")", cxt);
			count++;
		}
	}
	
	public static void showExpectedEloWinRates(RdContext cxt)
	{
		int count = 0;
		for (int i = 10; i <= 400; i += 10)
		{
			int mod = count % 5;
			if (mod == 0)
			{
				RP.rp("\n", cxt);
			}
			else
			{
				RP.rp("  ", cxt);
			}
			double pow = -(double)i / 400.0d;
			double eloVal = Math.pow(10, pow);
			double expectedWinRate = 1 / (1 + eloVal);
			RP.rp("(" + i + ", " + (float)expectedWinRate + ")", cxt);
			count++;
		}
	}
	
	public static void testVarianceRange(RdContext cxt)
	{
		MatchProcessingParameters mp = new MatchProcessingParameters();
		int skillVariance = mp._resultVarianceRange;
		BooleanResultCounter results = new BooleanResultCounter("SkillLevelDifferenceWinner");
		for (int i = 0; i < 10000; i++)
		{
			int player1 = RatingConstants.SKILL_LEVEL_INTERVAL;
			int player2 = 0;
			int player1Result = player1 + RatingUtils.createRandomRange(cxt, -skillVariance, skillVariance);
			int player2Result = player2 += RatingUtils.createRandomRange(cxt, -skillVariance, skillVariance);
			results.incrementCounter(player1Result > player2Result);
		}
		RP.rpln("" + results, cxt);
	}
	//+endsection Exploratory code
	
	//+section fillInPlayers
	public static void fillInPlayers(Players players, RdContext cxt)
	{
		MatchCreationUtils.initPlayerGroup(players._side1._namePrefix, players, players._side1,
			players._numPlayersPerGroup, cxt);
		MatchCreationUtils.initPlayerGroup(players._side2._namePrefix, players,
			players._side2, players._numPlayersPerGroup, cxt);
		
		startPlayingQueue(players, players._side1, cxt);
		startPlayingQueue(players, players._side2, cxt);
	}
	
	/** Support method for fillInPlayers **/
	public static void startPlayingQueue(Players players, PlayerGroup playerGroup, RdContext cxt)
	{
		playerGroup._playersWaiting.clear();
		playerGroup._playersNotWaiting.clear();
		playerGroup._playersWaiting.addAll(playerGroup._players);
	}
	//+endsection fillInPlayers

	//+section movePlayersToWaitingQueue
	public static void movePlayersToWaitingQueue(Players players, RdContext cxt)
	{
		movePlayersInGroupToWaitingQueue(players._side1, players, cxt);
		movePlayersInGroupToWaitingQueue(players._side2, players, cxt);
	}
	
	/** Support method for movePlayersToWaitingQueue **/
	public static void movePlayersInGroupToWaitingQueue(PlayerGroup playerGroup, Players players,
		RdContext cxt)
	{
		List<Player> playersBeingMoved = new ArrayList<Player>();
		Collection<Player> playersNotWaiting = playerGroup._playersNotWaiting;
		for (Player p : playersNotWaiting)
		{
			p._numRoundsNotWaitingForMatch++;
			if (p._numRoundsNotWaitingForMatch >= p._roundsToWaitTillReadyForMatch)
			{
				p._numRoundsNotWaitingForMatch = 0;
				playersBeingMoved.add(p);
			}
		}
		
		for (Player p : playersBeingMoved)
		{
			playersNotWaiting.remove(p);
			playerGroup._playersWaiting.add(p);
		}
	}
	//+endsection movePlayersToWaitingQueue

	
	//+section reportResults
	public static void reportResults(Players players, int numRounds, RdContext cxt)
	{
		int totalMatchesFinished = players._side1._totalWins + players._side2._totalWins;
		RP.rpln("---Report for Round " + numRounds + " with " + totalMatchesFinished +
			" matches finished, an average of " + ((float)totalMatchesFinished)/numRounds + " per round--", cxt);
		int skillDivider = RatingConstants.SKILL_LEVEL_INTERVAL;
		int ratingDivider = RatingConstants.RATING_LEVEL_INTERVAL;
		RP.rpln("---Side 1---", cxt);
		reportResultsForGroup(players._side1, players, skillDivider, ratingDivider, cxt);
		RP.rpln("---Side 2---", cxt);
		createDistributionDataForReport(players._side2, players, skillDivider, ratingDivider, cxt);
		reportResultsForGroup(players._side2, players, skillDivider, ratingDivider, cxt);
	
		RP.rpln(">>>Match Rating Differences Influence On Victory Results As Histogram Distribution" + 
			" (Where Rating Differences are Divided By Appropriate Team Multiplier For Increased Variance)", cxt);
		RP.rpln("" + players._resultsDistribution, cxt);
		for (RatingDifferenceSkillVariance rdsv : players._ratingSkillVariances)
		{
			RP.rpln(">>>Match Skill Differences Distribution When Rating Differences Are In Interval [" + 
				rdsv._ratingDiffRange[0] + "," + rdsv._ratingDiffRange[1] + "] (Where Rating And Skill Differences Are Divided By " 
				+ "Appropriate Team Multipliers For Increased Variance)", cxt);
			RP.rpln("" + rdsv._dist, cxt);
		}
		RP.rpln(">>>Match Statistics", cxt);
		String countersReport = players.createBooleanResultCounterReport(cxt);
		RP.rpln(countersReport, cxt);
		RP.rpln("---End Report---", cxt);
	}

	public static void createDistributionDataForReport(PlayerGroup playerGroup, Players players, 
		int skillDivider, int ratingDivider, RdContext cxt)
	{
		playerGroup.createSortedListByRating();
		playerGroup.createGroupedRatingAndSkillResultsFromSortedList(ratingDivider, skillDivider);
	}

	public static void reportResultsForGroup(PlayerGroup playerGroup, Players players,
		int skillDivider, int ratingDivider, RdContext cxt)
	{
		PlayerGroup retiredPlayers = playerGroup._retiredPlayers;
		if (retiredPlayers != null && retiredPlayers._players.size() > 0)
		{
			reportPlayersForGroup("retired", retiredPlayers, players, skillDivider, ratingDivider, cxt);
		}
		
		reportPlayersForGroup("active", playerGroup, players, skillDivider, ratingDivider, cxt);
		RP.rpln("Number of total matches won by this side is "+ playerGroup._totalWins, cxt);
	}

	public static void reportPlayersForGroup(String playerType, PlayerGroup playerGroup, Players players,
		int skillDivider, int ratingDivider, RdContext cxt)
	{
		RP.rpln("--" + playerGroup._namePrefix + " " + playerType + " players", cxt);
		createDistributionDataForReport(playerGroup, players, skillDivider, ratingDivider, cxt);
		if (TraceUtils._reportPlayerList)
		{
			for (Player p : playerGroup._playersSortedByRating)
			{
				RP.detailln("" + p, cxt);
			}
		}
		RP.rpln("--Rating and skill distribution for " + playerType + 
			" players, player count is " + playerGroup._players.size(), cxt);
		try
		{
			RdCharArray reportArr = new RdCharArray();
			long varianceTotal = 0;
			int totalNumPlayers = 0;
			for (int i = 0; i < playerGroup._groupedResults.length; i++)
			{
				GroupedResults gr = playerGroup._groupedResults[i];
				if (gr != null)
				{
					reportArr.reset();
					int ratingFloor = i * ratingDivider;
					reportArr.append("" + ratingFloor);
					reportArr.append(" [");
					reportArr.append("count=" + gr._distPoints.size());
					reportArr.append(",coeff=" + gr._coefficient);
					reportArr.append(",dev=" + gr._deviation);
					reportArr.append(",alpha=" + (int)(10 * gr._slopeOfBestFitLine + 0.5));
					reportArr.append("%] (");
					varianceTotal += gr._distPoints.size() * gr._deviation * gr._deviation;
					totalNumPlayers += gr._distPoints.size();
					boolean appendComma = false;
					for (int j = 0; j < gr._groupedTotals.length; j++)
					{
						StatTotal st = gr._groupedTotals[j];
						if (st != null)
						{
							if (appendComma)
							{
								reportArr.append(", ");
							}
							int skillFloor = j * skillDivider;
							reportArr.append("" + skillFloor);
							reportArr.append(":" + st._total);
							int numGames = (st._games > 0) ? st._games : 1;
							reportArr.append("[%wins=" + (100 * st._wins)/numGames);
							int total = (st._total > 0) ? st._total : 1;
							reportArr.append(",avg games " + st._games/total);
							reportArr.append(",avg equip=" + st._totalEquip/total);
							reportArr.append("]");
							appendComma = true;
						}
					}
					reportArr.append(")");
					RP.rpln(reportArr, cxt);
				}
			}
			if (totalNumPlayers > 0)
			{
				int summaryDev = (int)Math.sqrt((double)varianceTotal/totalNumPlayers);
				RP.rpln("Cumulative deviation: " + summaryDev, cxt);
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace(System.err);
		}
	}
//+endsection reportResults
}
