package groupratings;
import java.util.Collection;
import java.util.LinkedHashSet;

import rdd.core.RdContext;
import rdd.core.primitives.RandomUtils;


public class RatingUtils
{
	static public int createRandomRange(RdContext cxt, int low, int high)
	{
		long randomLong = RandomUtils.randomLong(cxt);
		int diff = high - low;
		boolean addRange = true;
		
		randomLong = (randomLong < 0) ? -randomLong : randomLong;
		if (diff < 0)
		{
			addRange = false;
			diff = -diff;
		}
		diff++;
		int rndRange = (int) (randomLong % diff);
		return (addRange) ? low + rndRange : low - rndRange;
	}
	
	static public int getRandomInRange(RdContext cxt, RandomRange range)
	{
		return createRandomRange(cxt, range._low, range._high);
	}
	
	static public <T> Collection<T> createOrderedSet(RdContext cxt)
	{
		return new LinkedHashSet();
	}
	
	static public int boundIntegerByAbsoluteValue(int val, int maxAbs)
	{
		int retVal = val;
		if (val > maxAbs)
		{
			retVal = maxAbs;
		}
		else if (val < -maxAbs)
		{
			retVal = -maxAbs;
		}
		return retVal;
	}
}
