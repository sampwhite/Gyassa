package groupratings;
import java.io.IOException;
import java.util.Collection;

import rdd.core.RdAppendDebug;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;


public class Team implements RdAppendDebug
{
	public Player[] _members;
	public Collection<Player>[] _collectionsWithMembers;
	public int[] _typesFoundCount;
	public int _numDiffTypesNeeded;
	public int _numPlayersFound;
	public int _numTypesFound;
	public int _minRating;
	
	public Team(int numTypes, int numPlayers)
	{
		_members = new Player[numPlayers];
		_collectionsWithMembers = new Collection[numPlayers];		
		_typesFoundCount = new int[numTypes];
	}
	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		appendable.append("minRating=" + _minRating);
		for (Player p : _members)
		{
			if (p != null)
			{
				appendable.append('\n');
				p.appendDebug(appendable, cxt, flags);
			}
		}
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
