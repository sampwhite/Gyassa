package groupratings;
import java.io.IOException;

import rdd.core.RdAppendDebug;
import rdd.core.RdContext;
import rdd.core.RdDataUtils;

public class Player implements RdAppendDebug
{
	public int _creationRound;
	public String _name;
	public int _type;
	
	public int _startSkill;
	public int _skillImprovementRate;
	public int _maxTrainingImprovement;
	public int _statCoorelationPercentage;
	public int _casualnessLevel;
	public int _minNumberOfGamesToPlay;
	
	public int _intrinsicSkill; // = _startSkill + _trainingImprovement
	public int _currentSkill; // = _intrinsicSkill + _equipmentScore;
	public int _trainingImprovement;
	public int _equipmentScore;
	public int _rating; // Can never go below 0.
	public int _gamesPlayed;
	public int _numWins;
	public int _roundsToWaitTillReadyForMatch;
	public int _numRoundsNotWaitingForMatch;
	public int _realWinCountInInterval;
	public int _numFirstRealWins;
	public int _lastRoundWithRealWin;
	public int _skillIncreasesInInterval;
	public int _lastRoundWithRealSkillIncrease;
	
	public int _numRoundsWaitingInQueue;
	public int _totalRoundsWaitingInQueue;
	
	public boolean _inMatch;
	
	public Player(int round, String name, int type, int startSkill, int skillImprovementRate, int maxTrainingImprovement,
		int startRating, int statCoorelationPercentage, int casualnessLevel, int minGamesToPlay)
	{
		_creationRound = round;
		_name = name;
		_type = type;
		_startSkill = startSkill;
		_intrinsicSkill = startSkill;
		_skillImprovementRate = skillImprovementRate;
		_maxTrainingImprovement = maxTrainingImprovement;
		_casualnessLevel = casualnessLevel;
		_minNumberOfGamesToPlay = minGamesToPlay;
		
		_rating = startRating;
		_type = type;
		_statCoorelationPercentage = statCoorelationPercentage;
		
		_currentSkill = _intrinsicSkill;
	}
	
	@Override
	public void appendDebug(Appendable appendable, RdContext cxt, int flags) throws IOException
	{
		appendable.append(_name);
		RdDataUtils.appendDebugNameValue(appendable, "rating", "" + _rating, null, 0, cxt, false, flags);
		RdDataUtils.appendDebugNameValue(appendable, "skill", "" + _currentSkill, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "iskill", "" + _intrinsicSkill, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "equip", "" + _equipmentScore, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "create", "" + _creationRound, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "coor", "" + _statCoorelationPercentage, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "train", "" + _trainingImprovement, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "rtrain", "" + _skillImprovementRate, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "mtrain", "" + _maxTrainingImprovement, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "type", "" + _type, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "nwait", "" + _totalRoundsWaitingInQueue, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "iwins", "" + _realWinCountInInterval, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "lwrd", "" + _lastRoundWithRealWin, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "ncas", "" + _casualnessLevel, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "games", "" + _gamesPlayed, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "fwins", "" + _numFirstRealWins, null, 0, cxt, true, flags);
		RdDataUtils.appendDebugNameValue(appendable, "wins", "" + _numWins, null, 0, cxt, true, flags);
		appendable.append(")");
	}
	
	@Override
	public String toString()
	{
		return RdDataUtils.createDebugStringReport(this, null);
	}
}
