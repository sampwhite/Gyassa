package groupratings;

/**
 * Used to track the results of a test.
 */
public class BooleanResultCounter
{
	public String _name;
	public int _numNA;
	public int _numTrue;
	public int _numFalse;
	
	public String _naString = "N/A";
	public String _trueString = "yes";
	public String _falseString = "no";
	public boolean _showPercents = true;
	
	public BooleanResultCounter(String name)
	{
		_name = name;
	}

	public BooleanResultCounter(String name, String trueString, String falseString)
	{
		_name = name;
		_trueString = trueString;
		_falseString = falseString;
	}

	public void incrementCounter(boolean result)
	{
		if (result)
		{
			_numTrue++;
		}
		else
		{
			_numFalse++;
		}
	}
	
	public boolean testDifferenceAgainstBoundingThreshhold(int val1, int val2, int bound)
	{
		int result = val1 - val2;
		if (result < 0)
		{
			result = -result;
		}
		boolean retVal = (result <= bound);
		incrementCounter(retVal);
		return retVal;
	}
	
	public void incrementNonApplicableCounter()
	{
		_numNA++;
	}

	@Override
	public String toString()
	{
		int winPer = 0;
		boolean doWinPer = _showPercents && _numTrue > 0 && _numFalse > 0;
		if (doWinPer)
		{
			winPer = (int)((100.0f * _numTrue)/(_numTrue + _numFalse) + 0.5);
		}
		String retVal =_name + "(" + _trueString + "=" + _numTrue;
		if (doWinPer)
		{
			retVal += "[" + winPer + "%]";
		}
		retVal += "," + _falseString + "=" + _numFalse;
		if (doWinPer)
		{
			retVal += "[" + (100 - winPer) + "%]";
			
		}
		
		if (_numNA > 0)
		{
			retVal += "," + _naString + "=" + _numNA;
		}
		retVal += ")";
		return retVal;
	}
}
